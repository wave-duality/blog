"""Exploratory board-shape associations with unique frozen-policy game outcomes."""
from pathlib import Path
import csv, hashlib, json, math, time
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
SOURCE=ROOT/'run/analysis/opening-baseline-10k-20261105/main'
NAMES=['desert_center','desert_inner_ring','compatible_first_pick_premium','maximum_corner_pips','corner_pip_std']

def save(path,x): path.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def wilson(k,n):
    p=k/n;z=1.959963984540054;d=1+z*z/n;c=(p+z*z/(2*n))/d;h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [c-h,c+h]
def sigmoid(x): return 1/(1+np.exp(-np.clip(x,-35,35)))
def fit_logistic(x,y):
    beta=np.zeros(x.shape[1]);beta[0]=math.log(y.mean()/(1-y.mean()))
    for iteration in range(100):
        p=sigmoid(x@beta);h=x.T@((p*(1-p))[:,None]*x)
        step=np.linalg.solve(h+np.eye(len(beta))*1e-10,x.T@(p-y))
        old=np.mean(np.logaddexp(0,x@beta)-y*(x@beta));rate=1.
        while rate>1e-7:
            trial=beta-rate*step;eta=x@trial;loss=np.mean(np.logaddexp(0,eta)-y*eta)
            if loss<=old+1e-13: break
            rate*=.5
        beta=trial
        if np.max(np.abs(rate*step))<1e-9: break
    p=sigmoid(x@beta);bread=np.linalg.inv(x.T@((p*(1-p))[:,None]*x))
    scores=x*(y-p)[:,None];cov=bread@(scores.T@scores)@bread*len(y)/(len(y)-x.shape[1])
    assert iteration<99
    return beta,cov,iteration+1
def auc(y,p):
    order=np.argsort(p,kind='stable');s=p[order];ranks=np.zeros(len(p));i=0
    while i<len(p):
        j=i+1
        while j<len(p) and s[j]==s[i]:j+=1
        ranks[order[i:j]]=(i+1+j)/2;i=j
    n1=y.sum();n0=len(y)-n1
    return float((ranks[y==1].sum()-n1*(n1+1)/2)/(n0*n1))
def metrics(y,p):
    p=np.clip(p,1e-9,1-1e-9)
    return dict(brier=float(np.mean((y-p)**2)),log_loss=float(-np.mean(y*np.log(p)+(1-y)*np.log(1-p))),auc=auc(y,p))
def boot_mean(a,seed=110101,nboot=5000):
    rng=np.random.default_rng(seed);means=[]
    for start in range(0,nboot,100):means.extend(a[rng.integers(len(a),size=(min(100,nboot-start),len(a)))].mean(1))
    return [float(v) for v in np.quantile(means,[.025,.975])]

def main():
    start=time.monotonic()
    protocol=dict(analysis='Exploratory analysis of existing outcomes; not a preregistered fresh-outcome experiment.',
      cohort='Exactly one original Generation37 greedy network-vs-network control per seed; tested_seat=0. No search.',
      boards=10000,seed_start=5500000,seed_end=5509999,source_protocol_sha256=sha(SOURCE/'protocol.json'),
      primary_features=NAMES,
      desert='Hex graph distance from the unique central hex: center=0, inner ring=1, coast=2.',
      compatible_first_pick_premium='For each tied maximum-total-pip A1 corner a, subtract half the maximum combined total pips of a mutually legal B1/B2 pair after a; average over tied a. This omits A2 and is a site-scarcity descriptor, not a game-theoretic seat advantage.',
      descriptive_features=['raw first-minus-second gap','raw first-minus-mean(second,third) gap','number of tied maximum-pip corners','standard deviation across all54 corner pip totals'],
      subgroup_bins=dict(premium=['0','(0,0.5]','(0.5,1]','>1'],maximum_pips=['<=11','12','>=13']),
      model='Unpenalized additive logistic regression, standardized inputs, robust sandwich standard errors. Coast is the desert reference. Holm correction across five coefficient tests.',
      validation='Deterministic SHA256(seed + board-seat-20261110) ordering; first8000train,last2000test. Training-only scales and constant win-rate baseline. Paired test-board bootstrap intervals for Brier/logloss improvements,5000resamples.',
      subgroup_uncertainty='95%Wilson intervals, pointwise exploratory. Center/coast difference uses stratified board bootstrap.',
      limitation='One stochastic trajectory per board estimates associations across board types under this policy, not individual-board win probabilities or a causal effect of moving the desert.')
    save(HERE/'board-types-protocol.json',protocol)
    geo=json.loads((ROOT/'viz/geometry.json').read_text());adj=np.eye(54,dtype=bool)
    for a,b in geo['path_vertices']:adj[a,b]=adj[b,a]=True
    compatible=~adj
    hexadj=np.array([[len(set(a)&set(b))==2 for b in geo['hex_vertices']] for a in geo['hex_vertices']])
    xy=np.asarray(geo['hex_xy']);center=int(np.argmin(((xy-xy.mean(0))**2).sum(1)))
    dist=np.full(19,99);dist[center]=0
    for _ in range(3):
        for a in range(19):dist[hexadj[a]]=np.minimum(dist[hexadj[a]],dist[a]+1)
    assert np.array_equal(np.bincount(dist),[1,6,12])
    i,j=np.triu_indices(54,1);pairs=np.column_stack([i[compatible[i,j]],j[compatible[i,j]]])
    replies=[pairs[compatible[a,pairs].all(1)] for a in range(54)]
    vp=np.zeros((54,19),int)
    for v,hs in enumerate(geo['vertex_hexes']):
        for h in hs:
            if h is not None:vp[v,h]=1
    pip_table=np.array([0,0,1,2,3,4,5,0,5,4,3,2,1]);rows=[];hashes={};boards=[]
    for path in sorted(SOURCE.glob('chunk-*.json')):
        raw=path.read_bytes();hashes[path.name]=hashlib.sha256(raw).hexdigest();chunk=json.loads(raw)
        controls={}
        for r in chunk['rows']:
            if r['rule']=='network':controls.setdefault(r['seed'],{})[r['tested_seat']]=r
        for seed,seats in sorted(controls.items()):
            a,b=seats[0],seats[1]
            assert a['history']==b['history'] and a['outcome']==b['outcome'] and a['board']==b['board']
            assert a['terminal'] and b['terminal'] and a['outcome'] in (-1,1)
            res,num,ports=map(np.array,a['board']);desert=np.flatnonzero(res==5);assert len(desert)==1
            tilep=pip_table[num];assert tilep.sum()==58 and tilep[desert[0]]==0
            ps=vp@tilep;sort=np.sort(ps)[::-1];top=np.flatnonzero(ps==ps.max())
            premium=np.mean([ps[v]-.5*np.max(ps[replies[v]].sum(1)) for v in top])
            assert premium>=0
            rows.append(dict(seed=seed,a_won=int(a['outcome']==1),desert_hex=int(desert[0]),desert_ring=int(dist[desert[0]]),
                desert_center=int(dist[desert[0]]==0),desert_inner_ring=int(dist[desert[0]]==1),
                compatible_first_pick_premium=float(premium),maximum_corner_pips=int(ps.max()),corner_pip_std=float(ps.std()),
                raw_first_second_gap=int(sort[0]-sort[1]),raw_first_next_two_gap=float(sort[0]-.5*(sort[1]+sort[2])),maximum_pip_corner_count=int(len(top))))
            boards.append(a['board'])
    rows.sort(key=lambda r:r['seed']);assert [r['seed'] for r in rows]==list(range(5500000,5510000))
    assert sum(r['a_won'] for r in rows)==5475
    with (HERE/'board-features.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    save(HERE/'board-feature-records.json',rows)
    y=np.array([r['a_won'] for r in rows],float);rawx=np.array([[r[n] for n in NAMES] for r in rows]);n=len(y)
    def groups(column,definitions):
        vals=np.array([r[column] for r in rows]);out=[]
        for name,fn in definitions:
            mask=fn(vals);count=int(mask.sum())
            if not count: continue
            wins=int(y[mask].sum());out.append(dict(label=name,boards=count,a_wins=wins,win_rate=wins/count,ci95=wilson(wins,count),feature_mean=float(vals[mask].mean())))
        return out
    grouped=dict(desert=groups('desert_ring',[(k,lambda a,v=v:a==v) for v,k in enumerate(['Center','Inner ring','Coast'])]),
        premium=groups('compatible_first_pick_premium',[('0',lambda a:a==0),('(0,0.5]',lambda a:(a>0)&(a<=.5)),('(0.5,1]',lambda a:(a>.5)&(a<=1)),('>1',lambda a:a>1)]),
        maximum_pips=groups('maximum_corner_pips',[('11 or fewer',lambda a:a<=11),('12',lambda a:a==12),('13 or more',lambda a:a>=13)]),
        raw_gap=groups('raw_first_next_two_gap',[('0',lambda a:a==0),('(0,0.5]',lambda a:(a>0)&(a<=.5)),('>0.5',lambda a:a>.5)]),
        top_ties=groups('maximum_pip_corner_count',[('One',lambda a:a==1),('Two',lambda a:a==2),('Three or more',lambda a:a>=3)]))
    ordered=sorted(range(n),key=lambda i:hashlib.sha256(f'{rows[i]["seed"]}:board-seat-20261110'.encode()).digest());train=np.array(ordered[:8000]);test=np.array(ordered[8000:])
    mean=rawx[train].mean(0);scale=rawx[train].std(0);assert (scale>0).all()
    x=np.column_stack([np.ones(n),(rawx-mean)/scale]);beta,cov,iterations=fit_logistic(x[train],y[train])
    pred=sigmoid(x[test]@beta);base=np.full(len(test),y[train].mean());brier_gain=(y[test]-base)**2-(y[test]-pred)**2
    loggain=-(y[test]*np.log(base)+(1-y[test])*np.log(1-base))+(y[test]*np.log(pred)+(1-y[test])*np.log(1-pred))
    fullscale=rawx.std(0);fullmean=rawx.mean(0);fullx=np.column_stack([np.ones(n),(rawx-fullmean)/fullscale]);b,c,it=fit_logistic(fullx,y)
    coefficients=[]
    for k,name in enumerate(NAMES,1):
        value=float(b[k]/fullscale[k-1]);se=float(np.sqrt(c[k,k])/fullscale[k-1]);z=value/se
        coefficients.append(dict(feature=name,log_odds_per_unit=value,standard_error=se,odds_ratio=math.exp(value),odds_ratio_ci95=[math.exp(value-1.96*se),math.exp(value+1.96*se)],z=z,p=math.erfc(abs(z)/math.sqrt(2))))
    order=np.argsort([r['p'] for r in coefficients]);last=0.
    for rank,k in enumerate(order):last=max(last,min(1,(len(order)-rank)*coefficients[k]['p']));coefficients[k]['holm_p']=last
    center_y=y[rawx[:,0]==1];coast_y=y[(rawx[:,0]==0)&(rawx[:,1]==0)];rng=np.random.default_rng(110102)
    boots=rng.binomial(len(center_y),center_y.mean(),50000)/len(center_y)-rng.binomial(len(coast_y),coast_y.mean(),50000)/len(coast_y)
    summary=dict(protocol=protocol,source_chunk_hashes=hashes,script_sha256=sha(Path(__file__)),boards=n,a_wins=int(y.sum()),win_rate=float(y.mean()),ci95=wilson(int(y.sum()),n),
      groups=grouped,center_minus_coast=dict(difference=float(center_y.mean()-coast_y.mean()),ci95=[float(v) for v in np.quantile(boots,[.025,.975])],method='Stratified empirical board bootstrap; equivalent binomial draws for binary labels;50000replicates'),
      adjusted_coefficients=coefficients,validation=dict(train_n=len(train),test_n=len(test),train_win_rate=float(y[train].mean()),test_win_rate=float(y[test].mean()),
       constant=metrics(y[test],base),features=metrics(y[test],pred),brier_improvement=float(brier_gain.mean()),brier_improvement_ci95=boot_mean(brier_gain),
       log_loss_improvement=float(loggain.mean()),log_loss_improvement_ci95=boot_mean(loggain),feature_prediction_range=[float(pred.min()),float(pred.max())]),
      feature_summaries={name:dict(min=float(rawx[:,j].min()),max=float(rawx[:,j].max()),mean=float(rawx[:,j].mean()),std=float(rawx[:,j].std())) for j,name in enumerate(NAMES)},
      seconds=time.monotonic()-start)
    save(HERE/'board-types-results.json',summary)
    np.savez_compressed(HERE/'board-types-arrays.npz',seeds=np.array([r['seed'] for r in rows]),y=y,features=rawx,train=train,test=test,predictions=pred,constant=base)
    print(json.dumps({k:summary[k] for k in ['boards','win_rate','groups','center_minus_coast','adjusted_coefficients','validation','seconds']},indent=2))

if __name__=='__main__':main()
