#!/usr/bin/env python3
"""Pre-specified supplemental local controls; uses exact cached scores."""
import sys
from pathlib import Path
ROOT=Path('/Users/owenzhang/CatanRL');sys.path.insert(0,str(ROOT))
import json,numpy as np,time,hashlib
from opening_anticipation_portfolios import (SOURCE,OUT,OBJECTIVES,FIELDS,coefficients,build_matrix,mean_ci,paired)
from opening_followup_blocking_fallback import load,all_rp
from opening_study_scale_analysis import (model_specs,stage_data,fit_moments,r2_stats,atomic_json)
from feature_dictionary import geometry_data

def run():
    start=time.monotonic();m=json.loads((SOURCE/'manifest.json').read_text());paths=[SOURCE/s['path'] for s in m['shards']]
    geometry,distance=geometry_data();co=coefficients();base=model_specs()['resource_coverage'];full=model_specs()['board_scarcity']
    specs={}
    for bn,bc in [('local',base),('full',full)]:
        specs[bn]=bc
        for on,ob in [('pips',['pips']),('weighted',['weighted_pips']),('production',['pips','weighted_pips'])]:
            opt=[o+'_optimistic' for o in ob];worst=[o+'_worst' for o in ob]
            specs[bn+'_'+on+'_optimistic']=bc+opt
            specs[bn+'_'+on+'_robust']=bc+worst
            specs[bn+'_'+on+'_both']=bc+opt+worst
    union=list(dict.fromkeys(k for cols in specs.values() for k in cols));cov=np.zeros((len(union),)*2);rhs=np.zeros(len(union));ntrain=0
    rows=[]
    for si,path in enumerate(paths):
        s=load(path);f=load(OUT/'cache'/path.name)['features'];rp=all_rp(s);idx=np.arange(len(rp));choice=s['chosen_vertices'][:,0]
        adj=np.array([sum(h is not None and h>=0 for h in hs) for hs in geometry['vertex_hexes']])
        match=np.all(rp==rp[idx,choice,None,:],axis=2)&(adj[None,:]==adj[choice,None]);counts=match.sum(1)
        matched_mean=(f*match[:,None,:,None]).sum(2)/counts[:,None,None]
        # Stronger local baselines tailored to each objective (simple one-site production maxima).
        pipsgreedy=rp.sum(2).argmax(1);weights=np.array(list(co['weighted_pips'].values()));weightedgreedy=(rp@weights).argmax(1)
        rows.append(dict(seed=s['board_seed'],train=s['train'],matched_count=counts,
          matched_delta=f[idx,:,choice,:]-matched_mean,
          chosen=f[idx,:,choice,:],pipsgreedy=f[idx,:,pipsgreedy,:],weightedgreedy=f[idx,:,weightedgreedy,:],
          pipsgreedy_vertex=pipsgreedy,weightedgreedy_vertex=weightedgreedy,chosen_vertex=choice,
          robust_oracle=f[:,:,:,1].max(2)))
        d,x=build_matrix(s,m,geometry,f,union);w=d['train'][d['group']]/54
        cov+=x.T@(x*w[:,None]);rhs+=x.T@(d['y']*w);ntrain+=int(d['train'].sum())
        if si%25==0:print('Secondary fit',si,flush=True)
    rec={k:np.concatenate([x[k] for x in rows]) for k in rows[0]};np.savez_compressed(OUT/'secondary-board-diagnostics.npz',**rec)
    fits={}
    for name,cols in specs.items():
        ix=np.array([union.index(k) for k in cols]);fit=fit_moments(cov[np.ix_(ix,ix)]/ntrain,rhs[ix]/ntrain,cols);fit.update(ix=ix,errors=[],hits=[]);fits[name]=fit
    targets=[]
    for si,path in enumerate(paths):
        s=load(path);f=load(OUT/'cache'/path.name)['features'];d,x=build_matrix(s,m,geometry,f,union);test=~s['train'];targets.append(d['target'][test])
        for name,fit in fits.items():
            pred=(x[:,fit['ix']]@fit['raw']).reshape(-1,54);err=((d['y'].reshape(-1,54)-pred)**2).mean(1)
            fit['errors'].append(err[test]);fit['hits'].append((pred.argmax(1)==d['chosen'])[test])
    target=np.concatenate(targets);models={}
    for name,fit in fits.items():
        fit['errors']=np.concatenate(fit['errors']);r,ci=r2_stats(fit['errors'],target)
        models[name]=dict(r2=r,r2_ci95=ci,agreement=mean_ci(np.concatenate(fit['hits'])))
    comparisons=[]
    for b in ['local','full']:
        for o in ['pips','weighted','production']:
            for a,c in [(b,b+'_'+o+'_optimistic'),(b,b+'_'+o+'_robust'),(b+'_'+o+'_optimistic',b+'_'+o+'_both'),(b+'_'+o+'_robust',b+'_'+o+'_both')]:
                comparisons.append(dict(reduced=a,full=c,**paired(fits[a]['errors'],fits[c]['errors'],target)))
    order=np.argsort([c['p'] for c in comparisons]);running=0
    for rank,ix in enumerate(order):running=max(running,(len(order)-rank)*comparisons[ix]['p']);comparisons[ix]['holm_p']=min(1.,running)
    descriptions={}
    for name,mask in [('all',np.ones(len(rec['seed']),bool)),('heldout',~rec['train'])]:
        descriptions[name]={}
        matched=mask&(rec['matched_count']>1)
        for j,o in enumerate(OBJECTIVES):
            z={'exact_local_matches':int(matched.sum()),'matched_candidate_count':mean_ci(rec['matched_count'][matched]),
               'vs_same_local_vector_optimistic':mean_ci(rec['matched_delta'][matched,j,0]),
               'vs_same_local_vector_worst':mean_ci(rec['matched_delta'][matched,j,1]),
               'vs_same_local_vector_near_best':mean_ci(rec['matched_delta'][matched,j,6])}
            for g in ['pipsgreedy','weightedgreedy']:
                z[g]=dict(robust_optimal=mean_ci(np.isclose(rec[g][mask,j,1],rec['robust_oracle'][mask,j],atol=1e-9,rtol=0)),
                  chosen_minus_greedy_worst=mean_ci(rec['chosen'][mask,j,1]-rec[g][mask,j,1]))
            descriptions[name][o]=z
    atomic_json(OUT/'secondary.json',dict(schema='opening-anticipation-portfolios-secondary-v1',models=models,comparisons=comparisons,
      descriptions=descriptions,boards=len(rec['seed']),elapsed_seconds=time.monotonic()-start,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
    print('Secondary complete',time.monotonic()-start,flush=True)
if __name__=='__main__':run()
