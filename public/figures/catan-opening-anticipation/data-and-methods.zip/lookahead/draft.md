### Comparing complete openings

The useful question is broader than whether A can still collect all five resources. Does its first pick set up a strong second pick after B has responded? A greedy local rule, a hopeful plan, and a robust plan can prefer different A1 locations on the same board.

We built a bounded opening tree on 128 randomly selected held-out boards. For each candidate A1, we considered B's four highest-scoring B1 choices and, after each, its four highest-scoring B2 choices. We then evaluated every legal A2 response. All roads followed the frozen policy. This produced 527,556 complete openings, scored by Generation 37's value head just before A's first roll.

For each A1, we compared the best attainable A2 value under favorable replies, a policy-weighted average of replies, and the worst reply pair examined. The original A1 policy was never changed by these calculations.

| What the A1 score assumes about B | Mean rank correlation with A1 policy | Policy's A1 also maximizes this score |
| :--- | ---: | ---: |
| Most favorable examined reply pair | 0.501 [0.441, 0.561] | 45.3% |
| Policy-weighted replies | 0.608 [0.548, 0.662] | 55.5% |
| Least favorable examined reply pair | 0.614 [0.550, 0.675] | 56.3% |

The weighted and worst-reply summaries agree with the A1 ranking more closely than the optimistic summary. Their paired rank-correlation improvements are +0.107 [0.042, 0.174] and +0.113 [0.044, 0.185], respectively. The difference between weighted and worst-reply scores is only +0.006 [−0.035, 0.043], so this experiment does not distinguish expected-response planning from minimax-style caution.

There is another useful limit: the resource-weighted local baseline already has a mean rank correlation of 0.586. Neither tree summary clearly exceeds it on this sample. The result is evidence of consistency with plausible responses, not proof that a planning explanation has defeated a local explanation. The separate remote-board intervention is needed to test whether unchanged local sites can change rank when their surroundings change.

The first randomly sampled board makes the distinction concrete. The policy selects A1 corner 44. Corner 40 would allow a much better best-case endpoint (+0.558 versus +0.201), but it is worse under both weighted replies (−0.050 versus +0.028) and the worst replies examined (−0.146 versus −0.107). These are raw value-head predictions, not winning percentages.

A2 is also conditional on what B does. Across the 16 reply pairs, an A1 has an average of 4.80 different value-maximizing A2 locations. The greedy A2 policy and the value-maximizing A2 agree 64.2% of the policy-weighted time; the average raw-value difference is 0.023. The two heads are not interchangeable.

<details>
<summary>What this does and does not establish</summary>

The A1 shortlist contains the six highest policy scores plus the strongest total-pip and resource-weighted local choices if absent. B's top-four branches retain 85.5% of its original joint softmax mass on average. The weighted score renormalizes within the shortlist at B1 and again at B2; the actual calculator is greedy, so these weights are not its action frequencies. All leaf states use native legal histories, and all leaf values are evaluated from A's acting-seat perspective before any dice roll.

Expanding B’s shortlist from four to eight on the fixed first eight boards kept the weighted and worst-score best A1 unchanged on all eight. Their cross-width ranking correlations were 0.986 and 0.967. The optimistic best A1 changed on five of eight boards. This small control supports numerical stability of the weighted and worst summaries in those examples, but cannot establish convergence to a full minimax solution.

The policy is one feed-forward computation. We construct this tree externally to examine what its choices are consistent with; we have not found an explicit search algorithm inside the network. The endpoint evaluator is the same checkpoint's imperfect value head. Opponent settlements are shortlisted and roads are greedy, so the worst-reply score is neither exact Catan minimax nor a guarantee about winning. Confidence intervals bootstrap independent boards 2,000 times and are exploratory, without a correction across comparisons.

</details>
