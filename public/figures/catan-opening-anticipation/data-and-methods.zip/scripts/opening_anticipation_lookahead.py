#!/usr/bin/env python3
"""Bounded opening-tree diagnostic, frozen Generation 37 policy and value.

This is a policy/value consistency study, not a playing-strength comparison or
proof that the feed-forward policy executes search. Top-k B settlement branches
and greedy roads deliberately bound the tree; every legal A2 is evaluated.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import time

import catan_rl
import numpy as np
import torch

from opening_engine import OpeningEngine, MODEL_PATH, MODEL_SHA
from opening_study_scale import split_flags, atomic_json
from opening_followup_plans import evaluate
from opening_network_study import board_features
from feature_dictionary import geometry_data
from train import split_obs

ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/'run/analysis/opening-anticipation-20261102/lookahead'
SELECTION_SEED=141137
COEFFICIENT_PATH=ROOT/'run/analysis/opening-study-100k-20261029/analysis/coefficients.csv'

def resource_coefficients():
    rows=list(csv.DictReader(COEFFICIENT_PATH.open()))
    return {r['feature']:float(r['coefficient']) for r in rows if r['stage']=='A1' and r['model']=='resource_pips'}

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def softmax(z):
    p=np.exp(np.asarray(z,float)-max(z));return p/p.sum()

def rank(x):
    x=np.asarray(x);_,inv,cnt=np.unique(x,return_inverse=True,return_counts=True)
    return (np.cumsum(cnt)-.5*cnt+.5)[inv]

def corr(a,b):
    a=np.asarray(a,float);b=np.asarray(b,float);a=a-a.mean();b=b-b.mean()
    return float(a@b/np.sqrt((a@a)*(b@b))) if a@a>1e-20 and b@b>1e-20 else None

def interval(values):
    x=np.asarray([v for v in values if v is not None],float)
    if not len(x):return dict(n=0,mean=None,ci95=None)
    rng=np.random.default_rng(141138);boot=x[rng.integers(len(x),size=(2000,len(x)))].mean(1)
    return dict(n=len(x),mean=float(x.mean()),ci95=np.quantile(boot,[.025,.975]).tolist())

def game(board,history):
    return catan_rl.Game.from_opening(*board,list(map(int,history)))

class Study:
    def __init__(self,batch_size=64):
        self.engine=OpeningEngine();self.model=self.engine.model
        self.model.requires_grad_(False);self.bot=catan_rl.Bot(sims=0)
        self.batch_size=batch_size;self.n_obs=0;self.n_leaves=0
        self.geometry,self.distance=geometry_data()
        self.resource_coefficients=resource_coefficients()

    def score(self,games):
        out=[]
        for start in range(0,len(games),self.batch_size):
            gs=games[start:start+self.batch_size]
            action,z,v=evaluate(self.model,[g.opening_observation() for g in gs],
                                [np.asarray(g.legal(),dtype=int) for g in gs])
            self.n_obs+=len(gs)
            for g,a,zz,vv in zip(gs,action,z,v):
                legal=np.asarray(g.legal(),dtype=int);zs=zz[legal]
                order=np.lexsort((legal,-zs));p=softmax(zs)
                out.append(dict(action=a,legal=legal.tolist(),logit=zs.tolist(),
                    probability=p.tolist(),order=order.tolist(),value=float(vv)))
        return out

    def complete_roads(self,board,histories):
        gs=[game(board,h) for h in histories];scores=self.score(gs)
        complete=[]
        for g,h,s in zip(gs,histories,scores):
            assert all(a<72 for a in g.legal())
            g.apply(s['action']);complete.append(h+[s['action']])
        return complete

    @torch.inference_mode()
    def leaf_values(self,board,histories):
        values=[]
        for start in range(0,len(histories),self.batch_size):
            block=histories[start:start+self.batch_size];obs=[]
            for h in block:
                g=game(board,h);assert len(h)==8 and g.to_act()==0 and not g.is_chance()
                # End of setup, before A's first RollDice decision: trained actor
                # frame is A, so the raw head needs NO sign inversion.
                assert list(g.legal())==[240]
                o,actor=self.bot.value_observations(*board,g.history(),0)
                assert actor==0 and o.shape==(1,4752)
                obs.append(o)
            _,v=self.model(*split_obs(torch.from_numpy(np.concatenate(obs))))
            values.extend(v.numpy().astype(float).tolist());self.n_obs+=len(obs)
        self.n_leaves+=len(values);return values

    def board(self,seed,width=4,a1_count=6):
        start=time.monotonic();native=catan_rl.Game(seed=int(seed));board=[list(a) for a in native.board_arrays()]
        names,x,_=board_features(board,[],0,self.geometry,self.distance)
        root=self.score([native])[0];legal=np.array(root['legal']);order=np.array(root['order']);z=np.array(root['logit'])
        candidates=legal[order[:a1_count]].tolist()
        max_pip_vertex=int(np.flatnonzero(x[:,names.index('total_pips')]==x[:,names.index('total_pips')].max())[0])
        if 72+max_pip_vertex not in candidates:candidates.append(72+max_pip_vertex)
        resource_score=sum(coef*x[:,names.index(name)] for name,coef in self.resource_coefficients.items())
        max_resource_vertex=int(np.flatnonzero(resource_score>=resource_score.max()-1e-10)[0])
        if 72+max_resource_vertex not in candidates:candidates.append(72+max_resource_vertex)
        a1_hist=self.complete_roads(board,[[a] for a in candidates])
        b1_scores=self.score([game(board,h) for h in a1_hist])
        a1s=[]
        for a1,h,s1 in zip(candidates,a1_hist,b1_scores):
            branches=[];b1ids=s1['order'][:width];p1=np.asarray(s1['probability']);m1=float(p1[b1ids].sum())
            b1_hist=self.complete_roads(board,[h+[s1['legal'][j]] for j in b1ids])
            b2_scores=self.score([game(board,hh) for hh in b1_hist])
            prefixes=[]
            for j,hh,s2 in zip(b1ids,b1_hist,b2_scores):
                b2ids=s2['order'][:width];p2=np.asarray(s2['probability']);m2=float(p2[b2ids].sum())
                for k in b2ids:
                    prefixes.append(hh+[s2['legal'][k]])
                    branches.append(dict(b1_vertex=s1['legal'][j]-72,b2_vertex=s2['legal'][k]-72,
                        b1_rank=int(s1['order'].index(j))+1,b2_rank=int(s2['order'].index(k))+1,
                        b1_probability=float(p1[j]),b2_probability=float(p2[k]),
                        b1_topk_mass=m1,b2_topk_mass=m2,
                        truncated_policy_weight=float(p1[j]/m1*p2[k]/m2)))
            prefixes=self.complete_roads(board,prefixes)
            a2_scores=self.score([game(board,hh) for hh in prefixes])
            pending=[];counts=[]
            for branch,hh,s in zip(branches,prefixes,a2_scores):
                branch.update(prefix=hh,a2_vertices=[a-72 for a in s['legal']],
                    a2_logits=s['logit'],a2_greedy_vertex=s['action']-72)
                pending.extend(hh+[a] for a in s['legal']);counts.append(len(s['legal']))
            leaves=self.complete_roads(board,pending);vals=self.leaf_values(board,leaves)
            at=0
            for branch,count in zip(branches,counts):
                v=np.asarray(vals[at:at+count]);leaf=leaves[at:at+count];at+=count
                best=int(np.lexsort((branch['a2_vertices'],-v))[0]);greedy=branch['a2_vertices'].index(branch['a2_greedy_vertex'])
                branch.update(a2_roads=[h[-1] for h in leaf],a2_values=v.tolist(),
                    best_a2_vertex=branch['a2_vertices'][best],best_a2_value=float(v[best]),
                    policy_a2_value=float(v[greedy]),best_history=leaf[best],policy_history=leaf[greedy])
            best=np.array([b['best_a2_value'] for b in branches]);policy=np.array([b['policy_a2_value'] for b in branches]);weights=np.array([b['truncated_policy_weight'] for b in branches])
            assert abs(weights.sum()-1)<1e-10
            greedy_branch=next(b for b in branches if b['b1_rank']==1 and b['b2_rank']==1)
            row=int(np.flatnonzero(legal==a1)[0])
            a1s.append(dict(vertex=a1-72,root_logit=float(z[row]),root_probability=root['probability'][row],
                root_rank=int(np.flatnonzero(order==row)[0])+1,a1_road=h[-1],local_features=x[a1-72].tolist(),
                resource_weighted_pips=float(resource_score[a1-72]),
                optimistic=float(best.max()),policy_weighted=float(weights@best),worst_case=float(best.min()),
                greedy_B_best_A2=greedy_branch['best_a2_value'],greedy_B_policy_A2=greedy_branch['policy_a2_value'],
                weighted_policy_A2=float(weights@policy),weighted_A2_value_gap=float(weights@(best-policy)),
                retained_joint_policy_mass=float(sum(b['b1_probability']*b['b2_probability'] for b in branches)),branches=branches))
        return dict(seed=int(seed),board=board,width=width,a1_count=a1_count,feature_names=names,
            chosen_a1_vertex=root['action']-72,max_pip_vertex=max_pip_vertex,max_resource_vertex=max_resource_vertex,a1s=a1s,seconds=time.monotonic()-start)

def summarize(out,config):
    boards=[json.loads(p.read_text()) for p in sorted(out.glob('board-*.json'))]
    metric_names=['optimistic','policy_weighted','worst_case','greedy_B_best_A2','greedy_B_policy_A2','weighted_policy_A2']
    metrics={}
    per_board={}
    for name in metric_names+['total_pips','resource_weighted_pips']:
        correlations=[];agree=[];gaps=[]
        for b in boards:
            rows=b['a1s'];z=[r['root_logit'] for r in rows]
            y=np.array([r[name] if name!='total_pips' else r['local_features'][b['feature_names'].index('total_pips')] for r in rows])
            chosen=next(i for i,r in enumerate(rows) if r['vertex']==b['chosen_a1_vertex'])
            correlations.append(corr(rank(z),rank(y)));agree.append(float(y[chosen]>=y.max()-1e-6));gaps.append(float(y.max()-y[chosen]))
        metrics[name]=dict(mean_within_board_spearman=interval(correlations),chosen_is_shortlist_max=interval(agree),best_minus_chosen=interval(gaps))
        per_board[name]=correlations
    # Descriptive partial correlations: residualize both centered logits and
    # centered tree scores against the same local main-effect controls.
    controls=['wood_pips','brick_pips','sheep_pips','wheat_pips','ore_pips','adjacent_hexes','local_resource_count','combined_concentration_hhi','generic_port','wood_port','brick_port','sheep_port','wheat_port','ore_port']
    X=[];Z=[];Y={n:[] for n in metric_names};ids=[]
    for bi,b in enumerate(boards):
        x=np.array([[r['local_features'][b['feature_names'].index(c)] for c in controls] for r in b['a1s']]);X.append(x-x.mean(0))
        z=np.array([r['root_logit'] for r in b['a1s']]);Z.extend(z-z.mean());ids.extend([bi]*len(z))
        for n in metric_names:
            y=np.array([r[n] for r in b['a1s']]);Y[n].extend(y-y.mean())
    X=np.concatenate(X);Z=np.array(Z);zr=Z-X@np.linalg.lstsq(X,Z,rcond=None)[0]
    partial={}
    for name,y in Y.items():
        y=np.array(y);yr=y-X@np.linalg.lstsq(X,y,rcond=None)[0]
        partial[name]=corr(zr,yr)
    rows=[r for b in boards for r in b['a1s']]
    result=dict(schema='opening-anticipation-lookahead-v1',**config,completed_boards=len(boards),a1_candidates=len(rows),
        examined_B_pairs=sum(len(r['branches']) for r in rows),completed_openings=sum(len(br['a2_vertices']) for r in rows for br in r['branches']),
        elapsed_board_seconds=sum(b['seconds'] for b in boards),metrics=metrics,
        paired_rank_correlation_contrasts={f'{a}_minus_{b}':interval([x-y for x,y in zip(per_board[a],per_board[b]) if x is not None and y is not None]) for a,b in [('worst_case','optimistic'),('policy_weighted','optimistic'),('worst_case','policy_weighted')]},
        retained_joint_policy_mass=interval([np.mean([r['retained_joint_policy_mass'] for r in b['a1s']]) for b in boards]),
        weighted_A2_value_gap=interval([np.mean([r['weighted_A2_value_gap'] for r in b['a1s']]) for b in boards]),
        descriptive_partial_correlations=dict(controls=controls,by_score=partial,interpretation='Pooled within-board centered OLS residual correlation; descriptive, not held-out predictive performance or proof of an internal search algorithm.'),
        model_sha256=sha(MODEL_PATH),script_sha256=sha(__file__),all_leaf_actors=0,all_leaf_legal_actions=[240],
        interpretation='Frozen policy/value consistency diagnostic. Top-k B1 and conditional B2 policy shortlist, greedy roads at every forced settlement, all legal A2 settlements. Worst case is only over examined replies and maximizes A value at A2; no later play/search, no guarantee of optimal Catan behavior. Raw tanh value is not calibrated win probability. Weighted averages use separately renormalized top-k softmax at B1 and B2, not actual greedy action frequencies.')
    atomic_json(out/'results.json',result)
    return result

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,default=DEFAULT);p.add_argument('--boards',type=int,default=64);p.add_argument('--width',type=int,default=4);p.add_argument('--a1',type=int,default=6);p.add_argument('--batch-size',type=int,default=64);p.add_argument('--summarize-only',action='store_true');a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True);torch.set_num_threads(1);assert sha(MODEL_PATH)==MODEL_SHA
    seeds=4100000+np.flatnonzero(~split_flags(100000));seeds=np.random.default_rng(SELECTION_SEED).permutation(seeds)[:a.boards].astype(int).tolist()
    config=dict(selected_boards=a.boards,selection_seed=SELECTION_SEED,seeds=seeds,width=a.width,a1_policy_count=a.a1,
        selection='Uniform sample without replacement from original 20,000 held-out boards, fixed before new evaluations. Each A1 shortlist: top policy candidates plus lowest-ID maximum-total-pip and maximum-resource-weighted corners if absent. Resource weights are the existing A1 resource-only regression fit on the disjoint80,000-board training split.',
        resource_coefficients=resource_coefficients(),resource_coefficients_sha256=sha(COEFFICIENT_PATH),
        protocol='At each settlement replay legal native actions. Every road is a greedy policy decision. B1/B2 top-k by their own acting-seat logits. Evaluate every legal A2 after a greedy A2 road, at A first RollDice decision (before any random roll).')
    if (a.out/'config.json').exists():assert config==json.loads((a.out/'config.json').read_text())
    else:atomic_json(a.out/'config.json',config)
    if not a.summarize_only:
        study=Study(a.batch_size)
        for i,seed in enumerate(seeds):
            path=a.out/f'board-{seed}.json'
            if path.exists():continue
            b=study.board(seed,a.width,a.a1);atomic_json(path,b)
            print(f'{i+1}/{len(seeds)} seed {seed}, {len(b["a1s"])} A1, {b["seconds"]:.1f}s, cumulative leaves {study.n_leaves}',flush=True)
    r=summarize(a.out,config);print(json.dumps({k:r[k] for k in ['completed_boards','completed_openings','elapsed_board_seconds','metrics']},indent=2))

if __name__=='__main__':main()
