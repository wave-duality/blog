#!/usr/bin/env python3
"""Paired objective contrasts and fixed-eight-board reply-width sensitivity."""
import json
import numpy as np
from opening_anticipation_lookahead import DEFAULT, interval, corr, rank, sha
from opening_study_scale import atomic_json

def main():
    boards=[json.loads(p.read_text()) for p in sorted(DEFAULT.glob('board-*.json'))]
    metrics=['optimistic','policy_weighted','worst_case','greedy_B_policy_A2','weighted_policy_A2','resource_weighted_pips']
    co={k:[] for k in metrics};ag={k:[] for k in metrics}
    for b in boards:
        rows=b['a1s'];z=np.array([r['root_logit'] for r in rows]);chosen=next(i for i,r in enumerate(rows) if r['vertex']==b['chosen_a1_vertex'])
        for k in metrics:
            v=np.array([r[k] for r in rows]);co[k].append(corr(rank(z),rank(v)));ag[k].append(float(v[chosen]>=v.max()-1e-6))
    pairs=[('worst_case','optimistic'),('policy_weighted','optimistic'),('worst_case','policy_weighted'),('worst_case','resource_weighted_pips'),('policy_weighted','resource_weighted_pips')]
    contrasts={f'{a}_minus_{b}':{'rank_correlation_difference':interval(np.array(co[a])-co[b]),'choice_agreement_difference':interval(np.array(ag[a])-ag[b])} for a,b in pairs}
    result={'boards':len(boards),'method':'Paired differences per independent board; 2,000 whole-board percentile bootstrap resamples, RNGseed141138. Conditional on frozen trained model and bounded sampled tree. Intervals not adjusted across multiple exploratory contrasts.','comparisons':contrasts,'summary_script_sha256':sha(__file__)}
    atomic_json(DEFAULT/'paired-comparisons.json',result)
    agreements=[];breadths=[]
    for b in boards:
        agreements.append(float(np.mean([sum(br['truncated_policy_weight']*(br['best_a2_value']-br['policy_a2_value']<1e-6) for br in a['branches']) for a in b['a1s']])))
        breadths.append(float(np.mean([len(set(br['best_a2_vertex'] for br in a['branches'])) for a in b['a1s']])))
    atomic_json(DEFAULT/'a2-interactions.json',dict(weighted_A2_policy_is_value_max=interval(agreements),distinct_value_best_A2_across_B_pairs=interval(breadths),
        meaning='One mean per independent board, averaging its A1 shortlist equally. A2 agreement is weighted by separately renormalized top4 B1/B2 preferences. Distinct A2 count is unweighted over16examined reply pairs. Descriptive interaction, not evidence of an explicit planning algorithm.',summary_script_sha256=sha(__file__)))
    config=json.loads((DEFAULT/'config.json').read_text());first=next(b for b in boards if b['seed']==config['seeds'][0]);examples=[]
    for row in first['a1s']:
        best=max(row['branches'],key=lambda b:b['best_a2_value']);worst=min(row['branches'],key=lambda b:b['best_a2_value'])
        examples.append({k:row[k] for k in ['vertex','root_rank','root_logit','optimistic','policy_weighted','worst_case','greedy_B_policy_A2']}|
            dict(optimistic_history=best['best_history'],worst_history=worst['best_history'],best_reply_optimistic=best['best_a2_vertex'],best_reply_worst=worst['best_a2_vertex']))
    atomic_json(DEFAULT/'first-board-example.json',dict(seed=first['seed'],board=first['board'],
        selection='First board in the random sample fixed before evaluation; all examined A1 candidates displayed. Raw Generation 37 value at complete opening, not calibrated win probability.',rows=examples))
    wide=DEFAULT.with_name('lookahead-width8')
    if not (wide/'results.json').exists():return
    wc=json.loads((wide/'config.json').read_text());base={b['seed']:b for b in boards};wideboards={}
    for path in wide.glob('board-*.json'):
        b=json.loads(path.read_text());wideboards[b['seed']]=b
    assert set(wideboards)==set(wc['seeds'])
    maxerror=0;comparisons=[]
    for seed in wc['seeds']:
        small=base[seed];large=wideboards[seed];s={r['vertex']:r for r in small['a1s']};l={r['vertex']:r for r in large['a1s']};assert set(s)==set(l)
        for vertex,a in s.items():
            b=l[vertex];old={(r['b1_vertex'],r['b2_vertex']):r for r in a['branches']};new={(r['b1_vertex'],r['b2_vertex']):r for r in b['branches']};assert set(old)<=set(new)
            for key,r in old.items():
                rr=new[key];assert r['prefix']==rr['prefix'] and r['a2_vertices']==rr['a2_vertices'] and r['a2_roads']==rr['a2_roads']
                err=float(np.max(np.abs(np.array(r['a2_values'])-rr['a2_values'])));assert err<3e-5;maxerror=max(err,maxerror)
            assert b['worst_case']<=a['worst_case']+3e-5
            assert b['optimistic']>=a['optimistic']-3e-5
        order=list(s);z=[s[v]['root_logit'] for v in order]
        row={'seed':seed,'a1_vertices':order,'chosen_a1':small['chosen_a1_vertex'],'comparisons':{}}
        for k in metrics[:3]:
            x=np.array([s[v][k] for v in order]);y=np.array([l[v][k] for v in order]);chosen=order.index(row['chosen_a1'])
            row['comparisons'][k]={'width4_root_rho':corr(rank(z),rank(x)),'width8_root_rho':corr(rank(z),rank(y)),
                'cross_width_rho':corr(rank(x),rank(y)),'best_corner_width4':order[int(np.argmax(x))],'best_corner_width8':order[int(np.argmax(y))],
                'mean_score_shift':float((y-x).mean()),'chosen_score_shift':float(y[chosen]-x[chosen]),'max_absolute_score_shift':float(np.max(abs(y-x)))}
        comparisons.append(row)
    summary={}
    for k in metrics[:3]:
        rows=[r['comparisons'][k] for r in comparisons]
        summary[k]={'mean_width4_root_rho':float(np.mean([r['width4_root_rho'] for r in rows])),
            'mean_width8_root_rho':float(np.mean([r['width8_root_rho'] for r in rows])),
            'mean_cross_width_rho':float(np.mean([r['cross_width_rho'] for r in rows])),
            'best_corner_changed_boards':sum(r['best_corner_width4']!=r['best_corner_width8'] for r in rows),
            'mean_score_shift':float(np.mean([r['mean_score_shift'] for r in rows]))}
    result={'boards':len(comparisons),'selection':'First8 boards in fixed128-board random sample; width control fixed before width8results.',
        'identity_control_max_shared_leaf_value_error':maxerror,'all_width4_branches_included_in_width8':True,'worst_value_monotonicity_passed':True,
        'summary':summary,'boards_detail':comparisons,'caution':'Eight-board numerical sensitivity check, not an adequately powered population estimate. Extra low-policy branches can change the worst-case answer.','summary_script_sha256':sha(__file__)}
    atomic_json(DEFAULT/'width-sensitivity.json',result)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
