#!/usr/bin/env python3
"""Independent native replay, single-row inference and aggregation audit."""
import json
from pathlib import Path
import numpy as np
import torch
import catan_rl
from opening_engine import OpeningEngine, MODEL_PATH, MODEL_SHA
from opening_anticipation_lookahead import DEFAULT, sha, corr, rank, interval
from opening_study_scale import atomic_json, split_flags
from train import split_obs

@torch.inference_mode()
def validate(out=DEFAULT):
    torch.set_num_threads(1);assert sha(MODEL_PATH)==MODEL_SHA
    config=json.loads((out/'config.json').read_text());records={}
    heldout=set((4100000+np.flatnonzero(~split_flags(100000))).tolist())
    for path in out.glob('board-*.json'):
        b=json.loads(path.read_text());assert b['seed'] in heldout;records[b['seed']]=b
    assert set(records)==set(config['seeds'])
    checked=0;all_leaves=0
    for b in records.values():
        for row in b['a1s']:
            branches=row['branches'];assert len(branches)==config['width']**2
            best=np.array([max(br['a2_values']) for br in branches]);policy=np.array([br['a2_values'][br['a2_vertices'].index(br['a2_greedy_vertex'])] for br in branches])
            w=np.array([br['truncated_policy_weight'] for br in branches]);assert abs(w.sum()-1)<1e-12
            assert abs(row['optimistic']-best.max())<1e-12
            assert abs(row['worst_case']-best.min())<1e-12
            assert abs(row['policy_weighted']-w@best)<1e-12
            assert abs(row['weighted_policy_A2']-w@policy)<1e-12
            assert abs(row['weighted_A2_value_gap']-w@(best-policy))<1e-12
            assert np.min(best-policy)>=-1e-12
            assert row['optimistic']>=row['policy_weighted']>=row['worst_case']
            for br in branches:
                assert len(br['a2_vertices'])==len(br['a2_roads'])==len(br['a2_values'])
                assert np.all(np.isfinite(br['a2_values'])) and max(abs(v) for v in br['a2_values'])<=1
                all_leaves+=len(br['a2_vertices'])
            checked+=1
    engine=OpeningEngine();model=engine.model;bot=catan_rl.Bot(sims=0);errors=[];roadchecks=0;leafchecks=0
    # Fixed validation sample: first16 in preregistered random seed order.
    for seed in config['seeds'][:16]:
        b=records[seed];native=catan_rl.Game(seed=seed);assert [list(a) for a in native.board_arrays()]==b['board']
        for ri,row in enumerate(b['a1s']):
            br=row['branches'][ri%len(row['branches'])];h=br['best_history'];g=catan_rl.Game(seed=seed)
            for at,action in enumerate(h):
                assert g.to_act()==[0,0,1,1,1,1,0,0][at]
                assert action in g.legal()
                if at%2:
                    z,_=model(*split_obs(torch.from_numpy(g.opening_observation())))
                    legal=np.array(g.legal());chosen=int(legal[np.lexsort((legal,-z[0,legal].numpy()))[0]])
                    assert action==chosen;roadchecks+=1
                if at==6:assert [a-72 for a in g.legal()]==br['a2_vertices']
                g.apply(action)
            assert g.to_act()==0 and g.legal()==[240]
            obs,actor=bot.value_observations(*b['board'],g.history(),0);assert actor==0
            _,v=model(*split_obs(torch.from_numpy(obs)));expected=br['a2_values'][br['a2_vertices'].index(h[-2]-72)]
            error=abs(float(v[0])-expected);assert error<3e-5;errors.append(error);leafchecks+=1
    validation=dict(status='passed',board_count=len(records),candidate_aggregate_checks=checked,leaf_entries=all_leaves,
        independently_replayed_leaves=leafchecks,single_row_greedy_road_checks=roadchecks,
        single_row_value_max_error=max(errors),all_values_in_tanh_range=True,all_leaf_actor_frames='A (seat0), before first roll',
        all_boards_original_heldout=True,model_sha256=sha(MODEL_PATH),analysis_script_sha256=sha(Path(__file__).with_name('opening_anticipation_lookahead.py')),validation_script_sha256=sha(__file__))
    atomic_json(out/'validation.json',validation);print(json.dumps(validation,indent=2))

if __name__=='__main__':validate()
