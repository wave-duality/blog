"""Build a native-board viewer for the bounded opening-reply study."""
import hashlib
import json
from pathlib import Path

from build_opening_theory_reader import live_renderer


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "run/analysis/opening-anticipation-20261102"
OUT = RUN / "publication/public/figures"


def make_examples():
    source = RUN / "lookahead"
    report = json.loads((source / "results.json").read_text())
    cases = []
    for seed in report["seeds"]:
        original = json.loads((source / f"board-{seed}.json").read_text())
        candidates = []
        for a1 in sorted(original["a1s"], key=lambda row: row["root_rank"]):
            branches = a1["branches"]
            chosen = {
                "best": max(branches, key=lambda branch: branch["best_a2_value"]),
                "greedy": next(branch for branch in branches if branch["b1_rank"] == branch["b2_rank"] == 1),
                "worst": min(branches, key=lambda branch: branch["best_a2_value"]),
            }
            views = {}
            for mode, branch in chosen.items():
                greedy = mode == "greedy"
                history = branch["policy_history" if greedy else "best_history"]
                value = branch["policy_a2_value" if greedy else "best_a2_value"]
                assert len(history) == 8 and history[0] == a1["vertex"] + 72
                assert history[2] == branch["b1_vertex"] + 72
                assert history[4] == branch["b2_vertex"] + 72
                assert history[6] == branch["a2_greedy_vertex" if greedy else "best_a2_vertex"] + 72
                if mode in {"best", "worst"}:
                    assert abs(value - a1["optimistic" if mode == "best" else "worst_case"]) < 1e-12
                views[mode] = dict(history=history, value=value,
                                   b1_rank=branch["b1_rank"], b2_rank=branch["b2_rank"],
                                   b1_probability=branch["b1_probability"],
                                   b2_probability=branch["b2_probability"])
            candidates.append({key: a1[key] for key in [
                "vertex", "root_rank", "root_logit", "optimistic", "policy_weighted",
                "worst_case", "retained_joint_policy_mass"
            ]} | dict(views=views))
        cases.append(dict(seed=seed, board=original["board"],
                          chosen_a1_vertex=original["chosen_a1_vertex"],
                          max_pip_vertex=original["max_pip_vertex"],
                          max_resource_vertex=original["max_resource_vertex"],
                          candidates=candidates))
    assert len(cases) == 128 and cases[0]["seed"] == 4172414
    return dict(schema="opening-anticipation-examples-v1", cases=cases,
                geometry=json.loads((ROOT / "viz/geometry.json").read_text()),
                width=report["width"], model_sha256=report["model_sha256"],
                source_results_sha256=hashlib.sha256((source / "results.json").read_bytes()).hexdigest(),
                renderer_source="viz/index.html",
                renderer_sha256=hashlib.sha256(live_renderer().encode()).hexdigest(),
                interpretation="External bounded opening tree, not an internal policy trace. Best and worst are only among examined B replies, with value-optimized A2. All roads are greedy. Values are raw A-perspective values before A's first roll, not calibrated win probabilities.")


TEMPLATE = r'''<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Compare opening replies</title>
<style>
*{box-sizing:border-box}body{margin:0;padding:14px 18px;background:#fff;color:#282725;font:16px/1.55 Georgia,"Times New Roman",serif}
h1{font-size:23px;line-height:1.25;font-weight:600;letter-spacing:-.025em;margin:0 0 8px}p{margin:9px 0}label{display:block;font-size:13px;color:#66635e;margin-bottom:4px}
.intro{color:#5f5c56;font-size:15px;max-width:70ch}.controls{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0 14px}.control{flex:1 1 175px;min-width:0}.control.mode{flex:1.5 1 250px}
select{display:block;width:100%;max-width:100%;min-width:0;font:15px/1.4 Georgia,serif;color:inherit;background:#fff;border:1px solid #c5c1b9;border-radius:4px;padding:8px 28px 8px 9px}
button{font:inherit;color:#315f87;background:none;border:0;padding:1px 0;cursor:pointer;text-decoration:underline;text-decoration-color:#adbdca;text-underline-offset:3px}
button:focus-visible,select:focus-visible,.table-wrap:focus-visible{outline:2px solid #4177a5;outline-offset:3px}.story{border-block:1px solid #e4e1dc;padding:10px 0;margin:0 0 8px;font-size:15px}
.comparison{display:grid;grid-template-columns:minmax(0,1fr);gap:8px 24px;align-items:start}.board-wrap{min-width:0}svg{display:block;width:100%;height:auto;max-height:520px;margin:0 auto}
.legend{display:flex;justify-content:center;gap:22px;color:#605e59;font-size:13px;margin:0 0 12px}.a{color:#3e6fa8}.b{color:#d9583f}.legend span::before{content:"";display:inline-block;width:9px;height:9px;border-radius:50%;background:currentColor;margin-right:6px}
.reading{min-width:0}.reading h2{font-size:17px;font-weight:600;margin:14px 0 7px;line-height:1.3}.value{font-size:16px;border-left:3px solid #b6c6d4;padding:5px 0 5px 12px;margin:8px 0 12px;font-variant-numeric:tabular-nums}.value strong{font-size:25px;letter-spacing:-.03em}.branch{font-size:14px;color:#5d5a55;margin:0 0 12px}
.table-wrap{overflow-x:auto;max-width:100%;margin:8px 0 10px}table{width:100%;border-collapse:collapse;font-size:14px;line-height:1.4;font-variant-numeric:tabular-nums}caption{text-align:left;font-size:17px;font-weight:600;margin-bottom:8px}th,td{padding:8px 7px;border-bottom:1px solid #e6e3de;text-align:right;white-space:nowrap}thead th{font-weight:500;color:#68645e;font-size:12px;white-space:normal;vertical-align:bottom}th:first-child,td:first-child{text-align:left;padding-left:8px}th:last-child,td:last-child{padding-right:8px}tr.selected{background:#edf3f7}td.metric-best{font-weight:600}td small{display:block;font-size:11px;line-height:1.25;color:#79746d}.selected button{color:#234e70}
.note{color:#68645e;font-size:13px;line-height:1.5}.notes{border-top:1px solid #e4e1dc;margin-top:18px;padding-top:10px}.notes p{margin:6px 0}.download{color:#66635e;text-underline-offset:3px}noscript{display:block;padding:12px;border:1px solid #d9d5cf}
@media(min-width:940px){.comparison{grid-template-columns:minmax(0,1.1fr) minmax(0,1fr)}.reading h2{margin-top:10px}svg{max-height:530px}.reading{padding-top:8px}}
@media(max-width:480px){body{padding:12px 10px}.controls{gap:9px}.control,.control.mode{flex-basis:100%}h1{font-size:21px}th,td{padding:7px 5px}table{font-size:13px}.story{font-size:14px}}
</style></head>
<body><main id="figure">
<h1>One first settlement, several replies</h1>
<p class="intro">Choose A’s first corner, then compare a favorable reply, the policy’s continuation, and an adverse reply. The board shows all four opening settlements and their roads.</p>
<div class="controls">
<div class="control"><label for="example">Sampled board</label><select id="example"></select></div>
<div class="control"><label for="candidate">A1 first settlement</label><select id="candidate"></select></div>
<div class="control mode"><label for="mode">Continuation</label><select id="mode"><option value="best">Best examined B reply for A</option><option value="greedy">Greedy policy continuation</option><option value="worst" selected>Worst examined B reply for A</option></select></div>
</div>
<p id="story" class="story"></p>
<div class="comparison">
<div class="board-wrap"><svg id="board" role="img"></svg><p class="legend"><span class="a">A places first and last</span><span class="b">B places twice in between</span></p></div>
<section class="reading" aria-label="Opening comparison">
<h2 id="continuation-title"></h2><p id="value" class="value" aria-live="polite"></p><p id="branch" class="branch"></p>
<div class="table-wrap" tabindex="0" role="region" aria-label="A1 values; scroll horizontally if needed"><table><caption>Compare the examined A1 choices</caption><thead><tr><th scope="col">A1 corner<br>Policy rank</th><th scope="col">Best<br>reply</th><th scope="col">Policy<br>weighted</th><th scope="col">Worst<br>reply</th></tr></thead><tbody id="scores"></tbody></table></div>
<p class="note">Click a corner to show its continuation. Bold numbers mark the highest score in each column. The shaded row is the selected A1.</p>
<p id="coverage" class="note"></p>
</section></div>
<div class="notes note">
<p><strong>How to read the values.</strong> These are raw network values for A, from −1 to +1, evaluated after setup and before the first dice roll. They are not calibrated winning probabilities.</p>
<p><strong>A bounded external comparison.</strong> B1 and B2 each use their top four policy choices; “best” and “worst” refer only to those examined replies. In those two modes, A2 is chosen to maximize the value over every legal A2 corner. In the greedy mode, B1, B2 and A2 follow their highest policy scores. Every road is greedy.</p>
<p>The policy-weighted column averages the value-best A2 outcome using separately renormalized top-four policy weights at B1 and B2. It is an average across replies, not the value of the single board shown. This tree was evaluated externally; it is not a trace of the policy’s internal reasoning.</p>
<p>All 128 sampled boards are available here. A1 candidates are the policy’s top six plus maximum-pip and resource-weighted alternatives when absent.</p>
</div>
<noscript>This figure needs JavaScript to switch boards and draw opening pieces. The downloadable examples contain all displayed histories and values.</noscript>
</main>
<script>
'use strict';
const DATA=/*DATA*/;
const NS='http://www.w3.org/2000/svg';
let GEO=DATA.geometry,CENTER,BOARD,S;
/*RENDERER*/
CENTER=[HX(9),HY(9)];
const $=id=>document.getElementById(id);
let boardIndex=0,candidateIndex=0,mode='worst';
function showTip(){}function hideTip(){}
function signed(value){return `${value<0?'−':'+'}${Math.abs(value).toFixed(3)}`}
function bestCandidate(c,key){return c.candidates.reduce((best,item)=>item[key]>best[key]?item:best)}
function candidateLabel(c,a){let extra=[];if(a.vertex===c.max_pip_vertex)extra.push('max pips');if(a.vertex===c.max_resource_vertex)extra.push('max weighted pips');return `Corner ${a.vertex} · policy #${a.root_rank}${extra.length?' · '+extra.join(', '):''}`}
function fillCandidates(){const c=DATA.cases[boardIndex];$('candidate').replaceChildren();c.candidates.forEach((a,i)=>{const option=document.createElement('option');option.value=i;option.textContent=candidateLabel(c,a);$('candidate').appendChild(option)});candidateIndex=c.candidates.findIndex(a=>a.root_rank===1);$('candidate').value=String(candidateIndex)}
function drawBoard(c,a,view){
  BOARD={res:c.board[0],num:c.board[1],port:c.board[2]};
  S={vertex:Array(54).fill(0),path:Array(72).fill(0),robber:c.board[0].indexOf(5)};justBuilt=null;
  view.history.forEach((action,i)=>{const actor=[0,1,1,0][Math.floor(i/2)];if(action<72)S.path[action]=actor===0?2:1;else S.vertex[action-72]=actor===0?3:1});
  const root=$('board');root.replaceChildren();root.setAttribute('viewBox','-470 -185 1040 970');root.setAttribute('preserveAspectRatio','xMidYMid meet');
  root.setAttribute('aria-label',`Board ${c.seed}: A1 corner ${view.history[0]-72}, B1 corner ${view.history[2]-72}, B2 corner ${view.history[4]-72}, A2 corner ${view.history[6]-72}. ${$('mode').selectedOptions[0].textContent}.`);
  const defs=el('defs',{},root),shadow=el('filter',{id:'sh',x:'-40%',y:'-40%',width:'180%',height:'180%'},defs);el('feDropShadow',{dx:0,dy:1.5,stdDeviation:2.2,'flood-color':'#000','flood-opacity':.12},shadow);
  drawPorts(root);drawHexes(root);drawGlyphs(root);drawTokens(root);drawRobber(root);drawPieces(root);
  const overlay=g(root);view.history.forEach((action,i)=>{if(action<72)return;const vertex=action-72,label=['A1','B1','B2','A2'][i/2],x=VX(vertex),y=VY(vertex)-31;el('rect',{x:x-21,y:y-14,width:42,height:27,rx:4,fill:'#fff',stroke:label[0]==='A'?'#bdccda':'#e4c6c0','stroke-width':1.4},overlay);txt(overlay,x,y,label,{'font-size':20,'font-weight':600,fill:label[0]==='A'?'#3e6fa8':'#d9583f'})});
}
function draw(){
  const c=DATA.cases[boardIndex],a=c.candidates[candidateIndex],view=a.views[mode];
  drawBoard(c,a,view);
  const optimistic=bestCandidate(c,'optimistic'),robust=bestCandidate(c,'worst_case');
  $('story').textContent=`Among the examined A1 choices, corner ${optimistic.vertex} has the highest best-reply value (${signed(optimistic.optimistic)}); corner ${robust.vertex} has the highest worst-reply value (${signed(robust.worst_case)}). The original policy chooses corner ${c.chosen_a1_vertex}.`;
  const titles={best:'Best examined reply for A',greedy:'Greedy policy continuation',worst:'Worst examined reply for A'};
  $('continuation-title').textContent=titles[mode];
  $('value').replaceChildren();const strong=document.createElement('strong');strong.textContent=signed(view.value);$('value').append(strong,document.createTextNode(' raw value for A'));
  const corners=[0,2,4,6].map(i=>view.history[i]-72);
  $('branch').textContent=`A1 ${corners[0]} → B1 ${corners[1]} (policy #${view.b1_rank}) → B2 ${corners[2]} (policy #${view.b2_rank}) → A2 ${corners[3]}. ${mode==='greedy'?'A2 follows its policy favorite.':'A2 is the value-best legal response to these B placements.'}`;
  const keys=['optimistic','policy_weighted','worst_case'],maxima=keys.map(key=>Math.max(...c.candidates.map(item=>item[key])));
  $('scores').replaceChildren();c.candidates.forEach((item,index)=>{const row=document.createElement('tr');if(index===candidateIndex)row.className='selected';const cell=document.createElement('td'),button=document.createElement('button');button.type='button';button.textContent=`Corner ${item.vertex}`;button.setAttribute('aria-label',`Show corner ${item.vertex}, policy rank ${item.root_rank}`);button.setAttribute('aria-pressed',String(index===candidateIndex));button.addEventListener('click',()=>{candidateIndex=index;$('candidate').value=String(index);draw()});cell.appendChild(button);const rank=document.createElement('small');rank.textContent=`Policy #${item.root_rank}${item.root_rank===1?' · original choice':''}`;cell.appendChild(rank);row.appendChild(cell);keys.forEach((key,j)=>{const td=document.createElement('td');td.textContent=signed(item[key]);if(item[key]===maxima[j])td.className='metric-best';row.appendChild(td)});$('scores').appendChild(row)});
  $('coverage').textContent=`For this A1, the 16 examined B reply pairs retain ${(a.retained_joint_policy_mass*100).toFixed(1)}% of the full joint B policy mass. Replies outside this shortlist are not evaluated.`;
  measure();
}
DATA.cases.forEach((c,i)=>{const option=document.createElement('option');option.value=i;option.textContent=`${i+1} of ${DATA.cases.length} · seed ${c.seed}`;$('example').appendChild(option)});
$('example').addEventListener('change',event=>{boardIndex=Number(event.target.value);fillCandidates();draw()});
$('candidate').addEventListener('change',event=>{candidateIndex=Number(event.target.value);draw()});
$('mode').addEventListener('change',event=>{mode=event.target.value;draw()});
const figure=$('figure');let lastHeight=0;
function measure(){const height=Math.ceil(figure.getBoundingClientRect().height+32);if(height!==lastHeight){lastHeight=height;parent.postMessage({type:'catan-figure-resize',height},'*')}}
new ResizeObserver(measure).observe(figure);
addEventListener('message',event=>{if(event.source===parent&&event.data?.type==='catan-figure-measure'){lastHeight=0;measure()}});
fillCandidates();draw();
window.OPENING_ANTICIPATION_VIEW={data:DATA,draw};
</script></body></html>'''


def main():
    data = make_examples()
    payload = json.dumps(data, separators=(",", ":"), allow_nan=False)
    html = TEMPLATE.replace("/*DATA*/", payload.replace("<", "\\u003c"))
    html = html.replace("/*RENDERER*/", live_renderer())
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "catan-opening-anticipation-examples.json").write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
    path = OUT / "catan-opening-anticipation.html"
    path.write_text(html)
    print(path)
    print(f"{len(data['cases'])} boards, {sum(len(c['candidates']) for c in data['cases'])} A1 candidates")


if __name__ == "__main__":
    main()
