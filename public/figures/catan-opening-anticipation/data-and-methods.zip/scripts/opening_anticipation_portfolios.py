#!/usr/bin/env python3
"""Exact opening fallback diagnostics using frozen proxy utilities.

No policy training/search. Every score coefficient comes from the original 80k
training-board fits; held-out diagnostics use the original 20k-board split.
The A2 regression predicts conditional relative logits, not comparable state
values. Its unidentifiable A1-dependent offset is set to zero by convention.
"""
from __future__ import annotations
import argparse, ctypes, hashlib, json, subprocess, time
from pathlib import Path
import numpy as np
import mpmath as mp
from feature_dictionary import geometry_data
from opening_study_scale_analysis import (ALPHA, atomic_json, stage_data, model_specs,
    fit_moments, r2_stats, paired_r2_difference, interval_mean)
from opening_followup_blocking_fallback import load, all_rp

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'run/analysis/opening-study-100k-20261029'
OUT=ROOT/'run/analysis/opening-anticipation-20261102/portfolios'
OBJECTIVES=['pips','weighted_pips','a2_preference']
FIELDS=['optimistic','worst','best_vertex','worst_b1','worst_b2','worst_vertex','near_best_count','worst_rank']
CPP=r'''
#include <cstdint>
#include <algorithm>
#include <vector>
#include <cmath>
static const uint64_t ALL=(uint64_t(1)<<54)-1;
extern "C" void summarize(int n,const double* qs,const uint64_t* closed,const double* thresholds,double* out){
 for(int b=0;b<n;b++)for(int a=0;a<54;a++){
  const double*q=qs+(b*54+a)*54;uint64_t legal=ALL&~closed[a];
  std::vector<int> order;for(int d=0;d<54;d++)if(legal>>d&1)order.push_back(d);
  std::sort(order.begin(),order.end(),[&](int u,int v){return q[u]!=q[v]?q[u]>q[v]:u<v;});
  int best=order[0],wb1=-1,wb2=-1,wd=best;double worst=q[best];
  uint64_t first=closed[best]&legal;
  while(first){int b1=__builtin_ctzll(first);first&=first-1;
   int next=-1;for(int d:order)if(!(closed[b1]>>d&1)){next=d;break;}
   uint64_t second=closed[next]&legal&~closed[b1];
   while(second){int b2=__builtin_ctzll(second);second&=second-1;
    int d=-1;for(int v:order)if(!((closed[b1]|closed[b2])>>v&1)){d=v;break;}
    if(wb1<0||q[d]<worst||(q[d]==worst&&(b1<wb1||(b1==wb1&&b2<wb2)))){worst=q[d];wb1=b1;wb2=b2;wd=d;}
   }
  }
  int near=0,rank=1;for(int d:order){near+=q[d]>=q[best]-thresholds[b];rank+=q[d]>worst+1e-10;}
  double*o=out+(b*54+a)*8;
  o[0]=q[best];o[1]=worst;o[2]=best;o[3]=wb1;o[4]=wb2;o[5]=wd;o[6]=near;o[7]=rank;
 }
}
'''

def coefficients(source=SOURCE):
    r=json.loads((source/'analysis/results.json').read_text())
    def co(stage,model):
        return {x['feature']:(x['coefficient'] or 0.) for x in r['stages'][stage]['models'][model]['coefficients']}
    return dict(weighted_pips=co(0,'resource_pips'),local=co(0,'resource_coverage'),a2_preference=co(3,'resource_coverage'))

def pair_utility(rp, adjacency, objective='pips', coeff=None):
    """Return [boards, A1, A2] scores. Input pips are [boards,54,5].

    pips and weighted_pips are *combined* production. a2_preference is a
    conditional A2-score proxy with the A1-dependent intercept set to zero.
    """
    rp=np.asarray(rp,dtype=float)
    if rp.ndim==2:rp=rp[None]
    adjacency=np.broadcast_to(np.asarray(adjacency),rp.shape[:2])
    if objective in ('pips','weighted_pips'):
        weights=np.ones(5) if objective=='pips' else np.array([coeff[r+'_pips'] for r in ['wood','brick','sheep','wheat','ore']])
        single=rp@weights
        return np.ascontiguousarray(single[:,:,None]+single[:,None,:])
    if objective!='a2_preference':raise ValueError(objective)
    a=rp[:,:,None,:];d=rp[:,None,:,:];both=a+d;total=both.sum(-1)
    concentration=np.divide((both**2).sum(-1),total**2,out=np.zeros_like(total),where=total>0)
    features={r+'_pips':d[...,j] for j,r in enumerate(['wood','brick','sheep','wheat','ore'])}
    features.update(adjacent_hexes=adjacency[:,None,:],local_resource_count=(d>0).sum(-1),
      new_resource_types=((a==0)&(d>0)).sum(-1),new_resource_pips=np.where(a==0,d,0).sum(-1),
      all_five_covered=(both>0).all(-1),combined_concentration_hhi=concentration)
    return np.ascontiguousarray(sum(coeff[k]*v for k,v in features.items()),dtype=np.float64)

def make_solver(out=OUT):
    out.mkdir(parents=True,exist_ok=True);src=out/'exact.cpp';binary=out/'exact.dylib';src.write_text(CPP)
    subprocess.run(['c++','-O3','-std=c++17','-shared','-fPIC',str(src),'-o',str(binary)],check=True)
    lib=ctypes.CDLL(str(binary));fn=lib.summarize
    fn.argtypes=[ctypes.c_int,np.ctypeslib.ndpointer(np.float64,flags='C_CONTIGUOUS'),
      np.ctypeslib.ndpointer(np.uint64,flags='C_CONTIGUOUS'),np.ctypeslib.ndpointer(np.float64,flags='C_CONTIGUOUS'),
      np.ctypeslib.ndpointer(np.float64,flags='C_CONTIGUOUS')]
    fn.restype=None
    def solve(q,closed,threshold=1.):
        q=np.ascontiguousarray(q,dtype=np.float64);n=q.shape[0];out=np.empty((n,54,8),dtype=np.float64)
        fn(n,q,closed,np.full(n,threshold,dtype=np.float64),out)
        return out
    return solve

def mean_ci(x):
    x=np.asarray(x,dtype=float)
    if len(x)<2:return {'n':len(x),'mean':float(x.mean()) if len(x) else None,'ci95':None}
    m,ci=interval_mean(x);return dict(n=len(x),mean=m,ci95=ci)

def paired(a,b,target):
    d=np.asarray(a)-b;r=paired_r2_difference(a,b,target);se=d.std(ddof=1)/np.sqrt(len(d));t=float(d.mean()/se)
    # Complementary beta branch avoids the cancellation/convergence failure
    # of direct I_x(df/2,1/2) when x is extremely close to one.
    with mp.workdps(60):
        df=len(d)-1;x=mp.mpf(df)/(df+mp.mpf(t)**2)
        p=(1-mp.betainc(mp.mpf('.5'),mp.mpf(df)/2,0,1-x,regularized=True)) if abs(t)<10 else mp.betainc(mp.mpf(df)/2,mp.mpf('.5'),0,x,regularized=True)
    r.update(t=t,df=len(d)-1,p=float(p),p_string=str(p),mean_squared_error_reduction=float(d.mean()))
    return r

def validate(q,f,distance,rng):
    checked=[]
    for flat in rng.choice(q.shape[0]*54,100,replace=False):
        b,a=divmod(int(flat),54);legal=np.flatnonzero(distance[a]>1)
        i,j=np.triu_indices(len(legal),1);pairs=np.stack([legal[i],legal[j]],axis=1)
        pairs=pairs[distance[pairs[:,0],pairs[:,1]]>1]
        mask=(distance[a][None,:]>1)&(distance[pairs[:,0]]>1)&(distance[pairs[:,1]]>1)
        brute=np.where(mask,q[b,a],-np.inf).max(1).min()
        assert abs(brute-f[b,a,1])<1e-8
        b1,b2,d=f[b,a,3:6].astype(int)
        assert distance[a,b1]>1 and distance[a,b2]>1 and distance[b1,b2]>1
        assert distance[a,d]>1 and distance[b1,d]>1 and distance[b2,d]>1
        assert abs(q[b,a,d]-brute)<1e-8
        checked.append(dict(board=b,a1=a,pairs=len(pairs)))
    return dict(cases=len(checked),all_exact=True,minimum_pairs=min(x['pairs'] for x in checked))

def regression_specs():
    local=model_specs()['resource_coverage'];full=model_specs()['board_scarcity']
    optimistic=[o+'_optimistic' for o in OBJECTIVES]
    robust=[o+'_worst' for o in OBJECTIVES]
    backup=[o+'_near_best_count' for o in OBJECTIVES]
    return dict(local=local,local_optimistic=local+optimistic,local_robust=local+robust,
      local_both=local+optimistic+robust,full=full,full_optimistic=full+optimistic,
      full_robust=full+robust,full_both=full+optimistic+robust,full_both_backups=full+optimistic+robust+backup,
      full_production_optimistic=full+optimistic[:2],full_production_both=full+optimistic[:2]+robust[:2])

def build_matrix(shard,manifest,geometry,features,union):
    base=list(dict.fromkeys(model_specs()['resource_coverage']+model_specs()['board_scarcity']))
    d=stage_data(shard,0,manifest['feature_names'],base,geometry)
    columns={k:d['x'][:,i] for i,k in enumerate(base)}
    own_rp=d['rp'].reshape(-1,54,5)
    weight=np.array([coefficients()['weighted_pips'][r+'_pips'] for r in ['wood','brick','sheep','wheat','ore']])
    for j,o in enumerate(OBJECTIVES):
        for k,f in enumerate(FIELDS):
            v=features[:,j,:,k]
            # The existing regressors already contain A1 production. Add
            # only the *future* A2 production, avoiding redundant own-score
            # components that alter the geometry of the ridge penalty.
            if f in ('optimistic','worst') and o in ('pips','weighted_pips'):
                v=v-(own_rp.sum(2) if o=='pips' else own_rp@weight)
            columns[o+'_'+f]=(v-v.mean(1)[:,None]).reshape(-1)
    return d,np.column_stack([columns[k] for k in union])

def main(source=SOURCE,out=OUT,max_shards=None):
    start=time.monotonic();out.mkdir(parents=True,exist_ok=True);cache=out/'cache';cache.mkdir(exist_ok=True)
    manifest=json.loads((source/'manifest.json').read_text());paths=[source/s['path'] for s in manifest['shards']]
    if max_shards:paths=paths[:max_shards]
    co=coefficients(source);geometry,distance=geometry_data();adj=np.array([len([h for h in hs if h is not None and h>=0]) for hs in geometry['vertex_hexes']])
    closed=np.array([sum(1<<j for j in np.flatnonzero(row<=1)) for row in distance],np.uint64)
    solve=make_solver(out);specs=regression_specs();union=list(dict.fromkeys(x for cols in specs.values() for x in cols));dim=len(union)
    cov=np.zeros((dim,dim));rhs=np.zeros(dim);ntrain=0;records=[];validations={};examples=[]
    for si,path in enumerate(paths):
        shard=load(path);rp=all_rp(shard);n=len(rp);idx=np.arange(n);choice=shard['chosen_vertices'][:,0]
        ds=stage_data(shard,0,manifest['feature_names'],model_specs()['resource_coverage'],geometry)
        local=(ds['x']@np.array([co['local'][k] for k in model_specs()['resource_coverage']])).reshape(n,54)
        localchoice=local.argmax(1)
        dense=np.empty((n,3,54,8));actual=np.empty((n,3,8));objective_choices=np.empty((n,3,2),np.int16)
        for j,o in enumerate(OBJECTIVES):
            q=pair_utility(rp,adj,o,co.get(o));threshold=float(np.mean(list(co['weighted_pips'].values()))) if o=='weighted_pips' else 1.
            cachepath=cache/path.name
            f=load(cachepath)['features'][:,j] if cachepath.exists() else solve(q,closed,threshold)
            dense[:,j]=f
            if si==0:validations[o]=validate(q,f,distance,np.random.default_rng(143700+j))
            ideal=f[idx,choice,0];qselected=q[idx,choice]
            before=distance[choice]>1
            b1=shard['chosen_vertices'][:,1];b2=shard['chosen_vertices'][:,2];a2=shard['chosen_vertices'][:,3]
            after=before&(distance[b1]>1)&(distance[b2]>1)
            afterbest=np.where(after,qselected,-np.inf).max(1)
            afterbestv=np.where(after,qselected,-np.inf).argmax(1)
            # Competition rank: 1 plus the number of strictly better pre-B candidates.
            rank=1+((qselected>afterbest[:,None]+1e-9)&before).sum(1)
            actual[:,j]=np.column_stack([ideal,afterbest,np.isclose(ideal,afterbest,rtol=0,atol=1e-9),rank,
              qselected[idx,a2],afterbest-qselected[idx,a2],f[idx,choice,1],afterbestv])
            objective_choices[:,j,0]=f[:,:,0].argmax(1);objective_choices[:,j,1]=f[:,:,1].argmax(1)
        np.savez_compressed(cache/path.name,features=dense)
        d,x=build_matrix(shard,manifest,geometry,dense,union);w=d['train'][d['group']]/54
        cov+=x.T@(x*w[:,None]);rhs+=x.T@(d['y']*w);ntrain+=int(d['train'].sum())
        records.append(dict(seed=shard['board_seed'],train=shard['train'],chosen=choice,local_choice=localchoice,
          local_score_chosen=local[idx,choice],local_score_best=local[idx,localchoice],
          total_pips_chosen=rp.sum(2)[idx,choice],total_pips_local=rp.sum(2)[idx,localchoice],
          chosen_features=dense[idx,:,choice,:],local_features=dense[idx,:,localchoice,:],
          oracle_worst=dense[:,:,:,1].max(2),oracle_optimistic=dense[:,:,:,0].max(2),actual=actual,
          objective_choices=objective_choices))
        if si%10==0 or si==len(paths)-1:print(f'Exact features {si+1}/{len(paths)} {time.monotonic()-start:.1f}s',flush=True)
    allrec={k:np.concatenate([x[k] for x in records]) for k in records[0]};np.savez_compressed(out/'board-diagnostics.npz',**allrec)
    fits={}
    for name,cols in specs.items():
        ix=np.array([union.index(k) for k in cols]);fit=fit_moments(cov[np.ix_(ix,ix)]/ntrain,rhs[ix]/ntrain,cols)
        fit.update(ix=ix,errors=[],agreement=[],coefficients=dict(zip(cols,fit['raw'].tolist())));fits[name]=fit
    targets=[]
    for si,path in enumerate(paths):
        shard=load(path);f=load(cache/path.name)['features'];d,x=build_matrix(shard,manifest,geometry,f,union);test=~d['train']
        targets.append(d['target'][test])
        for name,fit in fits.items():
            pred=(x[:,fit['ix']]@fit['raw']).reshape(-1,54);err=((d['y'].reshape(-1,54)-pred)**2).mean(1)
            fit['errors'].append(err[test]);fit['agreement'].append((pred.argmax(1)==d['chosen'])[test])
        if si%20==0 or si==len(paths)-1:print(f'Held-out evaluation {si+1}/{len(paths)} {time.monotonic()-start:.1f}s',flush=True)
    target=np.concatenate(targets);modelresults={}
    for name,fit in fits.items():
        fit['errors']=np.concatenate(fit['errors']);r,ci=r2_stats(fit['errors'],target)
        modelresults[name]=dict(r2=r,r2_ci95=ci,choice_agreement=mean_ci(np.concatenate(fit['agreement'])),coefficients=fit['coefficients'])
    comparison_pairs=[('local','local_optimistic'),('local','local_robust'),('local_optimistic','local_both'),('local_robust','local_both'),
      ('full','full_optimistic'),('full','full_robust'),('full_optimistic','full_both'),('full_robust','full_both'),('full_both','full_both_backups'),
      ('full','full_production_optimistic'),('full_production_optimistic','full_production_both')]
    comparisons=[dict(reduced=a,full=b,**paired(fits[a]['errors'],fits[b]['errors'],target)) for a,b in comparison_pairs]
    order=np.argsort([c['p'] for c in comparisons]);running=0
    for rank,ix in enumerate(order):running=max(running,(len(order)-rank)*comparisons[ix]['p']);comparisons[ix]['holm_p']=min(1.,running)
    summaries={}
    for split,mask in [('all',np.ones(len(allrec['seed']),bool)),('heldout',~allrec['train'])]:
        cf=allrec['chosen_features'][mask];lf=allrec['local_features'][mask];aa=allrec['actual'][mask]
        differs=allrec['chosen'][mask]!=allrec['local_choice'][mask]
        sacrifice=allrec['local_score_best'][mask]-allrec['local_score_chosen'][mask]
        summary=dict(boards=int(mask.sum()),differs_from_local=mean_ci(differs),local_score_sacrifice=mean_ci(sacrifice),
          total_pip_sacrifice_vs_local=mean_ci(allrec['total_pips_local'][mask]-allrec['total_pips_chosen'][mask]),objectives={})
        for j,o in enumerate(OBJECTIVES):
            gain=cf[:,j,1]-lf[:,j,1];optimistic_gain=cf[:,j,0]-lf[:,j,0];
            s=dict(chosen_worst=mean_ci(cf[:,j,1]),local_worst=mean_ci(lf[:,j,1]),worst_gain_over_local=mean_ci(gain),
              chosen_optimistic=mean_ci(cf[:,j,0]),local_optimistic=mean_ci(lf[:,j,0]),optimistic_gain_over_local=mean_ci(optimistic_gain),
              chosen_matches_worst_optimum=mean_ci(np.isclose(cf[:,j,1],allrec['oracle_worst'][mask,j],rtol=0,atol=1e-9)),
              local_matches_worst_optimum=mean_ci(np.isclose(lf[:,j,1],allrec['oracle_worst'][mask,j],rtol=0,atol=1e-9)),
              chosen_worst_regret=mean_ci(allrec['oracle_worst'][mask,j]-cf[:,j,1]),local_worst_regret=mean_ci(allrec['oracle_worst'][mask,j]-lf[:,j,1]),
              local_sacrifice_with_worst_gain=mean_ci((sacrifice>1e-9)&(gain>1e-9)),
              on_differing_boards=dict(n=int(differs.sum()),worst_gain=mean_ci(gain[differs]),wins=mean_ci((gain>1e-9)[differs]),ties=mean_ci((np.abs(gain)<=1e-9)[differs])),
              ideal_complement_survives_recorded_B=mean_ci(aa[:,j,2]),best_remaining_rank_after_B=mean_ci(aa[:,j,3]),
              loss_after_recorded_B=mean_ci(aa[:,j,0]-aa[:,j,1]),worst_case_loss=mean_ci(cf[:,j,0]-cf[:,j,1]),
              actual_A2_regret_vs_best_available=mean_ci(aa[:,j,5]),near_best_locations=mean_ci(cf[:,j,6]),worst_survivor_rank=mean_ci(cf[:,j,7]),
              recorded_B_worst_gap=mean_ci(aa[:,j,1]-aa[:,j,6]))
            summary['objectives'][o]=s
        summaries[split]=summary
    result=dict(schema='opening-anticipation-portfolios-v1',boards=len(allrec['seed']),train_boards=ntrain,test_boards=len(target),
      source=str(source),source_manifest_sha256=hashlib.sha256((source/'manifest.json').read_bytes()).hexdigest(),
      analysis_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),coefficients=co,validation=validations,
      objectives={
       'pips':'Total pips of A1 and A2; ignores resource mix, ports, numbers and game value.',
       'weighted_pips':'Total resource pips of A1 and A2 weighted by the frozen A1 resource-only regression; logit-scale production proxy, not game value.',
       'a2_preference':'Fixed training-only A2 coverage-regression score, with the unidentifiable A1-specific intercept set to zero. Cross-A1 comparisons depend on this convention and cannot establish state value.'},
      near_best_thresholds=dict(pips=1,weighted_pips=float(np.mean(list(co['weighted_pips'].values()))),a2_preference=1),
      regression_feature_convention='For production objectives, added optimistic/worst features contain A2 production only; A1 production is already controlled. Descriptive objective comparisons retain combined A1+A2 production.',
      models=modelresults,comparisons=comparisons,summaries=summaries,elapsed_seconds=time.monotonic()-start,
      limitations=['Worst replies minimize A future-site proxy rather than maximizing B win probability.',
       'Only settlement legality is enumerated; roads are immaterial to setup settlement legality but matter to game value.',
       'Recorded B responses apply only to the actual chosen A1; no counterfactual opponent inference is made for alternative A1.',
       'No neuron tracing or proof of explicit search/computation inside the frozen policy.',
       'Paired test boards are independent; candidate corners within a board are not treated as independent samples.',
       'Intervals describe board sampling conditional on fixed training fits; they omit training-set/model uncertainty.'])
    atomic_json(out/'results.json',result)
    np.savez_compressed(out/'heldout-errors.npz',target=target,**{k:v['errors'] for k,v in fits.items()})
    print(json.dumps(dict(done=True,seconds=result['elapsed_seconds'],output=str(out/'results.json'))),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=SOURCE);p.add_argument('--out',type=Path,default=OUT);p.add_argument('--max-shards',type=int)
    a=p.parse_args();main(a.source,a.out,a.max_shards)
