#!/usr/bin/env python3
"""Distant swaps change worst-reply production while preserving optimistic scores.

Frozen A1 resource coefficients define a transparent production-quality proxy.
Neither that proxy nor its exact minimax is the value of playing Catan.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np
import torch
import catan_rl

from opening_engine import OpeningEngine, MODEL_PATH, MODEL_SHA
from feature_dictionary import geometry_data
from train import split_obs
from opening_study_scale_analysis import atomic_json, interval_mean

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'run/analysis/opening-study-100k-20261029'
OUT=ROOT/'run/analysis/opening-anticipation-20261102/remote'
PIPS=np.array([0,0,1,2,3,4,5,0,5,4,3,2,1])


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def summary(x,strata=None):
    x=np.asarray(x,float);mean,ci=interval_mean(x)
    if strata is not None and len(np.unique(strata))==2:
        groups=[x[np.asarray(strata)==s] for s in np.unique(strata)]
        assert len(groups[0])==len(groups[1])
        se=np.sqrt(sum(g.var(ddof=1)/len(g) for g in groups)/4)
        ci=[float(mean-1.959963984540054*se),float(mean+1.959963984540054*se)]
    return dict(n=len(x),mean=mean,ci95=ci)


def replies(q,a,distance):
    """Exact min over B1/B2, max over surviving A2; at most16 blocker pairs."""
    legal=distance[a]>1
    order=np.lexsort((np.arange(54),-q));order=order[legal[order]]
    optimistic=float(q[a]+q[order[0]])
    worst=float('inf');witness=None
    for b1 in np.flatnonzero(legal & (distance[order[0]]<=1)):
        surviving=order[distance[b1,order]>1]
        for b2 in np.flatnonzero(legal & (distance[b1]>1) & (distance[surviving[0]]<=1)):
            d=int(surviving[distance[b2,surviving]>1][0]);value=float(q[a]+q[d])
            if value<worst-1e-10:
                worst=value;witness=[int(b1),int(b2),d]
    assert witness is not None
    return optimistic,worst,witness


def exhaustive(q,a,distance):
    legal=np.flatnonzero(distance[a]>1)
    pairs=np.array([(b,c) for i,b in enumerate(legal) for c in legal[i+1:] if distance[b,c]>1])
    remaining=(distance[a][None,:]>1)&(distance[pairs[:,0]]>1)&(distance[pairs[:,1]]>1)
    return float(q[a]+np.where(remaining,q,-np.inf).max(1).min())


def screen(out,count=500):
    started=time.monotonic();geometry,distance=geometry_data()
    incidence=np.zeros((54,19))
    for v,hexes in enumerate(geometry['vertex_hexes']):
        for h in hexes:
            if h is not None and h>=0:incidence[v,h]=1
    report=json.loads((SOURCE/'analysis/results.json').read_text())
    weights=np.array([c['coefficient'] for c in report['stages'][0]['models']['resource_pips']['coefficients']])
    assert len(weights)==5
    manifest=json.loads((SOURCE/'manifest.json').read_text())
    rng=np.random.default_rng(14110237)
    allrows=[]
    for entry in manifest['shards']:
        with np.load(SOURCE/entry['path'],allow_pickle=False) as shard:
            for i in np.flatnonzero(~shard['train']):
                start,end=shard['position_ptr'][4*i:4*i+2]
                z=shard['candidate_logit'][start:end]
                vertices=shard['candidate_vertex'][start:end]
                assert np.array_equal(vertices,np.arange(54))
                order=np.lexsort((vertices,-z));a,b=map(int,order[:2])
                allrows.append(dict(seed=int(shard['board_seed'][i]),board=[shard[k][i].astype(int).tolist() for k in ['board_resources','board_numbers','board_ports']],a=a,b=b,source_margin=float(z[a]-z[b])))
    assert len(allrows)==20000
    selected=[];validation=[];eligible_signs=[0,0];scanned=0
    for index in rng.permutation(len(allrows)):
        row=allrows[int(index)];scanned+=1
        resources,numbers,ports=map(np.array,row['board'])
        rp=incidence@(np.eye(6)[resources,:5]*PIPS[numbers,None])
        q=rp@weights;a=row['a'];b=row['b']
        before=[replies(q,x,distance) for x in [a,b]]
        available=np.flatnonzero((incidence[a]==0)&(incidence[b]==0))
        variants=[]
        for ii,h in enumerate(available):
            for k in available[ii+1:]:
                if numbers[h]!=numbers[k] or resources[h]==resources[k] or numbers[h]==0:continue
                donor=resources.copy();donor[h],donor[k]=donor[k],donor[h]
                donor_rp=incidence@(np.eye(6)[donor,:5]*PIPS[numbers,None])
                donor_q=donor_rp@weights
                after=[replies(donor_q,x,distance) for x in [a,b]]
                optimistic_delta=(after[0][0]-after[1][0])-(before[0][0]-before[1][0])
                # Stronger control: preserve each focal optimistic score individually.
                if max(abs(after[j][0]-before[j][0]) for j in range(2))>1e-9:continue
                robust_delta=(after[0][1]-after[1][1])-(before[0][1]-before[1][1])
                if abs(robust_delta)<.1:continue
                variants.append((abs(robust_delta),-int(h),-int(k),int(h),int(k),donor.tolist(),after,robust_delta))
        if variants:
            _,_,_,h,k,donor,after,robust_delta=max(variants,key=lambda v:v[:3])
            # Balance the direction of the manipulated proxy margin; avoids a
            # result dominated by interventions that always hurt the original favorite.
            side=int(robust_delta>0);eligible_signs[side]+=1
            if sum(r['robust_margin_change']>0 for r in selected) >= count//2 and side:continue
            if sum(r['robust_margin_change']<0 for r in selected) >= count//2 and not side:continue
            selected.append(dict(**row,swap=[h,k],donor_board=[donor,numbers.tolist(),ports.tolist()],
                source_optimistic=[r[0] for r in before],donor_optimistic=[r[0] for r in after],
                source_worst=[r[1] for r in before],donor_worst=[r[1] for r in after],
                source_witnesses=[r[2] for r in before],donor_witnesses=[r[2] for r in after],
                robust_margin_change=float(robust_delta)))
            if len(validation)<40:
                dq=(incidence@(np.eye(6)[donor,:5]*PIPS[numbers,None]))@weights
                for j,x in enumerate([a,b]):
                    assert abs(exhaustive(q,x,distance)-before[j][1])<1e-9
                    assert abs(exhaustive(dq,x,distance)-after[j][1])<1e-9
                validation.append(row['seed'])
        if len(selected)>=count:break
        if scanned%2000==0:print(f'screened {scanned}, selected {len(selected)} ({time.monotonic()-started:.1f}s)',flush=True)
    assert len(selected)==count,(scanned,len(selected),eligible_signs)
    data=dict(schema='opening-remote-fixed-optimism-v1',pairs=selected,screened=scanned,
        sample=count,selection_seed=14110237,eligible_signs_seen=eligible_signs,
        weights=weights.tolist(),weight_source='A1 five-resource regression; fitted only on original80k trainingboards',
        validation=dict(exhaustive_boards=len(validation),exhaustive_objectives=len(validation)*4),
        methods=dict(utility='sum_r beta_A1,r * (pips_A1,r + pips_A2,r); a production-quality proxy, not game value.',
          intervention='Swap different resources on equal-number tiles touching neither original top-two A1 candidates. Each focal optimistic pair score exactly unchanged. Relative worst-reply score changes by at least0.1 proxy units.',
          selection='Fixed random permutation of existing20k heldout boards; per board maximize absolute proxy-margin change, tile-ID tie breaks; select250 positive and250 negative proxy changes, with no donor-network evaluation during selection. Source top-two candidates are network-defined.',
          limitation='Remote swaps also change opponent opportunities and other global context. Alignment with this proxy does not identify a minimax algorithm. Direction balancing makes the sample diagnostic, not prevalence-representative.'),
        provenance=dict(checkpoint_sha256=MODEL_SHA,manifest_sha256=sha(SOURCE/'manifest.json'),regression_results_sha256=sha(SOURCE/'analysis/results.json')),
        screen_seconds=time.monotonic()-started)
    atomic_json(out/'pairs.json',data);return data


@torch.inference_mode()
def evaluate(out,data,batch=64):
    started=time.monotonic();torch.set_num_threads(1);engine=OpeningEngine();model=engine.model
    assert sha(MODEL_PATH)==MODEL_SHA
    rows=data['pairs'];obs=[];checks=dict(focal_vertex_max_error=0.,focal_hex_max_error=0.,all_path_max_error=0.,global_max_error=0.,native_states=0)
    geometry,_=geometry_data()
    for row in rows:
        pair=[]
        for board in [row['board'],row['donor_board']]:
            game=catan_rl.Game.from_opening(*board,[])
            np.testing.assert_array_equal(game.legal(),np.arange(72,126))
            pair.append(game.opening_observation());checks['native_states']+=1
        a,b=[split_obs(torch.from_numpy(o)) for o in pair]
        for key,x,y in [('focal_vertex_max_error',a[1][:,[row['a'],row['b']]],b[1][:,[row['a'],row['b']]]),
            ('focal_hex_max_error',a[0][:,sorted({h for v in [row['a'],row['b']] for h in geometry['vertex_hexes'][v] if h is not None and h>=0})],b[0][:,sorted({h for v in [row['a'],row['b']] for h in geometry['vertex_hexes'][v] if h is not None and h>=0})]),
            ('all_path_max_error',a[2],b[2]),('global_max_error',a[3],b[3])]:
            checks[key]=max(checks[key],float(torch.max(torch.abs(x-y))))
            assert checks[key]==0,(key,checks[key])
        obs.extend(pair)
    results=[]
    for start in range(0,len(obs),batch):
        z,_=model(*split_obs(torch.from_numpy(np.concatenate(obs[start:start+batch]))))
        results.append(z[:,72:126].numpy().copy())
    scores=np.concatenate(results).reshape(len(rows),2,54).astype(float)
    for i,row in enumerate(rows):
        a,b=row['a'],row['b']
        row['source_logit_margin']=float(scores[i,0,a]-scores[i,0,b])
        row['donor_logit_margin']=float(scores[i,1,a]-scores[i,1,b])
        row['logit_margin_change']=row['donor_logit_margin']-row['source_logit_margin']
        row['source_choice']=int(np.argmax(scores[i,0]));row['donor_choice']=int(np.argmax(scores[i,1]))
        assert abs(row['source_logit_margin']-row['source_margin'])<2e-4
    delta=np.array([r['logit_margin_change'] for r in rows]);proxy=np.array([r['robust_margin_change'] for r in rows])
    groups={}
    for label,mask in [('all',np.ones(len(rows),bool)),('proxy_favors_original_favorite',proxy>0),('proxy_favors_original_runner_up',proxy<0)]:
        groups[label]=dict(aligned_fraction=summary((delta[mask]*proxy[mask])>0,np.sign(proxy[mask])),
            signed_logit_change=summary(delta[mask]*np.sign(proxy[mask]),np.sign(proxy[mask])),
            absolute_logit_change=summary(abs(delta[mask]),np.sign(proxy[mask])))
    corr=float(np.corrcoef(delta,proxy)[0,1])
    report=dict(schema='opening-remote-fixed-optimism-results-v1',sample=len(rows),results=groups,
        focal_ranking_reversed=summary([r['donor_logit_margin']<0 for r in rows],np.sign(proxy)),
        any_greedy_choice_changed=summary([r['donor_choice']!=r['source_choice'] for r in rows],np.sign(proxy)),
        proxy_change_logit_change_pearson=corr,proxy_change_logit_change_r2=corr*corr,
        validation={**data['validation'],**checks},
        methods={**data['methods'],'uncertainty':'Normal95% intervals for conditional selected-board means; overall means use equal-weight direction strata and stratified standard errors.'},
        weights=data['weights'],screened=data['screened'],
        provenance={**data['provenance'],'script_sha256':sha(__file__)},evaluation_seconds=time.monotonic()-started)
    atomic_json(out/'scored-pairs.json',rows);atomic_json(out/'results.json',report)
    np.savez_compressed(out/'scores.npz',scores=scores,seed=np.array([r['seed'] for r in rows]))
    print(json.dumps(report,indent=2));return report


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--count',type=int,default=500);p.add_argument('--reuse-pairs',action='store_true');p.add_argument('--out',type=Path,default=OUT);args=p.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    data=json.loads((args.out/'pairs.json').read_text()) if args.reuse_pairs else screen(args.out,args.count)
    evaluate(args.out,data)
