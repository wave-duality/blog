//! Read-only sequential replay and information-safe observation extraction.
use std::io::{Read, Write, BufReader, BufWriter};
use catan::{Board, State, Phase, Observation, Rng, encode, legal_mask};
use catan::policy_training::replay_step;
use catan::search::PlayerView;
use catan::selfplay::Step;

fn bytes<const N: usize>(r: &mut impl Read) -> [u8; N] {
    let mut b = [0; N]; r.read_exact(&mut b).unwrap(); b
}
fn flat(o: &Observation) -> Vec<f32> {
    o.hex.iter().flatten().chain(o.vertex.iter().flatten())
        .chain(o.path.iter().flatten()).chain(o.global.iter()).copied().collect()
}
fn main() {
    let args: Vec<String> = std::env::args().collect();
    assert_eq!(args.len(), 3);
    let mut input = BufReader::new(std::fs::File::open(&args[1]).unwrap());
    let mut output = BufWriter::new(std::io::stdout().lock());
    let mut games_out = BufWriter::new(std::fs::File::create(&args[2]).unwrap());
    let games = u32::from_le_bytes(bytes(&mut input));
    let mut emitted = 0;
    for _ in 0..games {
        let seed = u64::from_le_bytes(bytes(&mut input));
        let board = Board::assemble(bytes(&mut input), bytes(&mut input), bytes(&mut input));
        let outcome = bytes::<1>(&mut input)[0] as i8;
        let terminal_turn = u16::from_le_bytes(bytes(&mut input));
        let steps = u32::from_le_bytes(bytes(&mut input));
        let mut state = State::new(&board);
        let mut candidates = Vec::new();
        let mut previous_turn = None;
        for history_index in 0..steps {
            let kind = bytes::<1>(&mut input)[0];
            let value = u16::from_le_bytes(bytes(&mut input));
            assert!(!state.is_terminal());
            if kind == 1 && state.phase == Phase::Play
                && previous_turn != Some(state.turn_number) && legal_mask(&board, &state).count() > 1 {
                candidates.push((history_index, state));
                previous_turn = Some(state.turn_number);
            }
            let step = if kind == 0 {
                assert!(value <= 255); Step::Chance(value as u8)
            } else {
                assert_eq!(kind, 1); Step::Action { index: value, policy: vec![], root_value: 0. }
            };
            state = replay_step(&board, &state, &step);
        }
        assert!(state.is_terminal());
        assert_eq!(state.reward(0) as i8, outcome);
        assert_eq!(state.turn_number, terminal_turn);
        let n = candidates.len().min(16);
        writeln!(games_out, "{{\"seed\":{seed},\"eligible_turns\":{},\"selected\":{n},\"terminal_turn\":{terminal_turn},\"outcome\":{outcome}}}", candidates.len()).unwrap();
        for i in 0..n {
            let (history_index, s) = candidates[i * candidates.len() / n];
            assert_eq!(s.current_player, s.to_act);
            let view = PlayerView::from_state(&s);
            let world = view.sample(&mut Rng::new(seed ^ u64::from(history_index)));
            let mut obs = Observation::default(); encode(&board, &world, &mut obs);
            let x = flat(&obs);
            // Independent hidden-world and referee encodings must be identical.
            let other = view.sample(&mut Rng::new(seed ^ 0xA617 ^ u64::from(history_index)));
            let mut check = Observation::default(); encode(&board, &other, &mut check);
            assert_eq!(x, flat(&check));
            encode(&board, &s, &mut check); assert_eq!(x, flat(&check));
            assert_eq!(x.len(), 4752);
            output.write_all(&seed.to_le_bytes()).unwrap();
            output.write_all(&s.turn_number.to_le_bytes()).unwrap();
            let actor_won = (outcome == 1 && s.to_act == 0) || (outcome == -1 && s.to_act == 1);
            output.write_all(&[s.to_act, u8::from(actor_won)]).unwrap();
            output.write_all(&history_index.to_le_bytes()).unwrap();
            output.write_all(&(legal_mask(&board, &s).count() as u16).to_le_bytes()).unwrap();
            output.write_all(&(candidates.len() as u16).to_le_bytes()).unwrap();
            for v in x { output.write_all(&v.to_le_bytes()).unwrap(); }
            emitted += 1;
        }
    }
    output.flush().unwrap(); games_out.flush().unwrap();
    eprintln!("Replayed {games} complete games; exported {emitted} positions; all terminal and encoder checks passed.");
}
