#!/usr/bin/env python3
"""Replay existing Gen37 controls and evaluate fixed, outcome-blind turn samples.

Run with repository .venv/bin/python; no new games, search, or model fitting.
The isolated native helper streams observations so no large observation file is
written. Retained arrays contain predictions and replay metadata only.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time

for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
            "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"
import numpy as np
import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(ROOT))
import catan_rl
from train import load_model, split_obs

EXPECTED_SHA = "fbc5209b17a14a1d7b649087efdb1503185c7dfab9d9f5b443d0957431272158"
SOURCE = ROOT / "run/analysis/opening-baseline-10k-20261105/main"
MODEL = ROOT / "run/scale/gen37.pt"
BOOT_SEED = 2026111038
DTYPE = np.dtype([("seed", "<u8"), ("turn", "<u2"), ("actor", "u1"),
                  ("actor_won", "u1"), ("history_index", "<u4"),
                  ("legal_count", "<u2"), ("eligible_turns", "<u2"),
                  ("observation", "<f4", (4752,))])

def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")

def prepare(out, limit):
    protocol = json.loads((SOURCE / "protocol.json").read_text())
    protocol_sha = sha(SOURCE / "protocol.json")
    assert protocol["boards"] == 10000 and protocol["model_sha256"] == EXPECTED_SHA
    manifest = []; seeds = []; outcomes = []; checks = {}; board_keys = set()
    duplicate_checks = 0
    binary = out / "controls.bin"
    with binary.open("wb") as f:
        f.write(struct.pack("<I", 0))
        for path in sorted(SOURCE.glob("chunk-*.json")):
            raw = path.read_bytes(); chunk = json.loads(raw)
            assert chunk["model_sha256"] == EXPECTED_SHA and chunk["protocol_sha256"] == protocol_sha
            manifest.append({"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()})
            by = {}
            for row in chunk["rows"]:
                if row["rule"] == "network":
                    by.setdefault(row["seed"], {})[row["tested_seat"]] = row
            for seed, pair in sorted(by.items()):
                if limit and len(seeds) >= limit:
                    break
                assert set(pair) == {0, 1}
                a, b = pair[0], pair[1]
                assert a["history"] == b["history"] and a["outcome"] == b["outcome"]
                assert a["board"] == b["board"] and a["terminal"] and b["terminal"]
                assert a["outcome"] in (-1, 1)
                assert a["won"] == (a["outcome"] == 1) and b["won"] == (a["outcome"] == -1)
                key = bytes(sum(a["board"], []))
                assert len(key) == 47 and key not in board_keys
                board_keys.add(key); duplicate_checks += 1
                seeds.append(seed); outcomes.append(a["outcome"])
                f.write(struct.pack("<Q", seed)); f.write(key)
                f.write(struct.pack("<bHI", a["outcome"], a["turn"], len(a["history"])))
                for kind, value in a["history"]:
                    f.write(struct.pack("<BH", kind, value))
                if seed % 100 == 0 or len(seeds) <= 4:
                    checks[seed] = a
            if limit and len(seeds) >= limit:
                break
        f.seek(0); f.write(struct.pack("<I", len(seeds)))
    assert len(set(seeds)) == len(seeds)
    if not limit:
        assert seeds == list(range(protocol["seed_start"], protocol["seed_end"]+1))
        assert len(seeds) == 10000 and sum(x == 1 for x in outcomes) == 5475
    return binary, np.array(seeds), np.array(outcomes), checks, {
        "source_protocol_sha256": protocol_sha, "source_chunks": manifest,
        "unique_games": len(seeds), "distinct_board_arrays": len(board_keys),
        "duplicate_control_history_and_outcome_checks": duplicate_checks,
        "compact_control_input_sha256": sha(binary)}

@torch.inference_mode()
def evaluate(out, binary, seeds, outcomes, references, batch):
    model = load_model(MODEL).eval(); bot = catan_rl.Bot(sims=0)
    assert bot.search_mode == "public-determinization-v1"
    executable = HERE / "native/target/release/midgame_calibration_export"
    native_log = (out / "native-replay.log").open("w")
    process = subprocess.Popen([str(executable), str(binary), str(out / "replay-games.jsonl")],
                               stdout=subprocess.PIPE, stderr=native_log)
    columns = {name: [] for name in DTYPE.names if name != "observation"}
    values = []; checked = set(); seen = {}; encoder_error = 0.; single_error = 0.
    start = time.monotonic(); total = 0; next_update = 16000
    try:
        while True:
            raw = process.stdout.read(batch * DTYPE.itemsize)
            if not raw:
                break
            assert len(raw) % DTYPE.itemsize == 0
            records = np.frombuffer(raw, dtype=DTYPE)
            observations = np.array(records["observation"], dtype=np.float32, copy=True)
            _, predicted = model(*split_obs(torch.from_numpy(observations)))
            v = predicted.cpu().numpy().reshape(-1)
            assert np.isfinite(v).all() and np.max(np.abs(v)) <= 1.000001
            values.append(v.copy())
            for key in columns:
                columns[key].append(records[key].copy())
            for i, row in enumerate(records):
                seed = int(row["seed"]); ordinal = seen.get(seed, 0); seen[seed] = ordinal + 1
                if seed in references and seed not in checked and ordinal == seed % 16:
                    ref = references[seed]
                    obs, actor = bot.value_observations(*ref["board"],
                        [tuple(s) for s in ref["history"][:int(row["history_index"])]], int(row["actor"]))
                    assert actor == row["actor"] and obs.shape == (1, 4752)
                    encoder_error = max(encoder_error, float(np.max(np.abs(obs[0]-observations[i]))))
                    assert encoder_error == 0.
                    checked.add(seed)
                if total+i < 4:
                    _, single = model(*split_obs(torch.from_numpy(observations[i:i+1])))
                    single_error = max(single_error, abs(float(single.item())-float(v[i])))
            total += len(records)
            if total >= next_update:
                print(f"Evaluated {total:,} sampled positions from {len(seen):,} games in {time.monotonic()-start:.1f}s", flush=True)
                next_update += 16000
        assert process.wait() == 0
    finally:
        process.stdout.close(); native_log.close()
        if process.poll() is None:
            process.terminate(); process.wait()
    data = {key: np.concatenate(parts) for key, parts in columns.items()}
    data["raw_value"] = np.concatenate(values)
    data["p_actor_win"] = (1+data["raw_value"].astype(np.float64))/2
    game_rows = [json.loads(line) for line in (out / "replay-games.jsonl").read_text().splitlines()]
    assert [r["seed"] for r in game_rows] == seeds.tolist()
    assert [r["outcome"] for r in game_rows] == outcomes.tolist()
    assert sum(r["selected"] for r in game_rows) == total
    assert all(r["selected"] > 0 for r in game_rows), "Report missing games; do not silently drop them."
    unique, index, counts = np.unique(data["seed"], return_inverse=True, return_counts=True)
    assert np.array_equal(unique, seeds)
    assert (counts <= 16).all()
    assert len(set(zip(data["seed"].tolist(), data["turn"].tolist()))) == total
    labels = ((outcomes[index] == 1) == (data["actor"] == 0)).astype(np.uint8)
    np.testing.assert_array_equal(labels, data["actor_won"])
    assert (data["legal_count"] > 1).all() and single_error < 1e-5
    data["game_index"] = index
    np.savez_compressed(out / "per-position.npz", **data)
    validation = {"all_saved_histories_legally_replayed": True,
        "all_10000_terminal_results_checked": len(game_rows) == 10000,
        "terminal_result_checks": len(game_rows), "terminal_turn_checks": len(game_rows),
        "unique_seed_turn_pairs": total, "information_boundary_checks": total,
        "each_encoding_equal_across_two_PlayerView_samples_and_referee": True,
        "native_vs_python_actor_view_checks": len(checked),
        "native_vs_python_max_absolute_observation_error": encoder_error,
        "single_vs_batch_value_max_absolute_error": single_error,
        "inference_seconds": time.monotonic()-start}
    return data, game_rows, validation

def summarize(out, data, game_rows, reps):
    gi = data["game_index"]; n = len(game_rows)
    counts = np.bincount(gi, minlength=n)
    w = 1/counts[gi]
    p = data["p_actor_win"]; y = data["actor_won"].astype(float)
    # Each game has total weight one, regardless of its selected-turn count.
    def game_mean(x): return np.bincount(gi, weights=w*x, minlength=n)
    py = game_mean(y); pp = game_mean(p); loss = game_mean((p-y)**2)
    residual = py-pp; q = float(py.mean())
    fitted_baseline = game_mean((y-q)**2)
    loo_q = (py.sum()-py)/(n-1)
    loo_baseline = py*(1-2*loo_q)+loo_q**2
    bands = np.minimum((p*10).astype(int), 9)
    band_weight = np.zeros((n, 10)); band_pred = np.zeros((n, 10)); band_y = np.zeros((n, 10))
    for band in range(10):
        mask = bands == band
        band_weight[:, band] = np.bincount(gi[mask], weights=w[mask], minlength=n)
        band_pred[:, band] = np.bincount(gi[mask], weights=w[mask]*p[mask], minlength=n)
        band_y[:, band] = np.bincount(gi[mask], weights=w[mask]*y[mask], minlength=n)
    # Bootstrap games using their sufficient statistics, retaining all within-game dependence.
    sufficient = np.column_stack((py, pp, loss, residual, loo_baseline,
                                  band_weight, band_pred, band_y))
    rng = np.random.default_rng(BOOT_SEED)
    draws = np.empty((reps, sufficient.shape[1]))
    for start in range(0, reps, 50):
        size = min(50, reps-start)
        multiplicities = np.zeros((size, n))
        indices = rng.integers(n, size=(size, n))
        for j in range(size): multiplicities[j] = np.bincount(indices[j], minlength=n)
        draws[start:start+size] = multiplicities @ sufficient / n
    def interval(array): return np.quantile(array, [.025, .975]).tolist()
    def metric(value, array): return {"estimate": float(value), "game_cluster_bootstrap_ci95": interval(array)}
    qboot = draws[:, 0]; brierboot = draws[:, 2]; constboot = qboot*(1-qboot)
    result = {"unique_games": n, "positions": len(p), "total_game_weight": float(w.sum()),
        "positions_per_game_min": int(counts.min()), "positions_per_game_max": int(counts.max()),
        "games_without_eligible_positions": sum(r["selected"] == 0 for r in game_rows),
        "actor_positions": {str(a): int((data["actor"] == a).sum()) for a in (0, 1)},
        "predicted_actor_win_probability": metric(pp.mean(), draws[:, 1]),
        "observed_actor_win_rate": metric(q, qboot),
        "mean_residual_observed_minus_predicted": metric(residual.mean(), draws[:, 3]),
        "brier_score": metric(loss.mean(), brierboot),
        "constant_50_percent_brier": .25,
        "fitted_constant_probability": q,
        "fitted_constant_brier": metric(fitted_baseline.mean(), constboot),
        "leave_one_game_out_constant_brier": {
            "estimate": float(loo_baseline.mean()),
            "note": "Auxiliary diagnostic only: each game's constant is fitted to all other games. No interval reported; the primary fitted-constant baseline is re-estimated within each bootstrap draw."},
        "brier_improvement_over_fitted_constant": metric(fitted_baseline.mean()-loss.mean(), constboot-brierboot),
        "outcome_r2": metric(1-loss.mean()/fitted_baseline.mean(), 1-brierboot/constboot),
        "outcome_r2_definition": "1 - equal-game-weighted Brier / variance of the actor-win labels; constant baseline is the equal-game-weighted observed mean.",
        "bootstrap": {"unit": "entire game", "replicates": reps, "seed": BOOT_SEED,
                      "intervals": "pointwise percentile 95%; mean baseline re-estimated per bootstrap draw"},
        "probability_bands": []}
    for band in range(10):
        weight = band_weight[:, band].sum(); mask = bands == band
        bw = draws[:, 5+band]; bp = draws[:, 15+band]; by = draws[:, 25+band]
        nonzero = bw > 0
        result["probability_bands"].append({"lower": band/10, "upper": (band+1)/10,
            "upper_inclusive": band == 9, "position_count": int(mask.sum()),
            "supporting_games": int((band_weight[:, band] > 0).sum()),
            "sum_equal_game_position_weights": float(weight),
            "mean_predicted_probability": float(band_pred[:, band].sum()/weight) if weight else None,
            "observed_win_rate": float(band_y[:, band].sum()/weight) if weight else None,
            "observed_win_rate_game_cluster_ci95": interval(by[nonzero]/bw[nonzero]) if weight else None,
            "residual_game_cluster_ci95": interval((by[nonzero]-bp[nonzero])/bw[nonzero]) if weight else None})
    np.savez_compressed(out / "per-game.npz", seed=np.array([r["seed"] for r in game_rows]),
        selected_positions=counts, eligible_turns=np.array([r["eligible_turns"] for r in game_rows]),
        mean_p=pp, mean_actor_won=py, mean_residual=residual, brier=loss,
        fitted_constant_brier=fitted_baseline, loo_constant_brier=loo_baseline,
        band_weight=band_weight, band_prediction_sum=band_pred, band_outcome_sum=band_y)
    write_json(out / "figure-data.json", {"weighting": "Each game total weight one; within-game sampled positions weight 1/n_selected.",
        "calibration_bands": result["probability_bands"], "brier": result["brier_score"],
        "constant_brier": result["fitted_constant_brier"], "outcome_r2": result["outcome_r2"]})
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=HERE)
    parser.add_argument("--limit", type=int, default=0, help="Pilot only; 0 means all 10,000 games.")
    parser.add_argument("--batch", type=int, default=256)
    parser.add_argument("--bootstrap", type=int, default=5000)
    args = parser.parse_args(); args.out.mkdir(parents=True, exist_ok=True)
    assert not (args.out / "summary.json").exists(), "Use a fresh destination."
    torch.set_num_threads(1); torch.set_num_interop_threads(1)
    assert sha(MODEL) == EXPECTED_SHA
    protocol = {"created_utc": datetime.now(timezone.utc).isoformat(),
        "source": str(SOURCE), "model": str(MODEL), "model_sha256": EXPECTED_SHA,
        "selection_fixed_before_new_predictions": True,
        "eligibility": "First saved action decision in Phase::Play with more than one legal action per distinct regular turn; all post-roll turns, no opponent hidden-card requirement.",
        "selection": "For m eligible turns select n=min(16,m), indices floor(i*m/n), i=0,...,n-1, in chronological order; uses no predictions or outcomes.",
        "weighting": "One unit of total weight per game; each selected position receives 1/n_selected.",
        "labels": "Saved final win of the actor at the sampled decision; original greedy Gen37-versus-Gen37 continuation.",
        "scope": "10,000 existing unique completed network controls; duplicated tested-seat controls verified then deduplicated.",
        "excluded": "Setup, pre-roll, chance, forced-only turns, and non-Play subdecisions.",
        "value_conversion": "p=(1+raw_actor_value)/2, no recalibration or fitting.",
        "training_target": "Gen37 target is 35% actual outcome plus 65% search value, gamma=1; this measures empirical calibration under the saved greedy policy, not optimal-play probabilities.",
        "uncertainty": "Whole-game nonparametric bootstrap from per-game sufficient statistics; pointwise 95% percentile intervals.",
        "cpu_threads": 1, "fresh_games": 0, "search_simulations": 0,
        "pilot_limit": args.limit, "bootstrap_replicates": args.bootstrap}
    write_json(args.out / "protocol.json", protocol)
    start = time.monotonic()
    binary, seeds, outcomes, checks, manifest = prepare(args.out, args.limit)
    print(f"Prepared {len(seeds):,} unique controls in {time.monotonic()-start:.1f}s", flush=True)
    data, game_rows, validation = evaluate(args.out, binary, seeds, outcomes, checks, args.batch)
    result = summarize(args.out, data, game_rows, args.bootstrap)
    result.update({"validation": validation, "interpretation": protocol["training_target"],
                   "scope": protocol["eligibility"], "weighting": protocol["weighting"],
                   "elapsed_seconds": time.monotonic()-start})
    manifest.update({"script_sha256": sha(__file__),
        "native_source_sha256": sha(HERE / "native/src/main.rs"), "model_sha256": EXPECTED_SHA,
        "native_binary_sha256": sha(HERE / "native/target/release/midgame_calibration_export"),
        "outputs": {name: sha(args.out / name) for name in ("per-position.npz", "per-game.npz", "figure-data.json", "replay-games.jsonl")}})
    write_json(args.out / "source-manifest.json", manifest)
    write_json(args.out / "summary.json", result)
    print(json.dumps({key: result[key] for key in ("unique_games", "positions", "brier_score", "fitted_constant_brier", "outcome_r2", "mean_residual_observed_minus_predicted", "elapsed_seconds")}, indent=2), flush=True)

if __name__ == "__main__":
    main()
