#!/usr/bin/env python3
"""Original Gen37 opening values matched to 10,000 existing greedy controls.

Only the empty root is evaluated once per board. No game trajectories, search,
policy changes, model updates, or calibration fitting are performed. Outcomes
are the saved original network-v-network controls, deduplicated by retaining
rule=network and tested_seat=0 after verifying the two control replays agree.

Run from any directory with the repository's .venv/bin/python. The default
output is this script's directory. Use --out for an independent reproduction.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time

# Set before importing numerical libraries; never use more than two CPU threads.
for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS",
            "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT))
import catan_rl
from train import load_model, split_obs

EXPECTED_SHA = "fbc5209b17a14a1d7b649087efdb1503185c7dfab9d9f5b443d0957431272158"
DEFAULT_SOURCE = ROOT / "run/analysis/opening-baseline-10k-20261105/main"
Z95 = 1.959963984540054


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def save_json(path, data):
    with Path(path).open("x") as f:
        json.dump(data, f, indent=2, allow_nan=False)
        f.write("\n")


def interval(x):
    """Paired mean/normal-SE interval across independent board-seed units."""
    x = np.asarray(x, dtype=np.float64)
    mean = float(x.mean())
    se = float(x.std(ddof=1) / np.sqrt(len(x)))
    return {"mean": mean, "standard_error": se,
            "normal_ci95": [mean - Z95 * se, mean + Z95 * se]}


def wilson(wins, count):
    p = wins / count
    denom = 1 + Z95**2 / count
    center = (p + Z95**2 / (2 * count)) / denom
    half = Z95 * np.sqrt(p * (1-p) / count + Z95**2 / (4*count**2)) / denom
    return [float(center-half), float(center+half)]


def read_controls(source):
    """Stream full source rows, retain one outcome and public board per seed."""
    protocol = json.loads((source / "protocol.json").read_text())
    protocol_sha = sha(source / "protocol.json")
    assert protocol["boards"] == 10000
    assert protocol["model_sha256"] == EXPECTED_SHA
    by_seed = {}
    source_manifest = []
    duplicates_checked = rows_checked = 0
    for path in sorted(source.glob("chunk-*.json")):
        raw = path.read_bytes()
        chunk = json.loads(raw)
        assert chunk["protocol_sha256"] == protocol_sha
        assert chunk["model_sha256"] == EXPECTED_SHA
        source_manifest.append({"file": path.name, "sha256": hashlib.sha256(raw).hexdigest()})
        grouped = {}
        for row in chunk["rows"]:
            grouped.setdefault(row["seed"], []).append(row)
        for seed, rows in grouped.items():
            assert seed not in by_seed, ("duplicate seed across chunks", seed)
            assert len(rows) == 6
            assert {(r["tested_seat"], r["rule"]) for r in rows} == {
                (s, r) for s in (0, 1) for r in ("network", "max_pips", "resource_weighted")}
            controls = {r["tested_seat"]: r for r in rows if r["rule"] == "network"}
            a, b = controls[0], controls[1]
            assert a["history"] == b["history"]
            assert a["outcome"] == b["outcome"]
            assert a["terminal"] and b["terminal"] and a["outcome"] in (-1, 1)
            assert a["won"] == (a["outcome"] == 1)
            assert b["won"] == (a["outcome"] == -1)
            assert all(r["board"] == a["board"] for r in rows)
            by_seed[seed] = {"seed": seed, "board": a["board"], "a_won": int(a["won"]),
                             "saved_outcome": a["outcome"], "source_chunk": path.name}
            duplicates_checked += 1
            rows_checked += len(rows)
    expected_seeds = list(range(protocol["seed_start"], protocol["seed_end"] + 1))
    assert sorted(by_seed) == expected_seeds and len(by_seed) == 10000
    controls = [by_seed[seed] for seed in expected_seeds]
    assert sum(row["a_won"] for row in controls) == 5475
    return controls, protocol_sha, source_manifest, {
        "source_rows_checked": rows_checked, "unique_control_games": len(controls),
        "duplicate_control_histories_and_outcomes_checked": duplicates_checked,
        "all_six_condition_board_arrays_identical_per_seed": True,
        "deduplication": "Retain rule=network, tested_seat=0; verify tested_seat=1 has identical history/outcome."}


def calibration_bins(p, y, seeds, groups):
    # Predictions alone define the ordering. Seeds break an exact score tie.
    order = np.lexsort((seeds, p))
    bins = []
    for j, idx in enumerate(np.array_split(order, groups)):
        wins = int(y[idx].sum())
        bins.append({"bin": j+1, "count": len(idx), "a_wins": wins,
                     "implied_p_min": float(p[idx].min()), "implied_p_max": float(p[idx].max()),
                     "implied_p_mean": float(p[idx].mean()),
                     "observed_a_win_rate": float(y[idx].mean()),
                     "observed_a_win_rate_wilson_ci95": wilson(wins, len(idx)),
                     "paired_residual_y_minus_p": interval(y[idx]-p[idx])})
    return bins


def summarize(seeds, values, outcomes):
    y = outcomes.astype(np.float64)
    p = (1 + values.astype(np.float64)) / 2
    residual = y-p
    mean_y = float(y.mean())
    residual_summary = interval(residual)
    rng = np.random.default_rng(2026111037)
    boot = np.empty(10000)
    for start in range(0, len(boot), 100):
        idx = rng.integers(len(y), size=(100, len(y)))
        boot[start:start+100] = residual[idx].mean(axis=1)
    residual_summary["board_bootstrap_percentile_ci95"] = np.quantile(boot, [.025, .975]).tolist()
    residual_summary["bootstrap_replicates"] = 10000
    residual_summary["bootstrap_seed"] = 2026111037
    model_loss = (y-p)**2
    half_loss = (y-.5)**2
    fitted_mean_loss = (y-mean_y)**2
    # Leave-one-out fitted constant is also supplied so the fitted baseline's
    # slight in-sample advantage is transparent; it is not a new model fit.
    loo_mean = (y.sum()-y)/(len(y)-1)
    deciles = calibration_bins(p, y, seeds, 10)
    quintiles = calibration_bins(p, y, seeds, 5)
    low, high = int(np.argmin(p)), int(np.argmax(p))
    q = {str(percent): float(np.percentile(p, percent))
         for percent in (0, 1, 5, 10, 25, 50, 75, 90, 95, 99, 100)}
    auc_order = np.argsort(p, kind="stable")
    ranks = np.empty(len(p), dtype=float)
    # Average ranks handle tied floating-point predictions exactly.
    sorted_p = p[auc_order]
    boundaries = np.r_[0, np.flatnonzero(np.diff(sorted_p)) + 1, len(p)]
    for a, b in zip(boundaries[:-1], boundaries[1:]):
        ranks[auc_order[a:b]] = (a+1+b)/2
    n_positive = int(y.sum())
    n_negative = len(y)-n_positive
    auc = (ranks[y == 1].sum() - n_positive*(n_positive+1)/2)/(n_positive*n_negative)
    return {
        "boards": len(y), "a_wins": n_positive, "b_wins": n_negative,
        "observed_a_win_rate": mean_y,
        "observed_a_win_rate_wilson_ci95": wilson(n_positive, len(y)),
        "mean_implied_a_probability": float(p.mean()),
        "mean_raw_a_value": float(values.mean(dtype=np.float64)),
        "mean_implied_b_probability": float((1-p).mean()),
        "paired_residual_y_minus_p": residual_summary,
        "predictions": {"mean_sampling_interval_across_boards": interval(p),
                        "standard_deviation": float(p.std(ddof=1)),
                        "percentiles": q, "max_minus_min": float(p.max()-p.min()),
                        "p95_minus_p05": float(np.percentile(p,95)-np.percentile(p,5)),
                        "p90_minus_p10": float(np.percentile(p,90)-np.percentile(p,10)),
                        "a_favored_boards": int((p>.5).sum()),
                        "minimum": {"seed": int(seeds[low]), "implied_a_probability": float(p[low]),
                                    "observed_a_won": int(y[low])},
                        "maximum": {"seed": int(seeds[high]), "implied_a_probability": float(p[high]),
                                    "observed_a_won": int(y[high])}},
        "brier": {"original_gen37": float(model_loss.mean()), "constant_0_5": float(half_loss.mean()),
                  "constant_fitted_sample_mean": float(fitted_mean_loss.mean()),
                  "fitted_constant_value": mean_y,
                  "constant_leave_one_out_sample_mean": float(np.mean((y-loo_mean)**2)),
                  "gen37_minus_constant_0_5_paired": interval(model_loss-half_loss),
                  "gen37_minus_constant_fitted_mean_paired_descriptive": interval(model_loss-fitted_mean_loss),
                  "fitted_baseline_caveat": "The .5475 constant is fit to these same outcomes; its score and paired interval are descriptive in-sample comparisons, not held-out estimates."},
        "discrimination_descriptive": {"auc": float(auc),
            "pearson_prediction_outcome_correlation": float(np.corrcoef(p,y)[0,1])},
        "calibration_deciles": deciles, "calibration_quintiles": quintiles,
        "decile_expected_absolute_calibration_error": float(sum(
            b["count"]*abs(b["observed_a_win_rate"]-b["implied_p_mean"]) for b in deciles)/len(y)),
        "calibration_note": "Bins are equal-count groups sorted only by predicted probability. Intervals are pointwise. Binned observed rates estimate group averages under frozen greedy Generation 37 continuation. One existing stochastic game per board does not identify that individual board's win probability.",
        "interpretation": "p=(1+v)/2 is the original value head's implied A probability before any placement. It was not fit/calibrated here and was not trained specifically to predict this greedy-vs-greedy evaluation protocol. A mean match does not prove board-level calibration.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--model", type=Path, default=ROOT/"run/scale/gen37.pt")
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--batch", type=int, default=64)
    args = parser.parse_args()
    assert 1 <= args.batch <= 256
    args.out.mkdir(parents=True, exist_ok=True)
    for name in ("per-board.npz", "per-board.json", "summary.json", "source-manifest.json"):
        assert not (args.out/name).exists(), ("output already exists", args.out/name)
    started = time.monotonic()
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    assert sha(args.model) == EXPECTED_SHA
    rows, protocol_sha, manifest, validation = read_controls(args.source)
    print(f"Validated {len(rows)} unique saved controls and identical duplicates in {time.monotonic()-started:.1f}s", flush=True)
    model = load_model(args.model).cpu().eval().requires_grad_(False)
    assert not model.canonical_discards
    seeds = np.array([row["seed"] for row in rows], dtype=np.int64)
    outcomes = np.array([row["a_won"] for row in rows], dtype=np.int8)
    values = np.empty(len(rows), dtype=np.float32)
    board_resources = np.array([row["board"][0] for row in rows], dtype=np.uint8)
    board_numbers = np.array([row["board"][1] for row in rows], dtype=np.uint8)
    board_ports = np.array([row["board"][2] for row in rows], dtype=np.uint8)
    verified = forward_boards = forward_calls = 0
    with torch.inference_mode():
        for start in range(0, len(rows), args.batch):
            block = rows[start:start+args.batch]
            observations = []
            for row in block:
                game = catan_rl.Game(seed=row["seed"])
                assert [list(a) for a in game.board_arrays()] == row["board"], row["seed"]
                assert game.to_act() == 0 and not game.history()
                obs = game.opening_observation()
                assert obs.shape == (1,4752) and obs.dtype == np.float32
                # Global 372 is canonical_discards; 373:378 are its floor.
                assert np.all(obs[0, -400+372:-400+378] == 0)
                observations.append(obs)
                verified += 1
            obs = torch.from_numpy(np.concatenate(observations, axis=0))
            _, value = model(*split_obs(obs))
            values[start:start+len(block)] = value.cpu().numpy()
            forward_boards += len(block)
            forward_calls += 1
            if forward_boards % 1024 == 0 or forward_boards == len(rows):
                print(f"Evaluated {forward_boards}/{len(rows)} root positions; {time.monotonic()-started:.1f}s total", flush=True)
    assert verified == forward_boards == 10000
    assert np.isfinite(values).all() and np.all(np.abs(values) <= 1)
    p = (1+values.astype(np.float64))/2
    metrics = summarize(seeds, values, outcomes)
    validation.update({"seed_regenerated_board_arrays_exactly_equal_saved": verified,
        "legacy_canonical_discards_false_all_observations": True,
        "checkpoint_canonical_discards": False, "network_evaluated_root_positions": forward_boards,
        "batched_forward_calls": forward_calls, "search_simulations": 0, "new_game_trajectories": 0,
        "root_state": "Empty board, A/P0 to act before A1; original board generator verified against all saved arrays."})
    per_board = [{"seed": int(s), "raw_a_value": float(v), "implied_a_probability": float(prob),
                  "implied_b_probability": float(1-prob), "observed_a_won": int(y),
                  "saved_outcome": row["saved_outcome"], "source_chunk": row["source_chunk"]}
                 for s,v,prob,y,row in zip(seeds,values,p,outcomes,rows)]
    with (args.out/"per-board.npz").open("xb") as f:
        np.savez_compressed(f, seed=seeds, raw_a_value=values, implied_a_probability=p,
                            observed_a_won=outcomes, board_resources=board_resources,
                            board_numbers=board_numbers, board_ports=board_ports)
    save_json(args.out/"per-board.json", per_board)
    save_json(args.out/"source-manifest.json", {"source_directory": str(args.source.resolve()),
             "protocol_sha256": protocol_sha, "chunks": manifest})
    result = {"schema": "matched-gen37-opening-value-calibration-v1",
        "created_utc": datetime.now(timezone.utc).isoformat(), "model": str(args.model.resolve()),
        "model_sha256": EXPECTED_SHA, "script_sha256": sha(__file__),
        "source_protocol_sha256": protocol_sha,
        "source_manifest_sha256": sha(args.out/"source-manifest.json"),
        "per_board_npz_sha256": sha(args.out/"per-board.npz"),
        "per_board_json_sha256": sha(args.out/"per-board.json"),
        "runtime": {"seconds": time.monotonic()-started, "device": "cpu", "batch": args.batch,
                    "torch_threads": torch.get_num_threads(), "torch_interop_threads": torch.get_num_interop_threads(),
                    "torch_version": torch.__version__, "numpy_version": np.__version__,
                    "python_version": sys.version, "catan_rl_module": catan_rl.__file__},
        "source_code_sha256": {str(path.relative_to(ROOT)): sha(path) for path in (
            ROOT/"train.py", ROOT/"gnn.py", ROOT/"catan/src/py.rs", ROOT/"catan/src/features.rs")},
        "validation": validation, "summary": metrics}
    save_json(args.out/"summary.json", result)
    print(json.dumps({k: metrics[k] for k in ("observed_a_win_rate", "mean_implied_a_probability",
        "paired_residual_y_minus_p", "brier", "predictions")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
