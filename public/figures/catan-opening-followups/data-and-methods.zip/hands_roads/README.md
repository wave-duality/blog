# Starting hands and contested roads (Generation 37)

Reproduce from the CatanRL repository:

```sh
.venv/bin/python opening_followup_hands_roads.py --n 2000 --patch-n 512 --readiness-n 1000
.venv/bin/python run/analysis/opening-followups-20261102/hands_roads/validate.py
```

Requires the unchanged `run/scale/gen37.pt` checkpoint and the completed `run/analysis/opening-study-100k-20261029/shards/` corpus. The checkpoint SHA is checked by `OpeningEngine`; the output stores the script SHA, seeds and complete case histories. Selection uses only geometry, starting-card identities and public dice, never intervention scores.

Outputs:

- `results.json`: final summary and uncertainty.
- `hands-cases.json`: 2,000 A1/A2 reversals with identical final pieces and equal initial card counts, before and after a shared non-7 first roll.
- `roads-cases.json`: 2,000 orientation interventions at A2's free road decision, with identical global input and legal road sets.
- `roads-opponent-readiness-cases.json`: 1,000 orientation × B1/B2-order interventions, with equal card counts and B able/unable to buy a road.
- `roads-hand-factorial-cases.json`: 1,000 separate first-Play hand-context comparisons where A can buy the contested edge under all four conditions. These do not vary immediate affordability.
- `hands-patches.json`, `roads-patches.json`: 512 pairs per intervention; identity and complete-donor controls, plus unchanged-row controls for road patches.
- `validation.json`: independent single-row policy reruns, regeneration of sampled source boards and direct reconstruction of summary statistics.
- `article-sections.md`: draft prose for experiments 10 and 13.

The basic geometry is `A2—u—v—B2`; both opening roads can point toward the unowned middle edge `(u,v)`. This is a direct edge race, not an automatic settlement cutoff. All four settlements and long-run production stay fixed. The B hand intervention swaps B's two entire settlement/road placement pairs, so the second one grants a different but equally sized starting hand.

Every native root used to extract a legal mask has exactly zero child visits and no selection rounds. Its callback emits uniform dummy scores; the actual model is evaluated separately, without search or rollouts. All midgame observations cross the native actor's `PlayerView` boundary. No input vector was edited to create a supposed game state; embedding replacements are explicitly hybrid mechanistic diagnostics.

Mean confidence intervals treat one whole paired board as the independent unit. Frequency intervals are Wilson intervals; patch projections use 2,000 whole-board bootstrap resamples. The analysis is exploratory and intervals are pointwise. In particular, the broad embedding patch groups do not isolate a semantic neuron, and the road-ready hand comparison changes other resource identities besides wood and brick. These results describe this policy, not optimal play or measured winning value.
