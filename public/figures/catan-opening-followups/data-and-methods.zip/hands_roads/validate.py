"""Independent saved-output checks and single-row reruns of paired conditions."""
import hashlib,json,sys
from pathlib import Path
import numpy as np
import torch
import catan_rl
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT))
from opening_engine import OpeningEngine,warnings,_from_arrays
from train import split_obs
D=Path(__file__).resolve().parent
R=json.loads((D/'results.json').read_text())
assert hashlib.sha256((ROOT/'opening_followup_hands_roads.py').read_bytes()).hexdigest()==R['script_sha256']
sets={name:json.loads((D/file).read_text()) for name,file in [('hands','hands-cases.json'),('roads','roads-cases.json'),('factorial','roads-hand-factorial-cases.json'),('readiness','roads-opponent-readiness-cases.json')]}
for k,x in sets.items():assert len({r['seed'] for r in x})==len(x)
engine=OpeningEngine();bot=catan_rl.Bot(sims=0);errors=[];boards=0
@torch.inference_mode()
def check(obs,legal,probs,choice):
    z,_=engine.model(*split_obs(torch.from_numpy(obs)))
    indices=np.asarray(legal,dtype=int)
    p=torch.softmax(z[0,indices].double(),0).numpy()
    expect=np.asarray([probs[str(i)] for i in indices])
    errors.append(float(np.abs(p-expect).max()))
    np.testing.assert_allclose(p,expect,atol=2e-5,rtol=2e-5)
    selected=int(indices[np.argmax(z[0,indices].numpy())]);assert selected==choice
for name in ['hands','roads']:
    rows=sets[name]
    for i in np.random.default_rng(72313).choice(len(rows),64,replace=False):
        r=rows[i];b=r['board'];assert [list(x) for x in catan_rl.Game(seed=r['seed']).board_arrays()]==b
        assert not warnings(_from_arrays(*b))
        boards+=1
        if name=='hands':
            for label,h in [('original',r['history']),('swapped',r['swapped_history'])]:
                catan_rl.Game.from_opening(*b,h)
                history=[(1,a) for a in h]+[(1,240),(0,r['roll'])]
                obs,actor=bot.value_observations(*b,history,0);assert actor==0
                check(obs,r['legal_'+label],r['preference_'+label],r['choice_'+label])
        else:
            for label in ['away','toward']:
                game=catan_rl.Game.from_opening(*b,r[label+'_history'])
                assert game.legal()==r['legal_roads']
                check(game.opening_observation(),game.legal(),r['preferences_'+label],r['choice_'+label])
# Recompute primary aggregates directly from saved cases; no stored summary inputs.
h=sets['hands'];roads=sets['roads'];ready=sets['readiness']
assert sum(x['choice_original']!=x['choice_swapped'] for x in h)==R['hands']['choice_changed']['count']
np.testing.assert_allclose(np.mean([abs(x['pre_roll_value_original']-x['pre_roll_value_swapped']) for x in h]),R['hands']['pre_roll_absolute_value_delta']['mean'],atol=1e-7)
np.testing.assert_allclose(np.mean([x['race_preference_toward']-x['race_preference_away'] for x in roads]),R['roads']['race_preference_delta']['mean'])
np.testing.assert_allclose(np.mean([x['interaction'] for x in ready]),R['roads']['opponent_starting_hand_readiness']['interaction']['mean'])
# Every mechanism intervention has native identity and complete-donor controls.
patch_checks={}
for filename in ['hands-patches.json','roads-patches.json']:
    data=json.loads((D/filename).read_text())
    maxerr=max(max(float(v) for k,v in row.items() if k.endswith('error')) for row in data)
    assert maxerr<1e-5;patch_checks[filename]=dict(n=len(data),max_control_error=maxerr)
result=dict(status='passed',independent_single_row_decisions=256,original_seed_boards_rechecked=boards,all_source_board_distribution_checks_pass=True,max_saved_preference_error=max(errors),unique_board_counts={k:len(v) for k,v in sets.items()},summary_recomputed_from_saved_cases=True,patch_controls=patch_checks,script_sha256=R['script_sha256'],native_sources={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['catan/src/py.rs','catan/src/rules.rs','catan/src/features.rs','catan/src/state.rs']})
(D/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
