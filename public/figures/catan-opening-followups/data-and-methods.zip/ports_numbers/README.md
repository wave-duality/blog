# Opening follow-ups: ports and number patterns

Frozen Generation 37 checkpoint SHA-256: `fbc5209b17a14a1d7b649087efdb1503185c7dfab9d9f5b443d0957431272158`.

No search, self-play, optimizer, or training is used. All interventions replay legal native opening states. The completed run screened all 100,000 boards from `opening-study-100k-20261029`, sampled 2,000 eligible boards per B2/A2 stage for each main study, and evaluated 39,644 valid-board conditions in total (plus internal activation diagnostics). The same-rate port control contains 3,911 of the selected 4,000 positions.

## Reproduce

Put `methods/opening_followup_ports_numbers.py` in the root of a CatanRL checkout with its native Python extension, the original corpus shards, and the checkpoint. Run:

```sh
.venv/bin/python opening_followup_ports_numbers.py \
  --corpus run/analysis/opening-study-100k-20261029 \
  --out run/analysis/opening-followups-20261102/ports_numbers \
  --samples 2000 --patch-samples 128
```

The script sets Torch to one CPU thread. Use `--screen-boards 200 --samples 20 --patch-samples 2` with a separate output directory for a quick benchmark. `--reuse-selection` repeats forward evaluation from an existing selection file; it does not screen new boards. The seed is 110237. Selection is determined by geometry/resource conditions and seeded sampling, not by policy outputs. The supplemental same-rate port control is explicitly identified as a post-hoc diagnostic in the draft.

## Files

- `results.json`: summary statistics, sample counts, stage and resource/number breakdowns, validation results, runtime and source/checkpoint hashes.
- `selection.json`: complete reproducible selected boards, histories, legal corners, swaps, and corpus-shard hashes.
- `ports-rows.json`, `numbers-rows.json`, `ports_control-rows.json`: every evaluated contrast and its four or two condition scores.
- `*-patches.json`: all internal activation diagnostics, including exact identity controls.
- `blog-draft.md`: reader-facing draft for Experiments 9 and 11.
- `methods/opening_followup_ports_numbers.py`: exact analysis source.

Raw logits measure policy preference. They are not winning probability, calibrated strategic value, or a proof that one opening is stronger. Sampling uncertainty is measured by 2,000 bootstrap replicates over independent boards, with repeated stages from one board kept together in pooled summaries. This uncertainty does not cover model misspecification, alternative trained checkpoints, or the narrow eligibility criteria.

All inventories, number adjacency restrictions, native action legality, entire global input vectors (including hands), and the required local production invariants are asserted during evaluation. Internal activation hybrids are distinguished from valid game-state interventions. Existing number-diversification validation tests also pass.
