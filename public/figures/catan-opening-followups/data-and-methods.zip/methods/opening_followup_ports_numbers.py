#!/usr/bin/env python3
"""Paired valid-board opening interventions, frozen Generation 37, no search.

Screen every board in an existing corpus, select one eligible contrast per
board/stage (uniformly), and sample eligible board/stages without replacement.
Run from the CatanRL repository with its native extension and checkpoint.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time

import catan_rl
import numpy as np
import torch
import torch.nn.functional as F

from opening_engine import OpeningEngine, MODEL_PATH, MODEL_SHA, LABELS, SEATS
from analyze_number_diversification import PIPS, adjacent_pairs, valid_numbers, production, total_variance
from train import split_obs

ROOT = Path(__file__).resolve().parent
G = json.loads((ROOT/'viz/geometry.json').read_text())
LOCAL = [set(h for h in hs if h is not None and h >= 0) for hs in G['vertex_hexes']]
TOUCH = np.array([[h in hs for h in range(19)] for hs in LOCAL])
NEIGHBORS = adjacent_pairs(G)
PORT_VERTICES = [set(vs) for vs in G['port_vertices']]
PORT_VERTEX = {v:i for i,vs in enumerate(PORT_VERTICES) for v in vs}
SEED = 110237


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, allow_nan=False)+'\n')


def owned(history, stage):
    vs = history[::2] - 72
    own = [int(v) for j,v in enumerate(vs[:stage]) if SEATS[j] == SEATS[stage]]
    opp = [int(v) for j,v in enumerate(vs[:stage]) if SEATS[j] != SEATS[stage]]
    assert len(own) == 1
    return own[0], opp


def resource_pips(resources, numbers):
    return TOUCH.astype(int) @ (np.eye(6,dtype=int)[resources,:5] * PIPS[numbers,None])


def number_options(board, history, stage, legal):
    resources,numbers,ports = board
    own,opp = owned(history,stage)
    ownhex=LOCAL[own]; opphex=set().union(*(LOCAL[v] for v in opp))
    options=[]
    for source in sorted(ownhex-opphex):
        old=int(numbers[source]); new=14-old
        if old not in (3,4,5,6,8,9,10,11): continue
        if any(numbers[h] in (old,new) for h in ownhex-{source}): continue
        for remote in np.flatnonzero((numbers==new)&(resources==resources[source])):
            remote=int(remote)
            if remote in ownhex|opphex: continue
            changed=numbers.copy(); changed[source],changed[remote]=new,old
            if not valid_numbers(changed,NEIGHBORS): continue
            excluded=TOUCH[:,source]|TOUCH[:,remote]
            count_old=TOUCH[:,numbers==old].sum(1)
            count_new=TOUCH[:,numbers==new].sum(1)
            good=legal[~excluded[legal] & ((count_old+count_new)[legal]==1)]
            a=good[count_old[good]==1]; b=good[count_new[good]==1]
            if not len(a) or not len(b): continue
            options.append(dict(source_hex=source,remote_hex=remote,old_number=old,new_number=new,
                                pair=f'{min(old,new)}/{max(old,new)}',own_vertex=own,
                                became_diversified=a.tolist(),became_duplicated=b.tolist()))
    return options


def port_options(board, history, stage, legal):
    resources,numbers,ports=board
    own,opp=owned(history,stage); occupied={own,*opp}
    ownhex=LOCAL[own]; opphex=set().union(*(LOCAL[v] for v in opp))
    rp=resource_pips(resources,numbers)
    legalset=set(legal.tolist()); options=[]
    # The first settlement has no starting hand. Changing its resource mix
    # preserves all held cards; remote tile may touch no placed settlement.
    for source in sorted(ownhex-opphex):
        s=int(resources[source]); number=int(numbers[source])
        if s==5: continue
        for remote in np.flatnonzero((numbers==number)&(resources!=s)&(resources<5)):
            remote=int(remote); r=int(resources[remote])
            if remote in ownhex|opphex: continue
            for target_port in range(9):
                if ports[target_port] not in (r,5) or PORT_VERTICES[target_port]&occupied: continue
                other_type=5 if ports[target_port]==r else r
                for remote_port in np.flatnonzero(ports==other_type):
                    remote_port=int(remote_port)
                    if PORT_VERTICES[remote_port]&occupied: continue
                    for target in sorted(PORT_VERTICES[target_port]&legalset):
                        if LOCAL[target]&{source,remote}: continue
                        low=rp[own]+rp[target]; total=int(low.sum())
                        if not total or not .2 <= low[r]/total <= .5: continue
                        if low[r] < low.max(): continue
                        high=low.copy(); high[r]+=PIPS[number]; high[s]-=PIPS[number]
                        if high[r]/total < .5 or (high@high)<=(low@low): continue
                        # Controls are legal non-port corners whose local tile
                        # resources and numbers do not change in any condition.
                        controls=[int(v) for v in legal if v not in PORT_VERTEX and not LOCAL[v]&{source,remote}]
                        if len(controls)<8: continue
                        options.append(dict(source_hex=source,remote_hex=remote,source_resource=s,
                            target_resource=r,number=number,own_vertex=own,target_vertex=target,
                            target_port=target_port,remote_port=remote_port,controls=controls,
                            low_production_pips=low.tolist(),high_production_pips=high.tolist(),
                            low_share=float(low[r]/total),high_share=float(high[r]/total)))
    return options


class Reservoir:
    def __init__(self, n, seed):
        self.n=n;self.rng=np.random.default_rng(seed);self.seen=0;self.rows=[]
    def add(self,row):
        self.seen+=1
        if len(self.rows)<self.n:self.rows.append(row)
        else:
            j=int(self.rng.integers(self.seen))
            if j<self.n:self.rows[j]=row


def screen(args):
    corpus=Path(args.corpus); manifest=json.loads((corpus/'manifest.json').read_text())
    assert manifest['status']=='complete' and manifest['model']['sha256']==MODEL_SHA
    rs={(kind,stage):Reservoir(args.samples,SEED+100*k+stage) for k,kind in enumerate(('ports','numbers')) for stage in (2,3)}
    counters={kind:{LABELS[s]:dict(boards=0,eligible_boards=0,eligible_contrasts=0) for s in (2,3)} for kind in ('ports','numbers')}
    rng=np.random.default_rng(SEED); t=time.perf_counter(); boards_seen=0; sources=[]
    for shard in manifest['shards']:
        path=corpus/shard['path']; assert sha(path)==shard['sha256']
        with np.load(path) as a:
            seeds=a['board_seed'];resources=a['board_resources'];numbers=a['board_numbers'];ports=a['board_ports'];histories=a['history'];ptr=a['position_ptr'];vertices=a['candidate_vertex']
            for i,seed in enumerate(seeds):
                if args.screen_boards and boards_seen>=args.screen_boards:break
                board=(resources[i],numbers[i],ports[i]);history=histories[i]
                assert valid_numbers(numbers[i],NEIGHBORS)
                for stage in (2,3):
                    position=i*4+stage; legal=vertices[ptr[position]:ptr[position+1]].astype(int)
                    for kind,fn in (('ports',port_options),('numbers',number_options)):
                        cc=counters[kind][LABELS[stage]];cc['boards']+=1
                        options=fn(board,history,stage,legal)
                        if options:
                            cc['eligible_boards']+=1;cc['eligible_contrasts']+=len(options)
                            opt=options[int(rng.integers(len(options)))]
                            row=dict(seed=int(seed),stage=LABELS[stage],stage_index=stage,
                                board=[x.tolist() for x in board],history=history[:stage*2].tolist(),legal=legal.tolist(),**opt)
                            rs[kind,stage].add(row)
                boards_seen+=1
            sources.append(dict(path=shard['path'],sha256=shard['sha256']))
        if len(sources)%10==0:print(json.dumps(dict(event='screen',boards=boards_seen,seconds=round(time.perf_counter()-t,1),eligible=counters)),flush=True)
        if args.screen_boards and boards_seen>=args.screen_boards:break
    selected={kind:sorted([r for stage in (2,3) for r in rs[kind,stage].rows],key=lambda r:(r['seed'],r['stage_index'])) for kind in ('ports','numbers')}
    return dict(schema='opening-followup-selection-v1',rng_seed=SEED,screened_boards=boards_seen,
        counters=counters,selected=selected,source_shards=sources,screen_seconds=time.perf_counter()-t,
        sampling='All eligible contrasts counted; one selected uniformly within each eligible board/stage, then a uniform reservoir of eligible boards per stage. No policy outputs used in eligibility/selection.')


def variants(row,kind):
    b=np.array(row['board'],dtype=object) # ragged arrays: 19,19,9
    base=[np.asarray(x,dtype=int).copy() for x in b]
    source=row['source_hex'];remote=row['remote_hex']
    if kind=='numbers':
        changed=[x.copy() for x in base];changed[1][source],changed[1][remote]=changed[1][remote],changed[1][source]
        return [base,changed]
    low=[x.copy() for x in base];target=row['target_port'];other=row['remote_port'];r=row['target_resource']
    comparator=row.get('comparator_type',5)
    low[2][target]=comparator;low[2][other]=r
    high=[x.copy() for x in low];high[0][source],high[0][remote]=high[0][remote],high[0][source]
    loport=[x.copy() for x in low];loport[2][target]=r;loport[2][other]=comparator
    hiport=[x.copy() for x in high];hiport[2][target]=r;hiport[2][other]=comparator
    return [low,loport,high,hiport]


def observations(row,kind):
    boards=variants(row,kind);obs=[];legal=row['legal'];own=row['own_vertex']
    for board in boards:
        assert all(Counter(x.tolist())==Counter(y) for x,y in zip(board,row['board']))
        assert valid_numbers(board[1],NEIGHBORS)
        game=catan_rl.Game.from_opening(*[x.tolist() for x in board],row['history'])
        assert game.to_act()==SEATS[row['stage_index']]
        assert [a-72 for a in game.legal()]==legal
        obs.append(game.opening_observation())
    for x in obs[1:]:
        # Entire global vector includes both public hands and own trade rates.
        np.testing.assert_array_equal(obs[0][:,-400:],x[:,-400:])
    if kind=='numbers':
        np.testing.assert_array_equal(PIPS[boards[0][1]],PIPS[boards[1][1]])
        for vs,sign in ((row['became_diversified'],-1),(row['became_duplicated'],1)):
            for v in vs:
                assert not LOCAL[v]&{row['source_hex'],row['remote_hex']}
                np.testing.assert_array_equal(PIPS@production(boards[0],[own,v],G),PIPS@production(boards[1],[own,v],G))
                delta=total_variance(boards[1],[own,v],G)-total_variance(boards[0],[own,v],G)
                assert abs(delta-sign*2*PIPS[row['old_number']]/36)<1e-12
    else:
        for v in [row['target_vertex'],*row['controls']]:
            for b in boards[1:]:
                assert all(boards[0][0][h]==b[0][h] and boards[0][1][h]==b[1][h] for h in LOCAL[v])
        assert sum(row['low_production_pips'])==sum(row['high_production_pips'])
    return np.concatenate(obs)


@torch.inference_mode()
def embeds(model,obs):
    h,v,p,g=split_obs(torch.from_numpy(obs))
    return [F.relu(model.hex_embed(h)),F.relu(model.vertex_embed(v)),F.relu(model.path_embed(p)),F.relu(model.global_embed(g))]


@torch.inference_mode()
def from_embeds(model,state):
    for layer in model.layers:state=layer(*state)
    return model.settle_head(state[1]).squeeze(-1).numpy().astype(float)


def contrast(row,logits,kind):
    if kind=='numbers':
        return logits[...,row['became_diversified']].mean(-1)-logits[...,row['became_duplicated']].mean(-1)
    return logits[...,row['target_vertex']]-logits[...,row['controls']].mean(-1)


@torch.inference_mode()
def patch(model,row,obs,kind):
    """Internal interventions only; hybrid activations are not legal boards."""
    state=embeds(model,obs);direct=model(*split_obs(torch.from_numpy(obs)))[0][:,72:126].numpy().astype(float)
    original=from_embeds(model,state)
    np.testing.assert_array_equal(original,direct)
    identity=from_embeds(model,[x.clone() for x in state]);np.testing.assert_array_equal(identity,direct)
    if kind=='numbers':
        hh=[x[1:2].clone() for x in state];vv=[x[1:2].clone() for x in state];both=[x[1:2].clone() for x in state]
        hh[0]=state[0][0:1].clone();vv[1]=state[1][0:1].clone();both[0]=hh[0];both[1]=vv[1]
        hlog=from_embeds(model,hh);vlog=from_embeds(model,vv);blog=from_embeds(model,both)
        # Only number identities in the tile/vertex embeddings can change.
        torch.testing.assert_close(state[2][0],state[2][1],atol=0,rtol=0)
        torch.testing.assert_close(state[3][0],state[3][1],atol=0,rtol=0)
        np.testing.assert_allclose(blog[0],direct[0],atol=3e-5,rtol=2e-6)
        baseline=float(contrast(row,direct[0],kind));full=float(contrast(row,direct[1],kind))-baseline
        return dict(seed=row['seed'],stage=row['stage'],effect=full,
            restore_hex_number_embeddings_effect=float(contrast(row,hlog[0],kind))-baseline,
            restore_vertex_number_embeddings_effect=float(contrast(row,vlog[0],kind))-baseline,
            restore_both_effect=float(contrast(row,blog[0],kind))-baseline,
            identity_max_abs_error=float(np.max(abs(identity-direct))),
            full_restore_max_abs_error=float(np.max(abs(blog[0]-direct[0]))))
    # Restore only the two target-port vertex activations from generic-port
    # donor at equal production. The reciprocal remote port remains changed.
    target=list(PORT_VERTICES[row['target_port']]);remote=list(PORT_VERTICES[row['remote_port']]);out=[]
    for rows in (target,remote,target+remote):
        hybrid=[x[[1,3]].clone() for x in state]
        hybrid[1][:,rows,:]=state[1][[0,2]][:,rows,:]
        log=from_embeds(model,hybrid)
        cc=contrast(row,log,kind)-contrast(row,direct[[0,2]],kind)
        out.append((cc,log))
    for j in (0,2,3):
        torch.testing.assert_close(state[j][0],state[j][1],atol=0,rtol=0)
        torch.testing.assert_close(state[j][2],state[j][3],atol=0,rtol=0)
    np.testing.assert_allclose(out[2][1],direct[[0,2]],atol=3e-5,rtol=2e-6)
    effects=contrast(row,direct,kind)[[1,3]]-contrast(row,direct,kind)[[0,2]]
    return dict(seed=row['seed'],stage=row['stage'],low_port_effect=float(effects[0]),high_port_effect=float(effects[1]),interaction=float(effects[1]-effects[0]),
        restore_target_port_interaction=float(out[0][0][1]-out[0][0][0]),
        restore_remote_port_interaction=float(out[1][0][1]-out[1][0][0]),
        restore_all_port_interaction=float(out[2][0][1]-out[2][0][0]),
        restore_target_low_port_effect=float(out[0][0][0]),restore_target_high_port_effect=float(out[0][0][1]),
        identity_max_abs_error=float(np.max(abs(identity-direct))),
        full_restore_max_abs_error=float(np.max(abs(out[2][1]-direct[[0,2]]))))


def cluster_summary(rows,fields):
    if not rows:return {'rows':0,'boards':0}
    by=defaultdict(list)
    for row in rows:by[row['seed']].append(row)
    means=np.array([[np.mean([r[f] for r in rr]) for f in fields] for rr in by.values()])
    rng=np.random.default_rng(SEED+6);boot=np.empty((2000,len(fields)))
    for i in range(2000):boot[i]=means[rng.integers(len(means),size=len(means))].mean(0)
    return dict(rows=len(rows),boards=len(by),statistics={f:dict(mean=float(means[:,i].mean()),median=float(np.median(means[:,i])),fraction_positive=float((means[:,i]>0).mean()),
        ci95=np.quantile(boot[:,i],[.025,.975]).tolist()) for i,f in enumerate(fields)})


def run(args,selection):
    t=time.perf_counter();engine=OpeningEngine();model=engine.model.eval().requires_grad_(False)
    output=Path(args.out);rows_out={};patch_out={};benchmark={}
    for kind in ('ports','numbers','ports_control'):
        rows=selection['selected'][kind];enriched=[];patched=[];t0=time.perf_counter();batches=0
        patch_indices=set()
        rng=np.random.default_rng(SEED+99)
        for stage in ('B2','A2'):
            eligible=[i for i,r in enumerate(rows) if r['stage']==stage]
            patch_indices.update(rng.choice(eligible,min(args.patch_samples,len(eligible)),replace=False).tolist())
        nvariant=2 if kind=='numbers' else 4
        for start in range(0,len(rows),args.batch_size):
            chunk=rows[start:start+args.batch_size];ob=[observations(row,kind) for row in chunk];batch=np.concatenate(ob)
            with torch.inference_mode():scores=model(*split_obs(torch.from_numpy(batch)))[0][:,72:126].numpy().astype(float).reshape(len(chunk),nvariant,54)
            batches+=1
            for j,(row,obs,logits) in enumerate(zip(chunk,ob,scores)):
                cc=contrast(row,logits,kind);new=dict(row,contrast_scores=cc.tolist())
                if kind=='numbers':
                    new['effect']=float(cc[1]-cc[0]);new['variance_change_magnitude']=float(2*PIPS[row['old_number']]/36)
                    delta=logits[1]-logits[0];new['diversified_logit_change']=float(delta[row['became_diversified']].mean());new['duplicated_logit_change']=float(delta[row['became_duplicated']].mean())
                else:
                    new.update(low_port_effect=float(cc[1]-cc[0]),high_port_effect=float(cc[3]-cc[2]),interaction=float(cc[3]-cc[2]-cc[1]+cc[0]))
                new['greedy_choices']=[int(np.array(row['legal'])[np.argmax(s[row['legal']])]) for s in logits]
                enriched.append(new)
                if start+j in patch_indices:patched.append(patch(model,row,obs,kind))
            if batches%20==0:print(json.dumps(dict(event='evaluate',kind=kind,positions=min(start+args.batch_size,len(rows)),seconds=round(time.perf_counter()-t0,1))),flush=True)
        benchmark[kind]=dict(positions=len(rows),valid_board_forwards=len(rows)*nvariant,patch_positions=len(patched),seconds=time.perf_counter()-t0)
        rows_out[kind]=enriched;patch_out[kind]=patched
        write_json(output/(kind+'-rows.json'),enriched);write_json(output/(kind+'-patches.json'),patched)
    fields={'ports':['low_port_effect','high_port_effect','interaction'],'numbers':['effect'],'ports_control':['low_port_effect','high_port_effect','interaction']}
    pfields={'ports':['interaction','restore_target_port_interaction','restore_remote_port_interaction','restore_all_port_interaction'],
             'numbers':['effect','restore_hex_number_embeddings_effect','restore_vertex_number_embeddings_effect','restore_both_effect']}
    pfields['ports_control']=pfields['ports']
    summaries={kind:dict(all=cluster_summary(rows_out[kind],fields[kind]),by_stage={stage:cluster_summary([r for r in rows_out[kind] if r['stage']==stage],fields[kind]) for stage in ('B2','A2')},
        patches=cluster_summary(patch_out[kind],pfields[kind]),patches_by_stage={stage:cluster_summary([r for r in patch_out[kind] if r['stage']==stage],pfields[kind]) for stage in ('B2','A2')}) for kind in fields}
    summaries['numbers']['by_pair']={pair:cluster_summary([r for r in rows_out['numbers'] if r['pair']==pair],['effect']) for pair in sorted({r['pair'] for r in rows_out['numbers']})}
    summaries['numbers']['by_direction']={key:cluster_summary([r for r in rows_out['numbers'] if (r['old_number']<r['new_number'])==lower],['effect']) for key,lower in [('low_to_high',True),('high_to_low',False)]}
    summaries['ports']['by_resource']={name:cluster_summary([r for r in rows_out['ports'] if r['target_resource']==i],fields['ports']) for i,name in enumerate(('wood','brick','sheep','wheat','ore'))}
    summaries['ports']['production_shares']=cluster_summary(rows_out['ports'],['low_share','high_share'])
    summaries['ports_control']['production_shares']=cluster_summary(rows_out['ports_control'],['low_share','high_share'])
    assert sha(MODEL_PATH)==MODEL_SHA
    result=dict(schema='opening-followup-ports-numbers-v1',created_utc=datetime.now(timezone.utc).isoformat(),checkpoint_sha256=MODEL_SHA,
        configuration=vars(args),corpus_screen={k:v for k,v in selection.items() if k!='selected'},summary=summaries,benchmark=benchmark,
        validation=dict(global_vectors_hands_trade_rates_unchanged=True,all_native_replays_legal=True,
            resource_number_port_inventories_preserved=True,all_number_adjacency_restrictions_preserved=True,
            number_local_candidate_tiles_and_resource_pips_unchanged=True,port_local_candidate_tiles_unchanged=True,
            patch_identity_max_abs_error=max(r['identity_max_abs_error'] for k in patch_out for r in patch_out[k]),
            patch_full_restore_max_abs_error=max(r['full_restore_max_abs_error'] for k in patch_out for r in patch_out[k])),
        estimand='Mean within-board paired raw-logit contrast; board/stage sampled uniformly among eligible boards. Stage intervals resample board means; pooled intervals average repeated stages per board before resampling. 2000 percentile replicates.',
        caveats=['Frozen raw policy preferences, not win probabilities or strategically optimal choices.',
            'Eligibility selects particular valid swaps and surviving legal corners; does not represent every random opening.',
            'Remote reciprocal swaps necessarily alter global context. Port internal patches distinguish target from remote port pathways; number swaps still confound variance with number identity/remote context.',
            'Port test is immediate ownership on placement, not proximity or future route feasibility; candidate starting resources are unchanged.',
            'Internal hybrid activation patches are diagnostic interventions, not valid game states; pathway effects need not add or identify unique semantic neurons.'],
        runtime=dict(numpy=np.__version__,torch=str(torch.__version__),threads=torch.get_num_threads(),compiled_extensions={p.name:sha(p) for p in Path(catan_rl.__file__).resolve().parent.glob('*.so')}),
        source_sha256={p:sha(ROOT/p) for p in ['opening_followup_ports_numbers.py','opening_engine.py','analyze_number_diversification.py','train.py','gnn.py','catan/src/features.rs','viz/geometry.json','viz/inference.py']},
        elapsed_evaluation_seconds=time.perf_counter()-t)
    write_json(output/'results.json',result)
    print(json.dumps(dict(benchmark=benchmark,summary=summaries,validation=result['validation']),indent=2),flush=True)


def add_port_control(selection):
    """Same selected port positions, plus matched vs unavailable-resource 2:1.

    Uniformly choose an absent resource whose original port is unoccupied.
    Move that label to the target and the target's generic label to its old
    site in BOTH conditions. Then swap target and remote 2:1 labels only.
    Both endpoints remain valid inventories and all owned ports stay fixed.
    """
    rows=[];rng=np.random.default_rng(SEED+777);counts=Counter()
    for row in selection['selected']['ports']:
        occupied={a-72 for a in row['history'][::2]}
        qs=[q for q in range(5) if row['low_production_pips'][q]==0 and row['high_production_pips'][q]==0
            and not PORT_VERTICES[row['board'][2].index(q)]&occupied]
        if not qs:continue
        q=int(rng.choice(qs));qport=row['board'][2].index(q)
        low=variants(row,'ports')[0]
        low[2][row['target_port']]=q;low[2][qport]=5
        new=dict(row,board=[x.tolist() for x in low],comparator_type=q,mismatch_original_port=qport)
        rows.append(new);counts[row['stage']]+=1
    selection['selected']['ports_control']=rows
    selection['port_control_selection']=dict(selected_by_stage=dict(counts),eligible_from='The selected 2000 positions per stage of the main port study',
        comparator='2:1 port for a resource absent from both production portfolios; its production remains zero before and after concentration.')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--corpus',default=str(ROOT/'run/analysis/opening-study-100k-20261029'))
    ap.add_argument('--out',default=str(ROOT/'run/analysis/opening-followups-20261102/ports_numbers'))
    ap.add_argument('--samples',type=int,default=2000,help='Eligible boards per stage and study')
    ap.add_argument('--patch-samples',type=int,default=128,help='Random selected positions per stage for internal patches')
    ap.add_argument('--batch-size',type=int,default=32)
    ap.add_argument('--screen-boards',type=int,default=0,help='0 screens complete corpus; positive value for benchmark')
    ap.add_argument('--reuse-selection',action='store_true')
    args=ap.parse_args();torch.set_num_threads(1);torch.set_grad_enabled(False)
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    selpath=out/'selection.json'
    if args.reuse_selection:selection=json.loads(selpath.read_text())
    else:selection=screen(args);write_json(selpath,selection)
    add_port_control(selection)
    write_json(selpath,selection)
    run(args,selection)


if __name__=='__main__':main()
