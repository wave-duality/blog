#!/usr/bin/env python3
"""Experiment 8: matched A2 portfolios, greedy continuations and global patches.

No search/training. Uses actual actor-view observations from native legal replays.
The two interventions have equal total pips but different resources/location/hand;
this tests consequences of complete openings, not a pure latent 'plan' variable.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time

import catan_rl
import numpy as np
import torch
import torch.nn.functional as F

from opening_engine import OpeningEngine, MODEL_SHA, MODEL_PATH
from opening_study_scale import read_shard, atomic_json
from train import split_obs
from gnn import OTHER_ACTIONS

ROOT = Path(__file__).resolve().parent
CORPUS = ROOT/'run/analysis/opening-study-100k-20261029'
DEFAULT = ROOT/'run/analysis/opening-followups-20261102/plans-controlled'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def screen(out, count):
    """One score-independent, most contrasting matched pair per eligible board."""
    manifest = json.loads((CORPUS/'manifest.json').read_text())
    names = manifest['feature_names']
    cols = [names.index(n) for n in ['total_pips','adjacent_hexes',
            'local_resource_count','combined_resource_count','sheep_pips']]
    ports = [names.index(n) for n in ['direct_port','generic_port']]
    pp = [names.index(r+'_pips') for r in ['wood','brick','sheep','wheat','ore']]
    candidates = []
    seen = 0
    for path in sorted((CORPUS/'shards').glob('*.npz')):
        a = read_shard(path)
        for i, seed in enumerate(a['board_seed']):
            seen += 1
            lo, hi = a['position_ptr'][4*i+3:4*i+5]
            x = a['candidate_features'][lo:hi]
            vertices = a['candidate_vertex'][lo:hi]
            pip = x[:,pp]
            balance = pip[:,3]+pip[:,4]-pip[:,0]-pip[:,1]
            # Restrict both to no immediate port: do not compare port strategies.
            groups = {}
            for j in range(len(x)):
                if x[j,cols[0]] < 8 or x[j,ports[0]] != 0:
                    continue
                groups.setdefault(tuple(x[j,cols].astype(int)),[]).append(j)
            options = []
            for key, rows in groups.items():
                low = min(rows,key=lambda j:(float(balance[j]),int(vertices[j])))
                high = min(rows,key=lambda j:(-float(balance[j]),int(vertices[j])))
                gap = float(balance[high]-balance[low])
                if gap >= 6:
                    options.append((key[0],gap,-int(vertices[high]),-int(vertices[low]),high,low))
            if not options:
                continue
            *_, high, low = max(options)
            candidates.append(dict(seed=int(seed),board=[a['board_resources'][i].tolist(),
                a['board_numbers'][i].tolist(),a['board_ports'][i].tolist()],
                prefix=a['history'][i,:6].tolist(),
                ore_wheat_vertex=int(vertices[high]),wood_brick_vertex=int(vertices[low]),
                ore_wheat_pips=pip[high].tolist(),wood_brick_pips=pip[low].tolist(),
                match=dict(zip(['total_pips','adjacent_hexes','local_resource_count','combined_resource_count','sheep_pips'],
                               x[high,cols].astype(int).tolist())),
                logit_ore_wheat=float(a['candidate_logit'][lo+high]),
                logit_wood_brick=float(a['candidate_logit'][lo+low])))
        if seen % 20000 == 0:
            print(f'screen {seen}: {len(candidates)} eligible',flush=True)
    rng = np.random.default_rng(11023708)
    ids = rng.permutation(len(candidates))[:count]
    selected = [candidates[int(i)] for i in ids]
    data = dict(schema='opening-plan-matched-v1',model_sha256=MODEL_SHA,
        screened_boards=seen,eligible_boards=len(candidates),selected_boards=len(selected),
        selection_seed=11023708,selection='One pair per board; no port, >=8 local pips, equal total pips, sheep pips, hex count, local/combined resource count; OW-minus-WB contrast gap >=6, hence >=3 pips shifted from wood/brick to ore/wheat. Max total pips then contrast, vertex ties. No network scores used to select pairs.',
        corpus_manifest_sha256=sha(CORPUS/'manifest.json'),pairs=selected)
    atomic_json(out/'pairs.json',data)
    return data


@torch.inference_mode()
def evaluate(model, observations, legal_sets):
    obs = np.concatenate(observations,axis=0)
    logits,values = model(*split_obs(torch.from_numpy(obs)))
    scores = logits.numpy().copy()
    actions = []
    for i,legal in enumerate(legal_sets):
        order = np.lexsort((legal,-scores[i,legal]))
        if len(order)>1 and scores[i,legal[order[0]]]-scores[i,legal[order[1]]] < .001:
            z,v = model(*split_obs(torch.from_numpy(obs[i:i+1])))
            scores[i] = z[0].numpy()
            values[i] = v[0]
            order = np.lexsort((legal,-scores[i,legal]))
        actions.append(int(legal[order[0]]))
    return actions,scores,values.numpy().copy()


@torch.inference_mode()
def states(model,obs):
    h,v,p,g = split_obs(torch.from_numpy(obs))
    s = (F.relu(model.hex_embed(h)),F.relu(model.vertex_embed(v)),
         F.relu(model.path_embed(p)),F.relu(model.global_embed(g)))
    all_states=[s]
    for layer in model.layers:
        s=layer(*s);all_states.append(s)
    return all_states


@torch.inference_mode()
def heads(model,state):
    H,V,P,g=state
    logits=torch.zeros(H.shape[0],241)
    logits[:,:72]=model.road_head(P).squeeze(-1)
    logits[:,72:126]=model.settle_head(V).squeeze(-1)
    logits[:,126:180]=model.city_head(V).squeeze(-1)
    logits[:,185:204]=model.robber_head(H).squeeze(-1)
    logits[:,OTHER_ACTIONS]=model.other_head(g)
    return logits.numpy()


@torch.inference_mode()
def patch_global(model,oa,ob,common):
    """Paired first-Play snapshots: dose is global activation at layer boundary."""
    ss=states(model,np.concatenate([oa,ob]))
    actual=model(*split_obs(torch.from_numpy(np.concatenate([oa,ob]))))[0].numpy()
    np.testing.assert_allclose(heads(model,ss[-1]),actual,atol=3e-5,rtol=2e-6)
    d=actual[0,common].astype(float)-actual[1,common].astype(float);d-=d.mean()
    energy=float(d@d)
    result=[]
    for depth in range(len(ss)-1):
        target=[s[1:2].clone() for s in ss[depth]]
        identity=[s.clone() for s in target]
        donor=[s[0:1].clone() for s in ss[depth]]
        target[3]=donor[3]
        for layer in list(model.layers)[depth:]:
            target=layer(*target);identity=layer(*identity);donor=layer(*donor)
        zs=heads(model,target)[0];zi=heads(model,identity)[0];zd=heads(model,donor)[0]
        np.testing.assert_allclose(zi,actual[1],atol=3e-5,rtol=2e-6)
        np.testing.assert_allclose(zd,actual[0],atol=3e-5,rtol=2e-6)
        shift=zs[common].astype(float)-actual[1,common].astype(float);shift-=shift.mean()
        result.append(dict(depth=depth,projection_numerator=float(shift@d),
            full_difference_energy=energy,shift_energy=float(shift@shift),
            identity_max_error=float(np.max(abs(zi-actual[1])))))
    return result


def observation(bot, game):
    obs,actor=bot.value_observations(*game.board_arrays(),game.history(),game.to_act())
    assert actor==game.to_act() and obs.shape==(1,4752)
    return obs


def apply_recorded(row,action):
    game=row['game'];actor=int(game.to_act());turn=int(game.turn())
    cat=0 if action<72 else 1 if action<126 else 2 if action<180 else 3 if action==180 else None
    if cat is not None:
        row['counts_full'][actor,cat]+=1
        if turn<=40:row['counts_40'][actor,cat]+=1
        row['first'].setdefault(str(actor)+'_'+str(cat),turn)
    game.apply(action);row['decisions']+=1


def rollout_chunk(engine,pairs,out,chunk_id,max_turns):
    model=engine.model;bot=catan_rl.Bot(sims=0)
    rows=[]
    for pair in pairs:
        for condition in ['ore_wheat','wood_brick']:
            game=catan_rl.Game(seed=pair['seed'])
            assert [list(a) for a in game.board_arrays()]==pair['board']
            for action in pair['prefix']+[72+pair[condition+'_vertex']]:
                game.apply(action)
            rows.append(dict(game=game,pair=pair,condition=condition,
                counts_40=np.zeros((2,4),dtype=int),counts_full=np.zeros((2,4),dtype=int),
                first={},snapshot=None,decisions=0))
    actions,_,_=evaluate(model,[r['game'].opening_observation() for r in rows],
        [np.array(r['game'].legal()) for r in rows])
    for r,a in zip(rows,actions):
        r['game'].apply(a);r['opening']=[int(a) for _,a in r['game'].history()]
    active=list(rows);t0=time.monotonic();iterations=0
    while active:
        ready=[]
        for row in active:
            game=row['game']
            while game.is_chance() and not game.is_terminal():game.resolve_chance()
            if game.is_terminal() or game.turn()>=max_turns:
                continue
            legal=np.asarray(game.legal(),dtype=np.int64)
            if len(legal)==1:
                apply_recorded(row,int(legal[0]));continue
            obs=observation(bot,game)
            # First actual Play decision with a choice for player A.
            phase=int(np.argmax(obs[0,-400+126:-400+139]))
            if row['snapshot'] is None and game.to_act()==0 and phase==3:
                row['snapshot']=dict(obs=obs.copy(),legal=legal.tolist(),turn=int(game.turn()))
            ready.append((row,obs,legal))
        if ready:
            for start in range(0,len(ready),32):
                block=ready[start:start+32]
                selected,_,_=evaluate(model,[o for _,o,_ in block],[l for _,_,l in block])
                for (row,obs,legal),action in zip(block,selected):
                    apply_recorded(row,action)
        active=[r for r in active if not r['game'].is_terminal() and r['game'].turn()<max_turns]
        iterations+=1
        if iterations%300==0:
            print(f'chunk {chunk_id}: step {iterations}, active {len(active)}, {time.monotonic()-t0:.1f}s',flush=True)
    saved=[];patches=[]
    for i,pair in enumerate(pairs):
        a,b=rows[2*i:2*i+2]
        if a['snapshot'] is not None and b['snapshot'] is not None:
            common=sorted(set(a['snapshot']['legal'])&set(b['snapshot']['legal']))
            # Same turn avoids transplanting representations across game ages.
            if len(common)>=2 and a['snapshot']['turn']==b['snapshot']['turn']:
                patches.append(dict(seed=pair['seed'],turn=a['snapshot']['turn'],common=common,
                    depths=patch_global(model,a['snapshot']['obs'],b['snapshot']['obs'],common)))
        for row in (a,b):
            game=row['game']
            saved.append(dict(seed=pair['seed'],condition=row['condition'],opening=row['opening'],
                counts_through_turn40=row['counts_40'].tolist(),counts_full=row['counts_full'].tolist(),
                first=row['first'],terminal=game.is_terminal(),turn=int(game.turn()),
                outcome=int(game.outcome()),decisions=row['decisions'],history=game.history()))
    atomic_json(out/f'chunk-{chunk_id:04}.json',dict(rows=saved,patches=patches,
        seconds=time.monotonic()-t0,max_turns=max_turns,model_sha256=MODEL_SHA))


def summarize(out,config):
    chunks=[json.loads(p.read_text()) for p in sorted(out.glob('chunk-*.json'))]
    rows=[r for c in chunks for r in c['rows']]
    pairs={}
    for r in rows:pairs.setdefault(r['seed'],{})[r['condition']]=r
    assert len(pairs)==config['selected_boards']
    assert all(set(p)=={'ore_wheat','wood_brick'} for p in pairs.values())
    def summ(a,b):
        a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float);d=a-b
        se=float(d.std(ddof=1)/np.sqrt(len(d)))
        return dict(ore_wheat=float(a.mean()),wood_brick=float(b.mean()),
            paired_difference=float(d.mean()),paired_95=[float(d.mean()-1.96*se),float(d.mean()+1.96*se)],boards=len(d))
    metrics={}
    ordered=list(pairs.values())
    for cat,name in enumerate(['roads','settlements','cities','development_cards']):
        for mode in ['count','any']:
            av=[p['ore_wheat']['counts_through_turn40'][0][cat] for p in ordered]
            bv=[p['wood_brick']['counts_through_turn40'][0][cat] for p in ordered]
            if mode=='any':av=np.asarray(av)>0;bv=np.asarray(bv)>0
            metrics[name+'_'+mode+'_by_turn40']=summ(av,bv)
    metrics['A_win']=summ([p['ore_wheat']['outcome']==1 for p in ordered],
                           [p['wood_brick']['outcome']==1 for p in ordered])
    patch_rows=[r for c in chunks for r in c['patches']]
    patch_summary=[]
    for depth in range(4):
        x=np.array([[r['depths'][depth]['projection_numerator'],r['depths'][depth]['full_difference_energy']] for r in patch_rows])
        if len(x) and x[:,1].sum()>1e-10:
            ratio=float(x[:,0].sum()/x[:,1].sum())
            influence=(x[:,0]-ratio*x[:,1])/x[:,1].mean()
            se=float(influence.std(ddof=1)/np.sqrt(len(x))) if len(x)>1 else 0
            patch_summary.append(dict(depth=depth,boards=len(x),directional_transfer=ratio,
                pointwise_95=[ratio-1.96*se,ratio+1.96*se],
                identity_max_error=max(r['depths'][depth]['identity_max_error'] for r in patch_rows)))
    result=dict(schema='opening-plan-continuations-v1',model_sha256=MODEL_SHA,
        screened_boards=config['screened_boards'],eligible_boards=config['eligible_boards'],
        paired_boards=len(pairs),games=len(rows),terminal_games=sum(r['terminal'] for r in rows),
        truncated_games=sum(not r['terminal'] for r in rows),selection=config['selection'],
        policy='Both seats frozen Generation37, greedy legal policy, no search/no noise/no resignation; 500-turn cap. Common initial RNG state within each board pair; different boards have distinct seeded streams. Later draws/steals can desynchronize the streams.',
        metrics=metrics,global_patches=patch_summary,patch_pairs=len(patch_rows),
        patch_meaning='At first A Play choice, only if same turn and at least two common legal actions, replace whole global vector of WB target with OW donor at each boundary. Directional projection onto centered donor-minus-target legal logits. Not percentage of a concept or proof of a plan; patch is a hybrid activation state.',
        units={'counts':'Building/buying actions by A through global turn40, excluding setup; roads include development-card roads. any is fraction with at least one such action.'},
        caveats=['Matched exact total production, sheep production, local resource count, total resource coverage and adjacent hex count; geometry, numbers, immediate cards and roads can differ.',
                 'Selected forced alternative openings, not representative of usual greedy openings; no claim that one strategy wins more in general.',
                 'One rollout per condition per independent board; paired intervals measure sampling uncertainty across these boards, not model or specification uncertainty.',
                 'Counts have four primary outcomes; CIs are pointwise, exploratory. No tuning after seeing rollout outcomes.'],
        script_sha256=sha(__file__),pairs_sha256=sha(out/'pairs.json'))
    atomic_json(out/'results.json',result)
    print(json.dumps(result,indent=2),flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,default=DEFAULT)
    p.add_argument('--pairs',type=int,default=2048)
    p.add_argument('--chunk-pairs',type=int,default=32)
    p.add_argument('--max-turns',type=int,default=500)
    p.add_argument('--screen-only',action='store_true')
    p.add_argument('--summarize-only',action='store_true')
    args=p.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    config=json.loads((args.out/'pairs.json').read_text()) if (args.out/'pairs.json').exists() else screen(args.out,args.pairs)
    assert config['selected_boards']==args.pairs
    if args.screen_only:return
    if not args.summarize_only:
        engine=OpeningEngine();engine.model.requires_grad_(False)
        for start in range(0,args.pairs,args.chunk_pairs):
            idx=start//args.chunk_pairs;dest=args.out/f'chunk-{idx:04}.json'
            if dest.exists():
                saved=json.loads(dest.read_text());assert saved['max_turns']==args.max_turns
                assert [r['seed'] for r in saved['rows'][::2]]==[r['seed'] for r in config['pairs'][start:start+args.chunk_pairs]]
                continue
            rollout_chunk(engine,config['pairs'][start:start+args.chunk_pairs],args.out,idx,args.max_turns)
        assert sha(MODEL_PATH)==MODEL_SHA
    summarize(args.out,config)


if __name__=='__main__':main()
