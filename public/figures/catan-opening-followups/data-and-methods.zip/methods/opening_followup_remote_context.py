#!/usr/bin/env python3
"""Equal-number remote resource swaps for A1 fallback sensitivity.

Target and comparison are the original policy's top two A1 corners. Swap two
non-desert resources on equal-number hexes touching neither. Resource counts,
every site's total pips, board-wide resource pips, ports, and both focal input
vertex rows remain fixed. Select swaps that change the contrast in exact
worst-reply resource coverage; compare preferences and partial input patches.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
import torch
import catan_rl
from opening_engine import OpeningEngine,MODEL_PATH,MODEL_SHA
from train import split_obs
from opening_followup_blocking_fallback import DEFAULT_SOURCE,DEFAULT_OUT,load,all_rp,sha,mean_ci,library
from opening_followup_opponent_relocation import embeddings,complete
from feature_dictionary import geometry_data
from opening_study_scale_analysis import atomic_json

@torch.inference_mode()
def run(source,out,n=1000):
    started=time.monotonic();out.mkdir(parents=True,exist_ok=True);torch.set_num_threads(1);geometry,distance=geometry_data()
    closed=np.array([sum(1<<j for j in np.flatnonzero(row<=1)) for row in distance],np.uint64);fn=library(out)
    m=json.loads((source/'manifest.json').read_text());arrays={k:[] for k in ['seed','resources','numbers','ports','rp','fallback','logits']}
    for rec in m['shards']:
        s=load(source/rec['path']);keep=~s['train'];rp=all_rp(s);cache=load(out/'cache'/Path(rec['path']).name)['fallback']
        lo=s['position_ptr'][::4][:-1];rows=lo[:,None]+np.arange(54)
        for key,val in [('seed',s['board_seed']),('resources',s['board_resources']),('numbers',s['board_numbers']),('ports',s['board_ports']),('rp',rp),('fallback',cache),('logits',s['candidate_logit'][rows])]:arrays[key].append(val[keep])
    arrays={k:np.concatenate(v) for k,v in arrays.items()};order=np.random.default_rng(141237).permutation(len(arrays['seed']))
    touching=np.zeros((54,19),bool)
    for v,hs in enumerate(geometry['vertex_hexes']):
        for h in hs:
            if h is not None and h>=0:touching[v,h]=True
    selected=[];scanned=0;PIPS=np.array([0,0,1,2,3,4,5,0,5,4,3,2,1])
    for bi in order:
        scanned+=1;resources=arrays['resources'][bi];numbers=arrays['numbers'][bi];ports=arrays['ports'][bi];rp=arrays['rp'][bi]
        rank=np.lexsort((np.arange(54),-arrays['logits'][bi]));a,b=map(int,rank[:2]);outside=~(touching[a]|touching[b]);swaps=[];rps=[]
        for h in range(19):
            for k in range(h+1,19):
                if not(outside[h] and outside[k] and numbers[h]==numbers[k] and resources[h]!=resources[k] and resources[h]<5 and resources[k]<5):continue
                r=rp.copy();x,y=int(resources[h]),int(resources[k]);pip=PIPS[numbers[h]]
                r[touching[:,h],x]-=pip;r[touching[:,h],y]+=pip;r[touching[:,k],y]-=pip;r[touching[:,k],x]+=pip
                np.testing.assert_array_equal(r[[a,b]],rp[[a,b]]);np.testing.assert_array_equal(r.sum(1),rp.sum(1))
                rps.append(r);swaps.append((h,k))
        if not swaps:continue
        rps=np.ascontiguousarray(rps,np.float32);f=np.empty((len(swaps),54,12),np.float32);fn(len(swaps),rps,closed,f)
        baseline=arrays['fallback'][bi];delta=(f[:,a,3]-f[:,b,3])-(baseline[a,3]-baseline[b,3]);possible=np.flatnonzero(delta!=0)
        if not len(possible):continue
        coverdelta=(f[:,a,4]-f[:,b,4])-(baseline[a,4]-baseline[b,4])
        ix=int(sorted(possible,key=lambda j:(-abs(float(delta[j])),-abs(float(coverdelta[j])),swaps[j]))[0]);h,k=swaps[ix]
        nr=resources.copy();nr[h],nr[k]=resources[k],resources[h]
        sourcegame=catan_rl.Game.from_opening(resources.astype(int).tolist(),numbers.astype(int).tolist(),ports.astype(int).tolist(),[])
        donorgame=catan_rl.Game.from_opening(nr.astype(int).tolist(),numbers.astype(int).tolist(),ports.astype(int).tolist(),[])
        obs=sourcegame.opening_observation();donor=donorgame.opening_observation();sv=split_obs(torch.from_numpy(obs));dv=split_obs(torch.from_numpy(donor))
        assert all(np.array_equal(sv[i].numpy(),dv[i].numpy()) for i in [2,3]);assert np.array_equal(sv[1][0,[a,b]].numpy(),dv[1][0,[a,b]].numpy())
        assert sourcegame.legal()==donorgame.legal()
        selected.append(dict(seed=int(arrays['seed'][bi]),target=a,comparison=b,swap=[h,k],coverage_contrast_change=float(delta[ix]),complement_count_contrast_change=float(coverdelta[ix]),
            source_fallback=baseline[[a,b],:6].tolist(),donor_fallback=f[ix,[a,b],:6].tolist(),source_resources=resources.astype(int).tolist(),source_numbers=numbers.astype(int).tolist(),ports=ports.astype(int).tolist(),obs=obs,donor_obs=donor))
        if len(selected)==n:break
    assert len(selected)==n,(len(selected),scanned)
    engine=OpeningEngine();model=engine.model;model.requires_grad_(False);assert sha(MODEL_PATH)==MODEL_SHA
    scored=[];val=dict(valid_native_board_pairs=n,focal_vertex_rows_unchanged=True,path_and_global_inputs_unchanged=True,all_local_total_pips_unchanged=True,board_resource_pip_totals_unchanged=True,identity_max_error=0.,full_patch_max_error=0.)
    for start in range(0,n,32):
        rows=selected[start:start+32];os=np.concatenate([r['obs'] for r in rows]);od=np.concatenate([r['donor_obs'] for r in rows]);ss=embeddings(model,os);ds=embeddings(model,od)
        z=complete(model,ss);zd=complete(model,ds);patches={}
        for label,indices in [('hex_only',[0]),('derived_vertex_only',[1]),('hex_and_vertex',[0,1])]:
            state=list(ss)
            for index in indices:state[index]=ds[index]
            patches[label]=complete(model,tuple(state))
        assert np.max(np.abs(patches['hex_and_vertex']-zd))<5e-5
        val['full_patch_max_error']=max(val['full_patch_max_error'],float(np.max(np.abs(patches['hex_and_vertex']-zd))))
        if start==0:
            identity=complete(model,tuple(s.clone() for s in ss));val['identity_max_error']=float(np.max(np.abs(z-identity)));assert val['identity_max_error']<5e-5
            np.testing.assert_allclose(model(*split_obs(torch.from_numpy(os)))[0][:,72:126].numpy(),z,atol=5e-5,rtol=0)
        for i,r in enumerate(rows):
            a,b=r['target'],r['comparison'];margin=float(z[i,a]-z[i,b]);donormargin=float(zd[i,a]-zd[i,b]);clean={k:v for k,v in r.items() if k not in ['obs','donor_obs']}
            clean.update(source_margin=margin,donor_margin=donormargin,margin_change=donormargin-margin,
                patches={k:float(v[i,a]-v[i,b])-margin for k,v in patches.items()},source_full_choice=int(z[i].argmax()),donor_full_choice=int(zd[i].argmax()))
            scored.append(clean)
    delta=np.array([r['margin_change'] for r in scored]);coverage=np.array([r['coverage_contrast_change'] for r in scored]);parts={}
    for key in ['hex_only','derived_vertex_only','hex_and_vertex']:
        p=np.array([r['patches'][key] for r in scored]);num=p*delta;den=delta**2;ratio=num.mean()/den.mean();influence=(num-ratio*den)/den.mean();se=influence.std(ddof=1)/np.sqrt(n)
        parts[key]=dict(directional_transfer=float(ratio),ci95=[float(ratio-1.96*se),float(ratio+1.96*se)],mean_absolute_margin_shift=float(np.mean(np.abs(p))))
    correlation=float(np.corrcoef(delta,coverage)[0,1])
    result=dict(schema='opening-remote-context-v1',boards=n,heldout_boards_screened=scanned,selection_rng_seed=141237,model_sha256=MODEL_SHA,
        measures=dict(mean_absolute_margin_change=mean_ci(abs(delta)),mean_robustness_aligned_margin_change=mean_ci(delta*np.sign(coverage)),
            moves_margin_toward_improved_coverage=mean_ci(delta*coverage>0),reverses_focal_ranking=mean_ci(np.array([r['donor_margin'] for r in scored])<0),
            changes_full_greedy_choice=mean_ci(np.array([r['source_full_choice']!=r['donor_full_choice'] for r in scored])),
            pearson_margin_change_vs_coverage_contrast_change=correlation),patches=parts,validation=val,
        methods=dict(selection='Random permutation of original20k held-out boards, seed141237; take first1000 eligible. Focal corners are original top-two A1 logits. Eligible equal-number resource swaps touch neither focal corner and change their exact worst-reply resource-coverage contrast. Choose largest absolute contrast change, then largest all-five-complement-count contrast change, then hex IDs. No evaluation of changed-board policy used in selection.',
            control='Swap two non-desert resource labels at equal-number hexes. All number tokens, resource inventory, every corner total pips, board-wide pips for each resource, ports and both focal raw vertex rows stay fixed. Native engine reconstructs both boards. All path/global input entries also verified identical.',
            activation='At input embedding boundary, replace only changed hex embeddings, only derived vertex embeddings, or both with their donor values; all unchanged rows are equal. Rerun complete trunk and settlement head. Identity and full-change positive controls pass.',
            directional_transfer='sum(patched margin shift × full margin shift) / sum(full margin shift²). Signed projection, not explained variance or percentage of a concept; pathways interact and transfers need not sum to1.',
            uncertainty='One paired board counterfactual each; normal95%CI for board means and delta-method95%CI for projection. Conditional on selected counterfactual family and frozen policy.',
            limitation='Remote resource swaps also change expansion and distant-port opportunities; a relationship with coverage robustness does not isolate a fallback algorithm or prove minimax planning.'),
        script_sha256=sha(__file__),source_manifest_sha256=sha(source/'manifest.json'),elapsed_seconds=time.monotonic()-started)
    atomic_json(out/'remote-context.json',result);atomic_json(out/'remote-context-pairs.json',dict(pairs=scored));print(json.dumps(result['measures'],indent=2),flush=True)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,default=DEFAULT_SOURCE);p.add_argument('--out',type=Path,default=DEFAULT_OUT);p.add_argument('--boards',type=int,default=1000);a=p.parse_args();run(a.source,a.out,a.boards)
