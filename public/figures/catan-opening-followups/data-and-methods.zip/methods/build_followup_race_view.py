"""A paired road-race illustration using the existing game's SVG renderer."""
import json
from pathlib import Path
from build_opening_theory_reader import live_renderer

ROOT=Path(__file__).resolve().parent
RUN=ROOT/'run/analysis/opening-followups-20261102'
OUT=RUN/'publication'


def main():
    rows=json.loads((RUN/'hands_roads/roads-cases.json').read_text())
    switches=sorted((r for r in rows if r['choice_away']!=r['choice_toward']),key=lambda r:r['seed'])
    stays=sorted((r for r in rows if r['choice_away']==r['choice_toward']),key=lambda r:r['seed'])
    chosen=switches[:2]+stays[:2]
    data=dict(geometry=json.loads((ROOT/'viz/geometry.json').read_text()),cases=chosen)
    html=r'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Paired road-race positions</title>
<style>*{box-sizing:border-box}body{margin:0;padding:12px 18px;background:#fff;color:#262626;font:17px/1.5 Georgia,serif}button,select{font:inherit;background:#fff;color:inherit;border:1px solid #bbb;border-radius:3px;padding:5px 10px}button{cursor:pointer}button[aria-pressed=true]{background:#f0f0f0;border-color:#555}header{display:flex;gap:10px;flex-wrap:wrap;align-items:center}p{margin:10px 0}svg{width:100%;max-height:500px;display:block;margin:auto}#caption{font-size:15px;color:#555}#scores{font-variant-numeric:tabular-nums;border-top:1px solid #ddd;padding-top:10px}small{color:#707070;display:block;font-size:13px}button:focus-visible,select:focus-visible{outline:2px solid #4177a5;outline-offset:2px}</style>
<header><label for="example">Board</label><select id="example"></select><button id="away" aria-pressed="true">B points away</button><button id="toward" aria-pressed="false">B points toward</button></header>
<p id="context">A is choosing its A2 starting road. The dashed blue road enters the race for the gold edge. With both roads pointing inward, either player could claim that edge on their next build.</p>
<svg id="board" role="img"></svg><p id="scores"></p><p id="caption">The settlements and A’s available roads stay fixed. Only B2’s road changes. The gold edge is contested road space; claiming it does not automatically cut off every route.</p><small>Illustrative sample: two boards where the choice changes and two where it stays the same. Percentages are legal-policy softmax preferences; actual play takes the highest score.</small>
<script>'use strict';const DATA=/*DATA*/;const NS='http://www.w3.org/2000/svg';let GEO=DATA.geometry,CENTER,BOARD,S;
/*RENDERER*/
CENTER=[HX(9),HY(9)];let index=0,toward=false;const $=id=>document.getElementById(id);function showTip(){}function hideTip(){}
function edge(root,e,attrs){const [v,w]=GEO.path_vertices[e];return el('line',{x1:VX(v),y1:VY(v),x2:VX(w),y2:VY(w),...attrs},root)}
function draw(){const c=DATA.cases[index],history=toward?c.toward_history:c.away_history;BOARD={res:c.board[0],num:c.board[1],port:c.board[2]};S={vertex:Array(54).fill(0),path:Array(72).fill(0),robber:c.board[0].indexOf(5)};justBuilt=null;
history.forEach((a,i)=>{const actor=[0,1,1,0][Math.floor(i/2)];if(a<72)S.path[a]=actor===0?2:1;else S.vertex[a-72]=actor===0?3:1});const root=$('board');root.replaceChildren();root.setAttribute('viewBox','-470 -185 1040 970');root.setAttribute('aria-label',`Board ${c.seed}, settlements A1 B1 B2 A2. B road points ${toward?'toward':'away from'} the contested edge.`);drawPorts(root);drawHexes(root);drawGlyphs(root);drawTokens(root);drawRobber(root);drawPieces(root);
const over=g(root);edge(over,c.motif.contested_edge,{stroke:'#b88622','stroke-width':9,'stroke-dasharray':'10 7','stroke-linecap':'round'});edge(over,c.motif.a_toward,{stroke:'#3e6fa8','stroke-width':8,'stroke-dasharray':'8 6','stroke-linecap':'round'});
history.forEach((a,i)=>{if(a<72)return;const v=a-72,label=['A1','B1','B2','A2'][i/2],x=VX(v),y=VY(v)-24;el('rect',{x:x-19,y:y-14,width:38,height:26,rx:4,fill:'#fff',stroke:'#ddd'},over);txt(over,x,y,label,{'font-size':19,'font-weight':600,fill:label[0]==='A'?'#3e6fa8':'#d9583f'})});
const prob=toward?c.race_preference_toward:c.race_preference_away,choice=toward?c.choice_toward:c.choice_away;$('scores').textContent=`Preference for entering the race: ${(100*prob).toFixed(1)}%. Highest-scoring move: ${choice===c.motif.a_toward?'enter the race':'take another road'}.`;$('away').setAttribute('aria-pressed',String(!toward));$('toward').setAttribute('aria-pressed',String(toward))}
DATA.cases.forEach((c,i)=>{const o=document.createElement('option');o.value=i;o.textContent=c.seed;$('example').appendChild(o)});$('example').onchange=e=>{index=Number(e.target.value);draw()};$('away').onclick=()=>{toward=false;draw()};$('toward').onclick=()=>{toward=true;draw()};draw();window.RACE_VIEW={data:DATA,draw};</script></html>'''
    html=html.replace('<header>','<main id="figure"><header>',1).replace('<script>','</main><script>',1)
    resize="""const figure=document.getElementById('figure');let lastHeight=0;
function measure(){const height=Math.ceil(figure.getBoundingClientRect().height+26);if(height!==lastHeight){lastHeight=height;parent.postMessage({type:'catan-figure-resize',height},'*')}}
new ResizeObserver(measure).observe(figure);addEventListener('message',e=>{if(e.source===parent&&e.data?.type==='catan-figure-measure'){lastHeight=0;measure()}});measure();"""
    html=html.replace('</script>',resize+'</script>')
    html=html.replace('/*DATA*/',json.dumps(data,separators=(',',':')).replace('<','\\u003c')).replace('/*RENDERER*/',live_renderer())
    OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'road-race-examples.html').write_text(html)
    print(OUT/'road-race-examples.html')


if __name__=='__main__':main()
