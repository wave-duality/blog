#!/usr/bin/env python3
"""Paired full-game B2 denial test, with production/start-card/port matching.

Run .venv/bin/python opening_followup_denial_continuations.py. Uses helpers from
opening_followup_plans.py for exact frozen greedy decisions and observations.
"""
import argparse, json, time
from pathlib import Path
import numpy as np
import torch
import catan_rl
from opening_engine import OpeningEngine, MODEL_SHA, MODEL_PATH
from opening_followup_plans import evaluate, observation
from opening_followup_blocking_fallback import DEFAULT_SOURCE, DEFAULT_OUT, load, all_rp, sha, mean_ci
from opening_study_scale_analysis import atomic_json
from feature_dictionary import geometry_data


def select(source,out,n=1024):
    manifest=json.loads((source/'manifest.json').read_text());_,dist=geometry_data();names=manifest['feature_names']
    matching=['wood_pips','brick_pips','sheep_pips','wheat_pips','ore_pips',
        'wood_starting_cards','brick_starting_cards','sheep_starting_cards','wheat_starting_cards','ore_starting_cards',
        'adjacent_hexes','direct_port','generic_port','wood_port','brick_port','sheep_port','wheat_port','ore_port']
    mix=[names.index(k) for k in matching];pairs=[];scanned=0
    for rec in manifest['shards']:
        shard=load(source/rec['path']);rp=all_rp(shard);pips=rp.sum(2)
        for bi in np.flatnonzero(~shard['train']):
            scanned+=1;lo,hi=shard['position_ptr'][bi*4+2:bi*4+4];v=shard['candidate_vertex'][lo:hi].astype(int);f=shard['candidate_features'][lo:hi]
            denied=pips[bi,v].max()-np.where(dist[v][:,v]>1,pips[bi,v][None,:],-1).max(1)
            _,groups=np.unique(f[:,mix].astype(int),axis=0,return_inverse=True);alternatives=[]
            for group in np.unique(groups):
                ids=np.flatnonzero(groups==group)
                if len(ids)<2 or f[ids[0],0]<8:continue
                gap=float(denied[ids].max()-denied[ids].min())
                if gap<1:continue
                h=int(ids[np.lexsort((v[ids],-denied[ids]))[0]]);l=int(ids[np.lexsort((v[ids],denied[ids]))[0]])
                alternatives.append((gap,float(f[h,0]),int(v[h]),int(v[l]),h,l))
            if not alternatives:continue
            gap,pip,hv,lv,h,l=sorted(alternatives,key=lambda a:(-a[0],-a[1],a[2],a[3]))[0]
            np.testing.assert_array_equal(f[h,mix],f[l,mix])
            pairs.append(dict(seed=int(shard['board_seed'][bi]),board=[shard[k][bi].astype(int).tolist() for k in ['board_resources','board_numbers','board_ports']],
                prefix=shard['history'][bi,:4].astype(int).tolist(),high_denial_vertex=hv,low_denial_vertex=lv,
                high_denial_loss=float(denied[h]),low_denial_loss=float(denied[l]),shared_total_pips=pip,shared_features=dict(zip(matching,f[h,mix].astype(int).tolist()))))
    eligible=len(pairs); assert eligible>=n
    selected=np.random.default_rng(121437).permutation(eligible)[:n]
    pairs=sorted([pairs[int(i)] for i in selected],key=lambda p:p['seed'])
    config=dict(paired_boards=n,eligible_heldout_boards=eligible,selection_rng_seed=121437,screened_heldout_boards=scanned,original_heldout_boards=20000,matching_features=matching,minimum_candidate_pips=8,
        selection='Uniform sample of1024 eligible held-out boards without replacement, fixed RNG seed121437. Within each board choose highest difference in best-A2-pip loss; then highest common total pips, then smallest high/low vertex IDs. Selection never uses network logits, values or outcomes.',
        pairs=pairs,source_manifest_sha256=sha(source/'manifest.json'),model_sha256=MODEL_SHA)
    atomic_json(out/'pairs.json',config);return config

@torch.inference_mode()
def play(model,pairs,out,chunk,max_turns=500):
    bot=catan_rl.Bot(sims=0);rows=[];t0=time.monotonic()
    for pair in pairs:
        for cond in ['high_denial','low_denial']:
            game=catan_rl.Game(seed=pair['seed']);assert [list(a) for a in game.board_arrays()]==pair['board']
            for action in pair['prefix']+[72+pair[cond+'_vertex']]:assert action in game.legal();game.apply(action)
            rows.append(dict(game=game,pair=pair,condition=cond,decisions=0))
    for setupstep in range(3):
        actions,_,_=evaluate(model,[r['game'].opening_observation() for r in rows],[np.asarray(r['game'].legal()) for r in rows])
        for r,a in zip(rows,actions):r['game'].apply(a)
    for row in rows:row['opening']=[int(a) for _,a in row['game'].history()];assert len(row['opening'])==8
    active=list(rows)
    while active:
        ready=[]
        for row in active:
            game=row['game']
            while game.is_chance() and not game.is_terminal():game.resolve_chance()
            if game.is_terminal() or game.turn()>=max_turns:continue
            legal=np.asarray(game.legal(),dtype=np.int64)
            if len(legal)==1:game.apply(int(legal[0]));row['decisions']+=1;continue
            ready.append((row,observation(bot,game),legal))
        for start in range(0,len(ready),32):
            block=ready[start:start+32];actions,_,_=evaluate(model,[o for _,o,_ in block],[l for _,_,l in block])
            for (row,_,_),action in zip(block,actions):row['game'].apply(action);row['decisions']+=1
        active=[r for r in active if not r['game'].is_terminal() and r['game'].turn()<max_turns]
    saved=[]
    for row in rows:
        g=row['game'];saved.append(dict(seed=row['pair']['seed'],condition=row['condition'],opening=row['opening'],terminal=bool(g.is_terminal()),turn=int(g.turn()),
            outcome=int(g.outcome()) if g.is_terminal() else None,decisions=row['decisions']))
    atomic_json(out/f'chunk-{chunk:04}.json',dict(rows=saved,seconds=time.monotonic()-t0,model_sha256=MODEL_SHA,max_turns=max_turns))
    print(f'Continuation chunk {chunk}, {len(saved)}games, {time.monotonic()-t0:.1f}s',flush=True)


def summarize(out,config):
    chunks=[json.loads(p.read_text()) for p in sorted(out.glob('chunk-*.json'))];rows=[r for c in chunks for r in c['rows']]
    pairs={}
    for r in rows:pairs.setdefault(r['seed'],{})[r['condition']]=r
    assert len(pairs)==config['paired_boards'];ordered=list(pairs.values());assert all(len(p)==2 for p in ordered)
    complete=[p for p in ordered if p['high_denial']['terminal'] and p['low_denial']['terminal']]
    def comparison(a,b):
        a=np.asarray(a,float);b=np.asarray(b,float);return dict(high_denial=float(a.mean()),low_denial=float(b.mean()),paired_difference=mean_ci(a-b))
    metrics={}
    if complete:
        metrics['B_win_completed_pairs']=comparison([p['high_denial']['outcome']==-1 for p in complete],[p['low_denial']['outcome']==-1 for p in complete])
        metrics['turns_completed_pairs']=comparison([p['high_denial']['turn'] for p in complete],[p['low_denial']['turn'] for p in complete])
    # Sharp bounds for censored games: assign each missing outcome0/1.
    low=[];high=[]
    for p in ordered:
        h=p['high_denial'];l=p['low_denial'];hw=float(h['outcome']==-1);lw=float(l['outcome']==-1)
        low.append((hw if h['terminal'] else 0)-(lw if l['terminal'] else 1));high.append((hw if h['terminal'] else 1)-(lw if l['terminal'] else 0))
    metrics['all_pairs_B_win_difference_censoring_bounds']=[float(np.mean(low)),float(np.mean(high))]
    result=dict(schema='opening-denial-continuations-v1',model_sha256=MODEL_SHA,paired_boards=len(ordered),games=len(rows),completed_pairs=len(complete),
        terminal_games=sum(r['terminal'] for r in rows),truncated_games=sum(not r['terminal'] for r in rows),metrics=metrics,
        mean_best_reply_pips_loss_high=float(np.mean([p['high_denial_loss'] for p in config['pairs']])),mean_best_reply_pips_loss_low=float(np.mean([p['low_denial_loss'] for p in config['pairs']])),
        screened_heldout_boards=config['screened_heldout_boards'],eligible_heldout_boards=config['eligible_heldout_boards'],selection_rng_seed=config['selection_rng_seed'],selection=config['selection'],matching_features=config['matching_features'],
        policy='Both seats frozen Generation37, greedy legal decisions, no search/no noise/no resignation. Complete B2 road and A2 settlement/road greedily, then play to terminal or500turn cap. Within each pair use same initial seed/RNG state; later stochastic events can desynchronize streams.',
        uncertainty='One continuation per condition per independent board. Paired board mean difference and normal95%CI; conditional on matched selection and this frozen policy. Selection fixed before outcome evaluation.',
        interpretation='A comparison of forced complete-game counterfactuals matched on own production, starting resource cards and direct-port type. Differences in geometry, number identities/correlations, distant ports, road opportunities and chosen followup actions remain, so the win-rate difference cannot be attributed solely to denial.',
        script_sha256=sha(__file__),pairs_sha256=sha(out/'pairs.json'),helper_sha256=sha(ROOT/'opening_followup_plans.py'))
    atomic_json(out/'results.json',result);return result

ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,default=DEFAULT_SOURCE);p.add_argument('--out',type=Path,default=DEFAULT_OUT/'continuations');p.add_argument('--pairs',type=int,default=1024);p.add_argument('--chunk-pairs',type=int,default=32);a=p.parse_args()
    a.out.mkdir(parents=True,exist_ok=True);torch.set_num_threads(1);assert sha(MODEL_PATH)==MODEL_SHA
    config=json.loads((a.out/'pairs.json').read_text()) if (a.out/'pairs.json').exists() else select(a.source,a.out,a.pairs)
    assert config['paired_boards']==a.pairs
    engine=OpeningEngine();engine.model.requires_grad_(False)
    for i,start in enumerate(range(0,a.pairs,a.chunk_pairs)):
        if (a.out/f'chunk-{i:04}.json').exists():continue
        play(engine.model,config['pairs'][start:start+a.chunk_pairs],a.out,i)
    summarize(a.out,config)
