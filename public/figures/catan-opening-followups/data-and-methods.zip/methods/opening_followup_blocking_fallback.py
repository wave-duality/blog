#!/usr/bin/env python3
"""Frozen Generation37 opening followups 12/14. No policy training or search.

All 100k original boards: exact distance-rule fallback enumeration for each A1;
B2 denial proxies; existing 80k/20k split and within-decision centered regressions.
A bounded legal-opponent-relocation/embedding-patching experiment uses fresh
network forwards. Run with .venv/bin/python opening_followup_blocking_fallback.py.
"""
from __future__ import annotations
import argparse, ctypes, hashlib, json, subprocess, time
from pathlib import Path
import numpy as np
from opening_study_scale_analysis import (ALPHA, Z95, atomic_json, stage_data, model_specs,
    fit_moments, score_covariance, choose_from_scores, interval_mean, r2_stats, paired_r2_difference)
from feature_dictionary import geometry_data

ROOT = Path(__file__).resolve().parent
DEFAULT_SOURCE = ROOT/'run/analysis/opening-study-100k-20261029'
DEFAULT_OUT = ROOT/'run/analysis/opening-followups-20261102/blocking_fallback'
FALLBACK_NAMES = ['best_complement_pips', 'worst_complement_pips', 'best_combined_coverage',
                  'worst_combined_coverage', 'all_five_complement_count', 'worst_coverage_tiebreak_pips']
DENIAL_NAMES = ['other_sites_denied', 'other_denied_total_pips', 'best_reply_pips_loss',
                'best_reply_coverage_loss', 'top_quartile_sites_denied']
CPP = r'''
#include <cstdint>
#include <algorithm>
#include <vector>
#include <numeric>
static const uint64_t ALL = (uint64_t(1)<<54)-1;
struct Answer {int q,b1,b2,a2;};
Answer worst(const int* q, uint64_t legal, const uint64_t* closed) {
    std::vector<int> order;
    for(int v=0;v<54;v++) if(legal>>v&1) order.push_back(v);
    std::sort(order.begin(),order.end(),[&](int a,int b){return q[a]!=q[b]?q[a]>q[b]:a<b;});
    Answer ans{q[order[0]],-1,-1,order[0]};
    // An optimal pair that lowers the best score must cover the first site.
    // Its first blocker is in that site's closed neighborhood. Its second
    // blocker must cover the best site surviving that first blocker. Thus
    // at most 4 x 4 blocker pairs suffice, without discarding any optimum.
    uint64_t first = closed[order[0]] & legal;
    while(first){int b1=__builtin_ctzll(first);first&=first-1;
        int d2=-1;for(int d:order)if(!(closed[b1]>>d&1)){d2=d;break;}
        uint64_t second = closed[d2] & legal & ~closed[b1];
        while(second){int b2=__builtin_ctzll(second);second&=second-1;
            uint64_t blocked=closed[b1]|closed[b2];
            int d=-1;for(int v:order)if(!(blocked>>v&1)){d=v;break;}
            if(ans.b1<0 || q[d]<ans.q || (q[d]==ans.q && (b1<ans.b1 || (b1==ans.b1&&b2<ans.b2))))
                ans={q[d],b1,b2,d};
        }
    }
    return ans;
}
extern "C" void fallback(int n, const float* rp, const uint64_t* closed, float* out) {
    for(int b=0;b<n;b++) {
        int pips[54],bits[54];
        for(int v=0;v<54;v++){pips[v]=bits[v]=0;for(int r=0;r<5;r++){
            int p=int(rp[(b*54+v)*5+r]);pips[v]+=p;if(p>0)bits[v]|=1<<r;}}
        for(int a=0;a<54;a++) {
            uint64_t legal=ALL & ~closed[a];
            int q[54],bestp=0,bestcov=0,count5=0;
            for(int d=0;d<54;d++){
                int cov=__builtin_popcount(unsigned(bits[a]|bits[d]));
                q[d]=64*cov+pips[d];
                if(legal>>d&1){bestp=std::max(bestp,pips[d]);bestcov=std::max(bestcov,cov);count5+=cov==5;}}
            Answer wp=worst(pips,legal,closed),wc=worst(q,legal,closed);
            float *o=out+(b*54+a)*12;
            o[0]=bestp;o[1]=wp.q;o[2]=bestcov;o[3]=wc.q/64;o[4]=count5;o[5]=wc.q%64;
            o[6]=wp.b1;o[7]=wp.b2;o[8]=wp.a2;o[9]=wc.b1;o[10]=wc.b2;o[11]=wc.a2;
        }
    }
}
'''

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):
    with np.load(path,allow_pickle=False) as a: return {k:a[k] for k in a.files}
def mean_ci(x):
    x=np.asarray(x,dtype=float); m,ci=interval_mean(x)
    return dict(n=len(x),mean=m,ci95=ci)
def center(x, starts, counts, group):
    return x-np.add.reduceat(x,starts,axis=0)[group]/counts[group,None]

def library(out):
    src=out/'fallback_exact.cpp';src.write_text(CPP)
    binary=out/'fallback_exact.dylib'
    subprocess.run(['c++','-O3','-std=c++17','-shared','-fPIC',str(src),'-o',str(binary)],check=True)
    lib=ctypes.CDLL(str(binary)); fn=lib.fallback
    fn.argtypes=[ctypes.c_int,np.ctypeslib.ndpointer(np.float32,flags='C_CONTIGUOUS'),
                 np.ctypeslib.ndpointer(np.uint64,flags='C_CONTIGUOUS'),np.ctypeslib.ndpointer(np.float32,flags='C_CONTIGUOUS')]
    fn.restype=None
    return fn

def all_rp(shard):
    ptr=shard['position_ptr']; rows=np.concatenate([np.arange(ptr[4*i],ptr[4*i+1]) for i in range(len(shard['board_seed']))])
    vs=shard['candidate_vertex'][rows].reshape(-1,54)
    assert np.array_equal(vs,np.broadcast_to(np.arange(54),vs.shape))
    return np.ascontiguousarray(shard['candidate_features'][rows,1:6].reshape(-1,54,5),dtype=np.float32)

def fallback_validation(rp, f, closed, distance, boards):
    import catan_rl
    rng=np.random.default_rng(121437); n=min(200,len(rp)*54); cases=[]
    native=0
    for flat in rng.choice(len(rp)*54,size=n,replace=False):
        bi,a=divmod(int(flat),54); pips=rp[bi].sum(1); masks=rp[bi]>0
        legal=np.flatnonzero(distance[a]>1); b1,b2=np.triu_indices(len(legal),1)
        pairs=np.stack([legal[b1],legal[b2]],axis=1)
        pairs=pairs[distance[pairs[:,0],pairs[:,1]]>1]
        remaining=(distance[a][None,:]>1)&(distance[pairs[:,0]]>1)&(distance[pairs[:,1]]>1)
        assert remaining.any(1).all()
        wp=np.where(remaining,pips,-1).max(1).min()
        coverage=(masks[a]|masks).sum(1);q=64*coverage+pips
        wc=np.where(remaining,q,-1).max(1).min()
        assert f[bi,a,1]==wp and 64*f[bi,a,3]+f[bi,a,5]==wc
        cases.append(dict(board=bi,a1=a,reply_pairs=len(pairs)))
        if native<20:
            board=[array[bi].tolist() for array in boards]
            for ix in [6,9]:
                b,c,d=f[bi,a,ix:ix+3].astype(int)
                game=catan_rl.Game.from_opening(*board,[])
                for v in [a,b,c]:
                    assert 72+v in game.legal();game.apply(72+int(v));game.apply(min(game.legal()))
                expected=np.flatnonzero((distance[a]>1)&(distance[b]>1)&(distance[c]>1))+72
                np.testing.assert_array_equal(game.legal(),expected)
                assert 72+d in game.legal();native+=1
    return dict(exhaustive_cases=len(cases),minimum_pairs=min(c['reply_pairs'] for c in cases),
                maximum_pairs=max(c['reply_pairs'] for c in cases),native_engine_legal_reply_checks=native,
                exact_enumeration_agrees=True,setup_roads_do_not_change_settlement_legality=True)

def denial(shard, d, distance, rp):
    n=len(shard['board_seed']); denselegal=np.zeros((n,54),bool);denselegal[d['group'],d['vertex']]=True
    pips=rp.sum(2); a1=shard['chosen_vertices'][:,0]
    coverage=((rp>0)|(rp[np.arange(n),a1]>0)[:,None,:]).sum(2)
    legalclosed=denselegal[:,None,:] & (distance<=1)[None,:,:]
    legalother=legalclosed & (~np.eye(54,dtype=bool))[None,:,:]
    surviving=denselegal[:,None,:] & (distance>1)[None,:,:]
    best=np.where(denselegal,pips,-1).max(1)
    bestcov=np.where(denselegal,coverage,-1).max(1)
    quart=np.array([np.quantile(pips[i,denselegal[i]],.75) for i in range(n)])
    extra=np.stack([legalother.sum(2),(legalother*pips[:,None,:]).sum(2),
        best[:,None]-np.where(surviving,pips[:,None,:],-1).max(2),
        bestcov[:,None]-np.where(surviving,coverage[:,None,:],-1).max(2),
        (legalclosed & (pips>=quart[:,None])[:,None,:]).sum(2)],axis=2).astype(float)
    return extra[d['group'],d['vertex']],extra,denselegal

def regression_specs():
    base=model_specs()['board_scarcity']
    return {
      'A1': {'context':base,'optimistic':base+[FALLBACK_NAMES[i] for i in [0,2,4]],
             'robust':base+[FALLBACK_NAMES[i] for i in [0,2,4,1,3]]},
      'B2': {'context':base,'denial':base+DENIAL_NAMES}}

def descriptive_a1(shard,rp,f):
    chosen=shard['chosen_vertices'][:,0];idx=np.arange(len(chosen));pips=rp.sum(2)
    matched=(pips==pips[idx,chosen,None]) & ((rp>0).sum(2)==(rp[idx,chosen]>0).sum(1)[:,None])
    adj=shard['candidate_features'][np.concatenate([np.arange(shard['position_ptr'][4*i],shard['position_ptr'][4*i+1]) for i in idx]),6].reshape(-1,54)
    matched &= adj==adj[idx,chosen,None]
    count=matched.sum(1);mean=(f[:,:,:6]*matched[:,:,None]).sum(1)/count[:,None]
    pbest=f[:,:,0];pworst=f[:,:,1];cbest=f[:,:,2];cworst=f[:,:,3]
    return dict(seed=shard['board_seed'],train=shard['train'],chosen=chosen,chosen_features=f[idx,chosen,:6],
      matched_count=count,matched_features=mean,chosen_pips=pips[idx,chosen],
      chosen_combined_worst_pips=pips[idx,chosen]+pworst[idx,chosen],
      maximal_robust_combined_pips=(pips+pworst).max(1),
      chosen_pip_loss=pbest[idx,chosen]-pworst[idx,chosen],chosen_coverage_loss=cbest[idx,chosen]-cworst[idx,chosen],
      any_all_five_complement=cbest[idx,chosen]==5,guaranteed_all_five=cworst[idx,chosen]==5)

def descriptive_b2(shard,d,rp,den,denselegal):
    n=len(shard['board_seed']);chosen=shard['chosen_vertices'][:,2];idx=np.arange(n);pips=rp.sum(2)
    # Exact immediate resource-vector matching, not merely total pips.
    match=denselegal & np.all(rp==rp[idx,chosen,None,:],axis=2)
    count=match.sum(1);base=(den*match[:,:,None]).sum(1)/count[:,None]
    maximum=np.where(denselegal,pips,-1).max(1)
    return dict(seed=shard['board_seed'],train=shard['train'],chosen=chosen,chosen_features=den[idx,chosen],
        matched_count=count,matched_features=base,production_sacrifice=maximum-pips[idx,chosen],
        reply_pips_loss=den[idx,chosen,2],reply_coverage_loss=den[idx,chosen,3])

def analysis(source,out,max_shards=None):
    t0=time.monotonic();out.mkdir(parents=True,exist_ok=True); cache=out/'cache';cache.mkdir(exist_ok=True)
    manifest=json.loads((source/'manifest.json').read_text());assert manifest['status']=='complete'
    geometry,distance=geometry_data();closed=np.array([sum(1<<j for j in np.flatnonzero(row<=1)) for row in distance],np.uint64)
    fn=library(out);specs=regression_specs();unions={s:list(dict.fromkeys(k for c in specs[s].values() for k in c)) for s in specs}
    base=model_specs()['board_scarcity'];aggregates={s:dict(cov=np.zeros((len(unions[s]),)*2),rhs=np.zeros(len(unions[s])),n=0) for s in specs}
    paths=[source/s['path'] for s in manifest['shards']];paths=paths[:max_shards] if max_shards else paths
    descriptives={s:[] for s in specs};validation=None;examples=[]
    for si,path in enumerate(paths):
        shard=load(path);rp=all_rp(shard);f=np.empty((len(rp),54,12),np.float32);fn(len(rp),rp,closed,f)
        if validation is None:validation=fallback_validation(rp,f,closed,distance,[shard['board_resources'],shard['board_numbers'],shard['board_ports']])
        np.savez_compressed(cache/path.name,fallback=f)
        for stage,label in [(0,'A1'),(2,'B2')]:
            d=stage_data(shard,stage,manifest['feature_names'],base,geometry)
            if stage==0:
                extra=f[d['group'],d['vertex'],:6];en=FALLBACK_NAMES;desc=descriptive_a1(shard,rp,f)
            else:
                extra,den,dense=denial(shard,d,distance,rp);en=DENIAL_NAMES;desc=descriptive_b2(shard,d,rp,den,dense)
            descriptives[label].append(desc)
            xx=center(extra,d['starts'],d['count'],d['group']);cols={k:xx[:,i] for i,k in enumerate(en)}
            cols.update({k:d['x'][:,i] for i,k in enumerate(base)})
            x=np.column_stack([cols[k] for k in unions[label]]);w=d['train'][d['group']]/d['count'][d['group']]
            agg=aggregates[label];agg['cov']+=x.T@(x*w[:,None]);agg['rhs']+=x.T@(d['y']*w);agg['n']+=int(d['train'].sum())
        if si%10==0 or si+1==len(paths):print(f'Features/moments {si+1}/{len(paths)}, {time.monotonic()-t0:.1f}s',flush=True)
    fits={}
    for label,agg in aggregates.items():
        fits[label]={}
        for name,cols in specs[label].items():
            ix=np.array([unions[label].index(k) for k in cols]);cov=agg['cov'][np.ix_(ix,ix)]/agg['n'];rhs=agg['rhs'][ix]/agg['n']
            fit=fit_moments(cov,rhs,cols);a=np.array(fit['active_indices']);scale=fit['scale'][a]
            fit.update(ix=ix,active=a,inverse=np.linalg.inv(cov[np.ix_(a,a)]/scale[:,None]/scale[None,:]+ALPHA*np.eye(len(a))),
                score_sum=np.zeros(len(a)),score_outer=np.zeros((len(a),len(a))),errors=[],hits=[],gaps=[])
            fits[label][name]=fit
    targets={s:[] for s in specs}
    for si,path in enumerate(paths):
        shard=load(path);rp=all_rp(shard);f=load(cache/path.name)['fallback']
        for stage,label in [(0,'A1'),(2,'B2')]:
            d=stage_data(shard,stage,manifest['feature_names'],base,geometry)
            if stage==0:extra=f[d['group'],d['vertex'],:6];en=FALLBACK_NAMES
            else:extra,_,_=denial(shard,d,distance,rp);en=DENIAL_NAMES
            xx=center(extra,d['starts'],d['count'],d['group']);cols={k:xx[:,i] for i,k in enumerate(en)};cols.update({k:d['x'][:,i] for i,k in enumerate(base)})
            x=np.column_stack([cols[k] for k in unions[label]]);te=~d['train'];targets[label].append(d['target'][te])
            for name,fit in fits[label].items():
                xx=x[:,fit['ix']];pred=xx@fit['raw'];res=d['y']-pred
                error=np.add.reduceat(res**2,d['starts'])/d['count'];choice=choose_from_scores(pred,d['vertex'],d['starts'],d['group'])
                fit['errors'].append(error[te]);fit['hits'].append((choice==d['chosen'])[te])
                a=fit['active'];z=xx[:,a]/fit['scale'][a]
                score=np.add.reduceat(z*res[:,None],d['starts'],axis=0)/d['count'][:,None]
                score-=ALPHA*np.add.reduceat(z*z,d['starts'],axis=0)/d['count'][:,None]*fit['standardized'][a]
                score=score[d['train']];fit['score_sum']+=score.sum(0);fit['score_outer']+=score.T@score
        if si%10==0 or si+1==len(paths):print(f'Evaluation {si+1}/{len(paths)}, {time.monotonic()-t0:.1f}s',flush=True)
    result=dict(schema='opening-blocking-fallback-v1',boards=sum(len(a['seed']) for a in descriptives['A1']),model=manifest['model'],
        source_manifest_sha256=sha(source/'manifest.json'),analysis_sha256=sha(__file__),validation=validation,stages={})
    for label in specs:
        target=np.concatenate(targets[label]);ntrain=aggregates[label]['n'];entry=dict(train_boards=ntrain,test_boards=len(target),models={},comparisons=[])
        for name,fit in fits[label].items():
            errors=np.concatenate(fit['errors']);fit['errors']=errors;hits=np.concatenate(fit['hits']);r2,ci=r2_stats(errors,target)
            a=fit['active'];cov=score_covariance(fit['score_sum'],fit['score_outer'],fit['inverse'],fit['scale'][a],ntrain)
            coeff=[]
            for j,k in enumerate(specs[label][name]):
                if j in a:
                    se=float(np.sqrt(max(0,cov[np.flatnonzero(a==j)[0],np.flatnonzero(a==j)[0]])));v=float(fit['raw'][j])
                    coeff.append(dict(feature=k,coefficient=v,ci95=[v-Z95*se,v+Z95*se]))
                else:coeff.append(dict(feature=k,coefficient=None,ci95=None,status='omitted_constant_or_exact_dependency'))
            entry['models'][name]=dict(r2=r2,r2_ci95=ci,top_choice_agreement=mean_ci(hits),coefficients=coeff)
        comparisons=[('context','optimistic'),('optimistic','robust'),('context','robust')] if label=='A1' else [('context','denial')]
        for a,b in comparisons:entry['comparisons'].append(dict(reduced=a,full=b,**paired_r2_difference(fits[label][a]['errors'],fits[label][b]['errors'],target)))
        raw={k:np.concatenate([v[k] for v in descriptives[label]]) for k in descriptives[label][0]};np.savez_compressed(out/f'descriptive-{label}.npz',**raw)
        eligible=raw['matched_count']>=2;effect=raw['chosen_features']-raw['matched_features'];names=FALLBACK_NAMES if label=='A1' else DENIAL_NAMES
        entry['matched']=dict(eligible_boards=int(eligible.sum()),condition='Same total pips, number of producing resources, and adjacent hex count' if label=='A1' else 'Exact five-resource production vector',
            includes_chosen=True,minimum_pool_size=2,features={k:mean_ci(effect[eligible,i]) for i,k in enumerate(names)})
        if label=='A1':
            entry['descriptive']={k:mean_ci(raw[k]) for k in ['chosen_pip_loss','chosen_coverage_loss','any_all_five_complement','guaranteed_all_five','chosen_combined_worst_pips','maximal_robust_combined_pips']}
            entry['descriptive']['matches_maximum_robust_combined_pips']=mean_ci(raw['chosen_combined_worst_pips']==raw['maximal_robust_combined_pips'])
        else:
            entry['descriptive']={k:mean_ci(raw[k]) for k in ['production_sacrifice','reply_pips_loss','reply_coverage_loss']}
            entry['descriptive']['sacrifices_any_pips']=mean_ci(raw['production_sacrifice']>0)
            entry['descriptive']['reduces_opponents_best_pips']=mean_ci(raw['reply_pips_loss']>0)
            entry['descriptive']['sacrifices_pips_and_reduces_best_reply']=mean_ci((raw['production_sacrifice']>0)&(raw['reply_pips_loss']>0))
        result['stages'][label]=entry
    result['methods']=dict(policy='Frozen Generation37, no search, one original greedy trajectory per board.',
       fitting='Original whole-board 80k/20k split, within-decision-centered legal logits; equal board weight; train-RMS standardized ridge alpha .001. Baseline is previous board-scarcity/context specification. Exact dependencies removed using train data.',
       uncertainty='Whole-board normal/delta-method95% intervals. Coefficient sandwich includes uncertainty in RMS scaling, conditional on retained feature set. Held-out R² uncertainty conditions on fitted coefficients. Descriptive comparisons use paired board means.',
       fallback='For each A1, exactly minimize the best remaining legal A2 over all legal B1/B2 settlement pairs. Two objectives: total pips; lexicographic combined resource coverage then total pips. Closed neighborhoods encode the actual setup settlement rule. Roads do not change setup settlement availability; every valid settlement configuration admits incident starting roads.',
       fast_exact='A pair that removes the best complement must contain a blocker in its closed neighborhood. Its second blocker must remove the best site surviving the first blocker. Checking these <=4x4 pairs attains the same optimum as full enumeration. Independently validated against every legal pair for200 cases.',
       denial='At B2, compute damage to A2 availability after the candidate: count/sum of other removed corners, loss of the best remaining pip total and best resource coverage paired with A1, count of removed upper-quartile production sites. These are availability proxies, not estimates of opponent win probability.',
       limitation='Correlations and proxy robustness do not establish strategic intent, optimal play, or advantage in actual continuation games. Tight intervals do not include uncertainty over trained policies.')
    result['elapsed_seconds']=time.monotonic()-t0;atomic_json(out/'results.json',result)
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,default=DEFAULT_SOURCE);p.add_argument('--out',type=Path,default=DEFAULT_OUT);p.add_argument('--max-shards',type=int)
    args=p.parse_args();analysis(args.source,args.out,args.max_shards)
