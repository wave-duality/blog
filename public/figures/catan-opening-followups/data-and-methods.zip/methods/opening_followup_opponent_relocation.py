#!/usr/bin/env python3
"""Fresh legal opponent-relocation and embedding patch for opening experiment12.

The current player is B choosing B2. Its B1 settlement/road and the board are
fixed. A1 (the opponent settlement and its road) moves to a valid alternative
with the same total pips and coastal/interior class. Prefer an exact resource
production-vector match if one exists. Compare only legal corners common to
both histories. Patch the embedded rows at the old/new opponent pieces.
"""
import argparse, hashlib, json, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
import catan_rl
from opening_engine import OpeningEngine, MODEL_SHA, MODEL_PATH
from opening_study_scale_analysis import atomic_json, interval_mean
from opening_followup_blocking_fallback import DEFAULT_SOURCE, DEFAULT_OUT, load, all_rp, mean_ci, sha
from feature_dictionary import geometry_data
from train import split_obs

@torch.inference_mode()
def embeddings(model, obs):
    h,v,p,g=split_obs(torch.from_numpy(obs))
    return (F.relu(model.hex_embed(h)),F.relu(model.vertex_embed(v)),F.relu(model.path_embed(p)),F.relu(model.global_embed(g)))

@torch.inference_mode()
def complete(model,state):
    for layer in model.layers:state=layer(*state)
    return model.settle_head(state[1]).squeeze(-1).numpy().copy()

@torch.inference_mode()
def run(source,out,boards=2000,batch=32):
    started=time.monotonic();out.mkdir(parents=True,exist_ok=True);torch.set_num_threads(1)
    model=OpeningEngine().model;model.eval();model.requires_grad_(False)
    assert sha(MODEL_PATH)==MODEL_SHA
    manifest=json.loads((source/'manifest.json').read_text());geometry,distance=geometry_data()
    adjacent=np.array([sum(h is not None and h>=0 for h in hs) for hs in geometry['vertex_hexes']])
    edges=[np.array([e for e,pair in enumerate(geometry['path_vertices']) if v in pair],int) for v in range(54)]
    selected=[];scanned=0
    for rec in manifest['shards']:
        shard=load(source/rec['path']);rp=all_rp(shard);pips=rp.sum(2)
        for bi in np.flatnonzero(~shard['train']):
            scanned+=1;a,b=map(int,shard['chosen_vertices'][bi,:2]);source_hist=shard['history'][bi,:4].astype(int).tolist()
            possible=np.flatnonzero((distance[b]>1)&(np.arange(54)!=a)&(pips[bi]==pips[bi,a])&(adjacent==adjacent[a]))
            if not len(possible):continue
            exact=possible[np.all(rp[bi,possible]==rp[bi,a],axis=1)]
            candidate=exact if len(exact) else possible
            alternative=int(candidate[np.lexsort((candidate,-distance[a,candidate]))[0]])
            road=int(edges[alternative].min());new_hist=[72+alternative,road,source_hist[2],source_hist[3]]
            board=[shard[k][bi].astype(int).tolist() for k in ['board_resources','board_numbers','board_ports']]
            sourcegame=catan_rl.Game.from_opening(*board,source_hist);donorgame=catan_rl.Game.from_opening(*board,new_hist)
            assert sourcegame.to_act()==1 and donorgame.to_act()==1
            common=np.intersect1d(sourcegame.legal(),donorgame.legal())-72
            assert len(common)>0
            selected.append(dict(seed=int(shard['board_seed'][bi]),board=board,source_history=source_hist,donor_history=new_hist,
              same_resource_vector=bool(np.array_equal(rp[bi,a],rp[bi,alternative])),source_observation=sourcegame.opening_observation(),
              donor_observation=donorgame.opening_observation(),common=common,a=a,alternative=alternative,old_road=source_hist[1],new_road=road))
            if len(selected)>=boards:break
        if len(selected)>=boards:break
    assert len(selected)==boards
    arrays={k:[] for k in ['source_scores','donor_scores','patched_scores','common_legal','seed','same_resource_vector','source_history','donor_history']}
    validation=dict(native_legal_histories=boards*2,common_legal_only=True,identity_max_absolute_error=0.,all_embeddings_positive_control_max_absolute_error=0.,manual_forward_max_absolute_error=0.)
    for start in range(0,boards,batch):
        rows=selected[start:start+batch];sourceobs=np.concatenate([r['source_observation'] for r in rows]);donorobs=np.concatenate([r['donor_observation'] for r in rows])
        ss=embeddings(model,sourceobs);ds=embeddings(model,donorobs);scores=complete(model,ss);donor=complete(model,ds)
        patched=[s.clone() for s in ss]
        for i,row in enumerate(rows):
            for v in [row['a'],row['alternative']]:patched[1][i,v]=ds[1][i,v]
            for edge in [row['old_road'],row['new_road']]:patched[2][i,edge]=ds[2][i,edge]
        patch=complete(model,tuple(patched))
        if start==0:
            direct=model(*split_obs(torch.from_numpy(sourceobs)))[0][:,72:126].numpy()
            identity=complete(model,tuple(s.clone() for s in ss));positive=complete(model,tuple(s.clone() for s in ds))
            for key,value in [('manual_forward_max_absolute_error',np.max(np.abs(direct-scores))),('identity_max_absolute_error',np.max(np.abs(identity-scores))),('all_embeddings_positive_control_max_absolute_error',np.max(np.abs(positive-donor)))]:
                validation[key]=float(value);assert value<5e-5
        common=np.zeros((len(rows),54),bool)
        for i,row in enumerate(rows):common[i,row['common']]=True
        for key,value in [('source_scores',scores),('donor_scores',donor),('patched_scores',patch),('common_legal',common),('seed',np.array([r['seed'] for r in rows])),('same_resource_vector',np.array([r['same_resource_vector'] for r in rows])),('source_history',np.array([r['source_history'] for r in rows])),('donor_history',np.array([r['donor_history'] for r in rows]))]:arrays[key].append(value)
        if start%320==0 or start+batch>=boards:print(f'Legal relocation/patch {min(start+batch,boards)}/{boards}, {time.monotonic()-started:.1f}s',flush=True)
    arrays={k:np.concatenate(v) for k,v in arrays.items()};np.savez_compressed(out/'opponent-relocation-arrays.npz',**arrays)
    s=arrays['source_scores'].astype(float);d=arrays['donor_scores'].astype(float);p=arrays['patched_scores'].astype(float);legal=arrays['common_legal'];count=legal.sum(1)
    center=lambda x:np.where(legal,x-(x*legal).sum(1)[:,None]/count[:,None],0.)
    delta=center(d-s);patchdelta=center(p-s);energy=(delta*delta).sum(1)/count;error=((delta-patchdelta)**2).sum(1)/count
    def softmax(x):
        e=np.where(legal,np.exp(x-np.where(legal,x,-np.inf).max(1)[:,None]),0.);return e/e.sum(1)[:,None]
    ssprob,ddprob,ppprob=softmax(s),softmax(d),softmax(p)
    sch=np.where(legal,s,-np.inf).argmax(1);dch=np.where(legal,d,-np.inf).argmax(1);pch=np.where(legal,p,-np.inf).argmax(1)
    measures={}
    for name,mask in [('all',np.ones(boards,bool)),('exact_resource_vector',arrays['same_resource_vector'])]:
        e=energy[mask];err=error[mask];ratio=1-err.mean()/e.mean();influence=-(err-(err.mean()/e.mean())*e)/e.mean();se=influence.std(ddof=1)/np.sqrt(len(e))
        numerator=(patchdelta*delta).sum(1)[mask]/count[mask];transfer=float(numerator.mean()/e.mean());transfer_influence=(numerator-transfer*e)/e.mean();transfer_se=transfer_influence.std(ddof=1)/np.sqrt(len(e))
        measures[name]=dict(directional_transfer=dict(value=transfer,ci95=[float(transfer-1.96*transfer_se),float(transfer+1.96*transfer_se)]),boards=int(mask.sum()),choice_changed=mean_ci((sch!=dch)[mask]),patch_changes_source_choice=mean_ci((sch!=pch)[mask]),
            patch_matches_donor_choice=mean_ci((dch==pch)[mask]),
            mean_centered_logit_rms_change=mean_ci(np.sqrt(energy[mask])),
            policy_total_variation=mean_ci((np.abs(ssprob-ddprob).sum(1)/2)[mask]),
            patch_policy_total_variation=mean_ci((np.abs(ssprob-ppprob).sum(1)/2)[mask]),
            fraction_of_squared_change_explained=dict(value=float(ratio),ci95=[float(ratio-1.96*se),float(ratio+1.96*se)]))
    result=dict(schema='opening-opponent-relocation-v1',boards=boards,heldout_boards_scanned=scanned,model_sha256=MODEL_SHA,
        source_manifest_sha256=sha(source/'manifest.json'),source_script_sha256=sha(__file__),validation=validation,results=measures,
        methods=dict(selection='First2000 eligible held-out boards in original corpus order. Alternative opponent A1 matches total production and adjacent hex count, preferring exact five-resource vector matches; farthest geometric alternative then lowest vertex ID breaks ties. Neither alternative selection nor eligibility uses network responses.',
          setting='B choosing B2. Same board and own B1 settlement/road. Move opponent A1 and its road; use smallest incident road at the new site. Both complete histories replayed by native engine. Scores/choices compared only over common legal settlements.',
          intervention='Patch post-ReLU input vertex embeddings at both old/new A1 vertices and path embeddings at both old/new road locations from the relocated history into the original history. Retain all other embeddings from original, then rerun every message-passing block and settlement head.',
          interpretation='A controlled sensitivity/activation-intervention test for location-specific opponent information. Moved piece rows contain all their encoded local features, not exclusively ownership. Hybrid activations need not correspond to a legal encoded state. This establishes computational sensitivity, not an identified denial neuron or strategic intent.',
          directional_transfer='mean_board(dot(patched centered score change, full centered score change)/legal_count) / mean_board(full centered score change squared/legal_count). Signed directional projection, not a percentage of a uniquely identified concept.',
          explanation_metric='1 - mean_board_MSE(full centered score change - patched centered score change)/mean_board_MSE(full centered score change). Can be negative; not a percentage of a uniquely identified causal pathway.',
          controls='Identity patch source into itself and full donor-embedding positive control; separate manual-forward agreement test. Whole-board95% normal or delta-method intervals; one paired intervention per board.'),elapsed_seconds=time.monotonic()-started)
    atomic_json(out/'opponent-relocation.json',result);return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,default=DEFAULT_SOURCE);p.add_argument('--out',type=Path,default=DEFAULT_OUT);p.add_argument('--boards',type=int,default=2000)
    a=p.parse_args();run(a.source,a.out,a.boards)
