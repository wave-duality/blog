"""Independent invariants and native checks for Experiment 8's saved pairs."""
import hashlib
import json
from pathlib import Path
import numpy as np
import catan_rl
from opening_engine import OpeningEngine, MODEL_SHA
from opening_followup_plans import evaluate, observation

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'run/analysis/opening-followups-20261102/plans-controlled'
data=json.loads((OUT/'pairs.json').read_text())
geometry=json.loads((ROOT/'viz/geometry.json').read_text())
ports=set(v for pair in geometry['port_vertices'] for v in pair)

def production(board,vertex):
    out=np.zeros(5,dtype=int)
    for h in geometry['vertex_hexes'][vertex]:
        if h is not None and h>=0:
            r,n=board[0][h],board[1][h]
            if r<5:out[r]+=6-abs(7-n)
    return out

for p in data['pairs']:
    board=p['board'];a,b=p['ore_wheat_vertex'],p['wood_brick_vertex']
    x,y=production(board,a),production(board,b)
    np.testing.assert_array_equal(x,p['ore_wheat_pips']);np.testing.assert_array_equal(y,p['wood_brick_pips'])
    assert x.sum()==y.sum() and x.sum()>=8 and x[2]==y[2]
    assert x[3:].sum()-y[3:].sum()>=3 and y[:2].sum()-x[:2].sum()>=3
    assert (x>0).sum()==(y>0).sum()
    first=production(board,p['prefix'][0]-72)
    assert ((x+first)>0).sum()==((y+first)>0).sum()
    assert a not in ports and b not in ports
    g=catan_rl.Game.from_opening(*board,p['prefix'])
    assert 72+a in g.legal() and 72+b in g.legal()

chunks=[json.loads(p.read_text()) for p in sorted(OUT.glob('chunk-*.json'))]
rows=[r for c in chunks for r in c['rows']]
assert len(rows)==2*len(data['pairs'])==4096
assert len(set((r['seed'],r['condition']) for r in rows))==len(rows)
assert all(r['terminal'] and r['outcome'] in (-1,1) and r['turn']<500 for r in rows)
engine=OpeningEngine();bot=catan_rl.Bot(sims=0);checks=0
for row in rows[::64]:
    p=next(p for p in data['pairs'] if p['seed']==row['seed'])
    game=catan_rl.Game(seed=row['seed'])
    assert [list(a) for a in game.board_arrays()]==p['board']
    for action in row['opening'][:7]:game.apply(action)
    action,_,_=evaluate(engine.model,[game.opening_observation()],[np.array(game.legal())])
    assert action[0]==row['opening'][7]
    game.apply(action[0])
    game.apply(240);game.resolve_chance()
    if len(game.legal())>1:
        obs=observation(bot,game)
        action,_,_=evaluate(engine.model,[obs],[np.array(game.legal())])
        actual=row['history'][len(game.history())]
        assert actual==[1,action[0]]
        checks+=1

summary=json.loads((OUT/'results.json').read_text())
assert summary['script_sha256']==hashlib.sha256((ROOT/'opening_followup_plans.py').read_bytes()).hexdigest()
result=dict(status='passed',matched_pairs=len(data['pairs']),native_opening_checks=len(data['pairs']),
    independent_first_decision_checks=checks,all_games_terminal=True,max_terminal_turn=max(r['turn'] for r in rows),
    minimum_terminal_turn=min(r['turn'] for r in rows),model_sha256=MODEL_SHA,
    script_sha256=summary['script_sha256'],validation_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(OUT/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
