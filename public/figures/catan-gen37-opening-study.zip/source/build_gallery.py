"""Build an embeddable gallery using the production game's SVG renderer."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from build_opening_theory_reader import live_renderer

def profile(board,vertex,geo):
    out=[0]*5
    for h in geo['vertex_hexes'][vertex]:
        if h is not None and board[0][h]<5:
            out[board[0][h]]+=6-abs(7-board[1][h])
    return out

def distances(geo):
    neighbors=[[] for _ in range(54)]
    for a,b in geo['path_vertices']:
        neighbors[a].append(b);neighbors[b].append(a)
    rows=[]
    for start in range(54):
        d=[99]*54;d[start]=0;queue=[start]
        for u in queue:
            for v in neighbors[u]:
                if d[v]==99:d[v]=d[u]+1;queue.append(v)
        rows.append(d)
    return rows

def build(source,out):
    out.mkdir(parents=True,exist_ok=True)
    detaildir=out/'catan-gen37-openings';detaildir.mkdir(exist_ok=True)
    manifest=json.loads((source/'manifest.json').read_text())
    geo=json.loads((ROOT/'viz/geometry.json').read_text());dist=distances(geo)
    summaries=[];checks=[]
    for path in sorted((source/'boards').glob('*.json')):
        b=json.loads(path.read_text());tags=[]
        pipsums=[profile(b['board'],p['chosen'],geo) for p in b['picks']]
        pairs=[[sum(pipsums[i][r] for i in range(4) if b['picks'][i]['seat']==seat) for r in range(5)] for seat in (0,1)]
        coverage=[sum(x>0 for x in pair) for pair in pairs]
        if any(p['pip_sacrifice']>=2 for p in b['picks']):tags.append('pip-sacrifice')
        if coverage==[5,5]:tags.append('coverage')
        if min(coverage)<5:tags.append('missing')
        if any(max(pair)/sum(pair)>=.5 for pair in pairs):tags.append('concentrated')
        if any(p['margin']<.1 for p in b['picks']):tags.append('close')
        port_matches=[]
        for seat,pair in enumerate(pairs):
            r=max(range(5),key=pair.__getitem__)
            endpoints=[v for i,ends in enumerate(geo['port_vertices']) if b['board'][2][i]==r for v in ends]
            d=min(dist[p['chosen']][v] for p in b['picks'] if p['seat']==seat for v in endpoints)
            if pair[r]/sum(pair)>=.4 and d<=2:port_matches.append((seat,r,d))
        if port_matches:tags.append('port')
        if port_matches:
            seat,r,d=port_matches[0];note=f"{'AB'[seat]}: concentrated {['wood','brick','sheep','wheat','ore'][r]}, {d} {'step' if d==1 else 'steps'} from its port."
        elif 'concentrated' in tags:note='At least half of one player’s pips are in a single resource.'
        elif 'pip-sacrifice' in tags:note=f"A choice passes up {max(p['pip_sacrifice'] for p in b['picks']):.0f} available pips."
        elif 'close' in tags:note='A settlement choice is nearly tied with its runner-up.'
        elif 'coverage' in tags:note='Both players finish with all five resources.'
        else:note=f"Final resource coverage: A {coverage[0]}/5, B {coverage[1]}/5."
        summary={k:b[k] for k in ('seed','split','board')}
        summary.update(tags=tags,note=note,picks=[{k:p[k] for k in ('label','seat','chosen','road')} for p in b['picks']])
        summaries.append(summary)
        # Keep the regression's full precision data in the reproducibility
        # archive. The reader loads only the selected board's scores/traces.
        lean={k:b[k] for k in ('seed','split','board','code','history')};lean['picks']=[]
        for p in b['picks']:
            pick={k:p[k] for k in ('label','seat','code','history','chosen','road','runner_up','margin','head_contributions','head_other','head_reconstruction_error','road_candidates')}
            pick['candidates']=[{k:c[k] for k in ('vertex','logit','preference')} for c in p['candidates']]
            lean['picks'].append(pick)
            assert p['chosen']==max(p['candidates'],key=lambda c:(c['logit'],-c['vertex']))['vertex']
            assert abs(sum(c['preference'] for c in p['candidates'])-1)<1e-6
            assert abs(sum(r['contribution'] for r in p['head_contributions'])+p['head_other']-p['margin'])<2e-5
            checks.append(p['head_reconstruction_error'])
        encoded=json.dumps(lean,separators=(',',':'),allow_nan=False).replace('</','<\\/')
        (detaildir/f"{b['seed']}.js").write_text('window.receiveOpeningBoard('+encoded+');\n')
    featured=[]
    for theme in ('port','concentrated','pip-sacrifice','coverage','missing','close'):
        options=[b for b in summaries if theme in b['tags'] and b['seed'] not in featured]
        if options:featured.append(options[0]['seed'])
    ordered=sorted(summaries,key=lambda b:(0,featured.index(b['seed'])) if b['seed'] in featured else (1,b['seed']))
    data=dict(boards=ordered,featured=featured,distances=dist,counts={t:sum(t in b['tags'] for b in summaries) for t in ('port','concentrated','pip-sacrifice','coverage','missing','close')})
    html=(HERE/'gallery.html').read_text().replace('/*SUMMARY_DATA*/',json.dumps(data,separators=(',',':'))).replace('/*GEOMETRY_DATA*/',json.dumps(geo,separators=(',',':'))).replace('/*LIVE_RENDERER*/',live_renderer())
    assert '/*SUMMARY_DATA*/' not in html and len(summaries)==manifest['board_count']
    (out/'catan-gen37-opening-gallery.html').write_text(html)
    (out/'opening-gallery-counts.json').write_text(json.dumps(dict(counts=data['counts'],featured=featured,boards=len(summaries),max_reconstruction_error=max(checks)),indent=2))
    with zipfile.ZipFile(out/'catan-gen37-opening-study.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(source.glob('*.json')):z.write(p,p.name)
        for p in sorted((source/'boards').glob('*.json')):z.write(p,'boards/'+p.name)
        for p in (ROOT/'opening_network_study.py', HERE/'build_gallery.py',HERE/'gallery.html'):
            if p.exists():z.write(p,'source/'+p.name)
        z.writestr('README.txt','Generation 37 opening preference study.\nThe board JSON files contain all legal candidate features and logits; manifest.json defines the features and fixed train/test split. The generator is included under source and requires the CatanRL repository plus original checkpoint.\nNo search, continuation games, or causal interventions were performed.\n')
    print(json.dumps({'boards':len(summaries),'filter_counts':data['counts'],'html_bytes':len(html.encode()),'detail_bytes':sum(p.stat().st_size for p in detaildir.glob('*.js')),'zip_bytes':(out/'catan-gen37-opening-study.zip').stat().st_size,'max_trace_error':max(checks),'output':str(out)},indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=HERE);ap.add_argument('--out',type=Path,default=HERE/'publication');a=ap.parse_args();build(a.source,a.out)
