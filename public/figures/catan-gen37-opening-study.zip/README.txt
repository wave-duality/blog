Generation 37 opening preference study.
The board JSON files contain all legal candidate features and logits; manifest.json defines the features and fixed train/test split. The generator is included under source and requires the CatanRL repository plus original checkpoint.
No search, continuation games, or causal interventions were performed.
