#!/usr/bin/env python3
"""Paired held-out tests for the published opening-regression progression.

Uses saved coefficients and candidate logits, never refits or runs the network.
Run from CatanRL with .venv/bin/python opening_study_significance.py.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path
from statistics import NormalDist
import time

import mpmath as mp
import numpy as np

from opening_study_scale_analysis import stage_data, paired_r2_difference


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'run/analysis/opening-study-100k-20261029'
DEST = SOURCE / 'significance-20261102'
MODELS = ['total_pips', 'resource_pips', 'resource_coverage',
          'resource_coverage_ports', 'resource_coverage_ports_numbers',
          'full_context', 'resource_context']
LABELS = ['A1', 'B1', 'B2', 'A2']
STEPS = list(zip(MODELS[:-1], MODELS[1:]))
COMPARISONS = STEPS + [('resource_coverage', 'resource_context')]
NAMES = ['Separate weights for the five resources',
         'Coverage, concentration, adjacent tiles', 'Ports', 'Dice-number patterns',
         'Expansion and settlement proximity', 'Resource-specific context',
         'All remaining context (combined)']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def extract(source, destination):
    started = time.monotonic()
    manifest = json.loads((source / 'manifest.json').read_text())
    results = json.loads((source / 'analysis/results.json').read_text())
    assert manifest['status'] == 'complete'
    assert sha(source / 'manifest.json') == results['source_manifest_sha256']
    union = list(dict.fromkeys(c for key in MODELS for c in results['model_definitions'][key]))
    fits = []
    for stage in results['stages']:
        fits.append({key: (np.array([union.index(c['feature']) for c in stage['models'][key]['coefficients']]),
                            np.array([c['coefficient'] if c['status'] == 'estimated' else 0.
                                      for c in stage['models'][key]['coefficients']])) for key in MODELS})
    collected = [{key: [] for key in ['seed', 'target', *MODELS]} for _ in LABELS]
    for si, entry in enumerate(manifest['shards']):
        path = source / entry['path']
        assert sha(path) == entry['sha256'], path
        with np.load(path, allow_pickle=False) as archive:
            shard = {key: archive[key] for key in archive.files}
        for stage in range(4):
            d = stage_data(shard, stage, manifest['feature_names'], union, manifest['geometry'])
            test = ~d['train']
            collected[stage]['seed'].append(d['seed'][test])
            collected[stage]['target'].append(d['target'][test])
            # Each board contributes one mean error, regardless of legal-action count.
            for key, (ix, coefficients) in fits[stage].items():
                residual = d['y'] - d['x'][:, ix] @ coefficients
                error = np.add.reduceat(residual ** 2, d['starts']) / d['count']
                collected[stage][key].append(error[test])
        if (si + 1) % 20 == 0:
            print(f'Reconstructed {si+1}/{len(manifest["shards"])} shards ({time.monotonic()-started:.1f}s)', flush=True)
    arrays = {}
    for label, stage in zip(LABELS, collected):
        for key, chunks in stage.items():
            arrays[f'{label}__{key}'] = np.concatenate(chunks)
        seeds = arrays[f'{label}__seed']
        assert len(seeds) == 20000 and len(np.unique(seeds)) == 20000
        np.testing.assert_array_equal(seeds, arrays['A1__seed'])
    np.savez_compressed(destination / 'heldout-board-errors.npz', **arrays)
    return arrays, results


def student_p(t, df):
    """Two-sided Student reference, evaluated without floating-point underflow."""
    x = mp.mpf(df) / (df + mp.mpf(t) ** 2)
    return mp.betainc(mp.mpf(df)/2, mp.mpf('0.5'), 0, x, regularized=True)


def analyze(arrays, saved, source, destination):
    mp.mp.dps = 60
    # Independent analytic controls for the Student reference implementation.
    assert abs(student_p(0, 19999) - 1) < mp.mpf('1e-50')
    assert abs(student_p(1, 1) - mp.mpf('.5')) < mp.mpf('1e-50')
    assert abs(student_p(2.2281388519649385, 10) - mp.mpf('.05')) < mp.mpf('1e-10')
    rows = []
    max_r2_error = 0.
    max_old_ci_error = 0.
    for stage, label in zip(saved['stages'], LABELS):
        target = arrays[f'{label}__target']
        for key in MODELS:
            r2 = 1 - arrays[f'{label}__{key}'].mean() / target.mean()
            max_r2_error = max(max_r2_error, abs(r2 - stage['models'][key]['r2']))
        for step, ((reduced, full), name) in enumerate(zip(COMPARISONS, NAMES)):
            er = arrays[f'{label}__{reduced}']; ef = arrays[f'{label}__{full}']
            d = er - ef
            n = len(d)
            se = float(d.std(ddof=1) / np.sqrt(n))
            assert se > 0
            t = float(d.mean() / se)
            delta = paired_r2_difference(er, ef, target)
            influence = (d - delta['delta_r2'] * target) / target.mean()
            delta_se = float(influence.std(ddof=1) / np.sqrt(n))
            previous = next((r for r in stage['paired_model_comparisons'] if r['reduced'] == reduced and r['full'] == full), None)
            if previous:
                max_old_ci_error = max(max_old_ci_error, abs(previous['delta_r2'] - delta['delta_r2']),
                                       float(np.max(np.abs(np.array(previous['ci95']) - delta['ci95']))))
            p = student_p(t, n - 1)
            # All tiny p values are intentionally displayed as bounds.
            rows.append(dict(stage=label, comparison=name, reduced=reduced, full=full,
                             kind='sequential' if step < 6 else 'compact_table_aggregate',
                             boards=n, df=n-1, r2_reduced=stage['models'][reduced]['r2'],
                             r2_full=stage['models'][full]['r2'], **delta, delta_r2_se=delta_se,
                             mean_mse_gain=float(d.mean()), mse_gain_se=se, paired_t=t,
                             relative_mse_reduction=float(d.mean()/er.mean()),
                             board_fraction_improved=float((d > 0).mean()),
                             p_display='<0.001' if p < mp.mpf('.001') else f'{float(p):.4f}',
                             _p=p))
    previous = mp.mpf(0)
    for rank, row in enumerate(sorted(rows, key=lambda r: r['_p'])):
        previous = max(previous, min(mp.mpf(1), (len(rows)-rank) * row['_p']))
        row['holm_p_display'] = '<0.001' if previous < mp.mpf('.001') else f'{float(previous):.4f}'
        row['holm_reject_005'] = bool(previous < mp.mpf('.05'))
        row['significant_improvement'] = row['holm_reject_005'] and row['mean_mse_gain'] > 0
    for row in rows:
        row.pop('_p')
    assert max_r2_error < 1e-12
    assert max_old_ci_error < 1e-12
    result = dict(schema='opening-paired-significance-v1', contrasts=rows,
        method=dict(unit='One independent held-out board; legal-candidate squared errors averaged within board.',
                    target='Within-decision-centered network logits.',
                    null='Equal expected board MSE for the two fixed regressions; equivalent to zero population R² difference for a common positive baseline.',
                    statistic='mean(MSE_reduced - MSE_full) / (sample SD of paired board differences / sqrt(B))',
                    reference='Two-sided Student t with B-1 degrees of freedom; approximate for non-Gaussian differences.',
                    delta_r2='mean(paired MSE gain) / mean(within-board centered-target variance)',
                    delta_interval='Pointwise 95% paired ratio delta-method interval; accounts for sampled denominator.',
                    multiple_comparisons='Holm correction across 28 unique contrasts: six sequential additions plus one compact-table aggregate, at four stages.',
                    interpretation='Conditional on fixed fitted regressions, checkpoint, analysis specification and generator distribution; exploratory, not a new preregistered holdout.',
                    p_reporting='Display p<0.001 rather than extreme tail precision. Student probabilities evaluated at 60 decimal digits with the regularized incomplete beta function.',
                    limitations='Detectable score-prediction gain is not a causal feature effect, action-agreement gain, or playing-strength gain.'),
        validation=dict(max_r2_reconstruction_error=max_r2_error,max_existing_paired_ci_error=max_old_ci_error,
                        distinct_test_boards=20000,student_reference_analytic_controls=True),
        provenance=dict(source_manifest_sha256=sha(source/'manifest.json'),saved_results_sha256=sha(source/'analysis/results.json'),
                        analysis_script_sha256=sha(__file__),board_errors_sha256=sha(destination/'heldout-board-errors.npz')))
    (destination/'results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    with (destination/'comparisons.csv').open('w',newline='') as stream:
        fields=[k for k in rows[0] if k != 'ci95']+['ci95_low','ci95_high']
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for row in rows:
            writer.writerow({**{k:v for k,v in row.items() if k!='ci95'},'ci95_low':row['ci95'][0],'ci95_high':row['ci95'][1]})
    for row in rows:
        print(f'{row["stage"]} {row["comparison"]}: ΔR²={row["delta_r2"]:+.6f}, t={row["paired_t"]:+.2f}, Holm p{row["holm_p_display"]}')
    print(json.dumps(result['validation']))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=SOURCE)
    parser.add_argument('--destination',type=Path,default=DEST)
    parser.add_argument('--reuse-errors',action='store_true')
    args=parser.parse_args();args.destination.mkdir(parents=True,exist_ok=True)
    if args.reuse_errors:
        with np.load(args.destination/'heldout-board-errors.npz',allow_pickle=False) as archive:
            arrays={k:archive[k] for k in archive.files}
        saved=json.loads((args.source/'analysis/results.json').read_text())
    else:
        arrays,saved=extract(args.source,args.destination)
    analyze(arrays,saved,args.source,args.destination)


if __name__=='__main__':
    main()
