"""Publish the corrected two-edge road-gamble illustration using native graphics."""
import hashlib
import json
from pathlib import Path

from build_opening_theory_reader import live_renderer

ROOT = Path(__file__).resolve().parent
RUN = ROOT / 'run/analysis/opening-two-edge-gambling-20261102'
PUB = ROOT / 'run/analysis/two-edge-wall-gambling-20261102/publication/public/figures'


def main():
    all_cases = json.loads((RUN / 'roads-cases.json').read_text())
    by_seed = {case['seed']: case for case in all_cases}
    # Contrast two strong reversals, followed by exceptions to a simple
    # readiness rule. These are explanatory examples, not a random sample.
    cases = [by_seed[seed] for seed in (4168781, 4112616, 4112444, 4176147)]
    for case in cases:
        motif = case['motif']
        motif['exit_vertex'] = motif['destination']
        assert motif['settlement_edge_distance'] == 2
    data = dict(cases=cases, geometry=json.loads((ROOT / 'viz/geometry.json').read_text()),
                renderer_source='viz/index.html',
                renderer_sha256=hashlib.sha256(live_renderer().encode()).hexdigest(),
                results_source='opening-two-edge-gambling-20261102/results.json')
    template = (ROOT / 'two_edge_wall_gambling.html').read_text()
    html = template.replace('__DATA__', json.dumps(data, separators=(',', ':'))).replace('__RENDERER__', live_renderer())
    assert '__DATA__' not in html and '__RENDERER__' not in html
    PUB.mkdir(parents=True, exist_ok=True)
    (PUB / 'catan-two-edge-wall-gambling.html').write_text(html)
    (PUB / 'catan-two-edge-wall-gambling-examples.json').write_text(json.dumps(data, indent=2)+'\n')
    print(json.dumps(dict(cases=len(cases), html=str(PUB / 'catan-two-edge-wall-gambling.html'))))


if __name__ == '__main__':
    main()
