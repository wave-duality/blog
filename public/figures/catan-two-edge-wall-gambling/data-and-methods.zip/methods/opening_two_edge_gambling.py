#!/usr/bin/env python3
"""Generation 37: a TWO-edge opening road gamble at a shared Y junction.

Each paired position has A2--u--B2, with the two inward opening roads meeting
at unoccupied u. The remaining edge u--w is the race. We vary B's opening road
orientation before A chooses its own opening road. This replaces neither the
old three-edge study nor its files: it is a distinct, corrected experiment.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import time

import catan_rl
import numpy as np
import torch

import opening_followup_hands_roads as base

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'run/analysis/opening-two-edge-gambling-20261102'
SEED = 20261102131


def sample(rows, n, salt):
    rng = np.random.default_rng(SEED + salt)
    return [rows[i] for i in rng.permutation(len(rows))[:n]]


def motif_for(board, history):
    """Select one outcome-blind Y junction per board, before network inference.

    There are exactly two edges between A2 and B2. No original A1/B1 road
    touches the junction or its third-branch destination. That destination is
    empty. The outward B road preserves whether B2's opening road directly
    joins B1's earlier road, so orientation does not add a connection elsewhere.
    """
    a, b = history[6] - 72, history[4] - 72
    if base.DISTANCE[a, b] != 2:
        return None
    occupied = set(history[1:4:2])
    buildings = {history[i] - 72 for i in (0, 2, 4, 6)}
    options = []
    for ar in base.INCIDENT[a]:
        u = int(next(v for v in base.ENDS[ar] if v != a))
        if len(base.INCIDENT[u]) != 3 or u in buildings:
            continue
        br = base.EDGE.get(tuple(sorted((u, b))))
        if br is None:
            continue
        third = set(base.INCIDENT[u]) - {ar, br}
        assert len(third) == 1
        race = third.pop()
        w = int(next(v for v in base.ENDS[race] if v != u))
        if w in buildings:
            continue
        # No old road can occupy the motif or provide a second entry at w.
        forbidden = set(base.INCIDENT[u]) | set(base.INCIDENT[w])
        if occupied & forbidden:
            continue
        connects_b1 = bool(set(base.ENDS[br]) & set(base.ENDS[history[3]]))
        away = []
        for e in base.INCIDENT[b]:
            v = int(next(v for v in base.ENDS[e] if v != b))
            if e in occupied or e == br or v in (u, w):
                continue
            if base.DISTANCE[a, v] <= 2:
                continue
            if bool(set(base.ENDS[e]) & set(base.ENDS[history[3]])) != connects_b1:
                continue
            away.append(e)
        if not away:
            continue
        options.append((-base.pip_total(board, w), ar, br, min(away), race, u, w))
    if not options:
        return None
    _, ar, br, away, race, u, w = min(options)
    return dict(a_corner=int(a), b_corner=int(b), a_toward=int(ar),
                b_toward=int(br), b_away=int(away), contested_edge=int(race),
                junction=u, destination=w, settlement_edge_distance=2,
                central_vertices=[u], motif='A2--junction--B2; junction--destination')


def validate_opening_pair(board, history, motif):
    legals = []
    for road in (motif['b_away'], motif['b_toward']):
        prefix = history[:7].copy()
        prefix[5] = road
        game = catan_rl.Game.from_opening(*board, prefix)
        legal = game.legal()
        if motif['a_toward'] not in legal or len(legal) < 2:
            return False
        complete = prefix + [motif['a_toward']]
        assert catan_rl.Game.from_opening(*board, complete).legal() == [240]
        legals.append(legal)
    assert legals[0] == legals[1]
    return True


def screen(limit=0):
    counts = Counter()
    rows = []
    for path in sorted(base.SOURCE.glob('*.npz')):
        with np.load(path) as data:
            for i, seed in enumerate(data['board_seed']):
                if limit and counts['boards'] >= limit:
                    break
                counts['boards'] += 1
                board = [data[k][i].astype(int).tolist() for k in
                         ('board_resources', 'board_numbers', 'board_ports')]
                history = data['history'][i].astype(int).tolist()
                motif = motif_for(board, history)
                if motif is None:
                    continue
                counts['geometrically_eligible'] += 1
                try:
                    valid = validate_opening_pair(board, history, motif)
                except (ValueError, RuntimeError):
                    counts['native_replay_rejected'] += 1
                    continue
                if not valid:
                    counts['fewer_than_two_legal_A_roads'] += 1
                    continue
                hand = base.grant(board, history[6] - 72).tolist()
                rows.append(dict(seed=int(seed), board=board, history=history,
                                 motif=motif, A_starting_hand=hand,
                                 A_road_ready=bool(min(hand[:2]) >= 1)))
        if limit and counts['boards'] >= limit:
            break
    counts['eligible_native_legal_boards'] = len(rows)
    return rows, dict(counts)


def road_summary(cases):
    return {
        'n': len(cases),
        'race_preference_away': base.mean_ci([c['race_preference_away'] for c in cases]),
        'race_preference_toward': base.mean_ci([c['race_preference_toward'] for c in cases]),
        'race_preference_delta': base.mean_ci([c['race_preference_toward'] - c['race_preference_away'] for c in cases]),
        'race_logit_margin_delta': base.mean_ci([c['race_logit_margin_toward'] - c['race_logit_margin_away'] for c in cases]),
        'race_chosen_away': base.wilson([c['choice_away'] == c['motif']['a_toward'] for c in cases]),
        'race_chosen_toward': base.wilson([c['choice_toward'] == c['motif']['a_toward'] for c in cases]),
        'any_choice_changed': base.wilson([c['choice_away'] != c['choice_toward'] for c in cases]),
    }


def representative_cases(cases):
    # Chosen for illustration after analysis; not a representative random sample.
    pool = [c for c in cases if c['A_road_ready']]
    illustrations = []
    categories = [
        ('enters_despite_threat', lambda c: c['choice_toward'] == c['motif']['a_toward'],
         lambda c: c['race_preference_toward']),
        ('backs_away_under_threat', lambda c: c['choice_away'] == c['motif']['a_toward'] and c['choice_toward'] != c['motif']['a_toward'],
         lambda c: c['race_preference_away'] - c['race_preference_toward']),
        ('more_interested_when_contested', lambda c: c['choice_toward'] == c['motif']['a_toward'],
         lambda c: c['race_preference_toward'] - c['race_preference_away']),
    ]
    seen = set()
    for label, pred, key in categories:
        available = [c for c in pool if c['seed'] not in seen and pred(c)]
        if available:
            chosen = max(available, key=key)
            seen.add(chosen['seed'])
            illustrations.append(dict(illustration=label, **chosen))
    not_ready = [c for c in cases if not c['A_road_ready'] and c['choice_toward'] == c['motif']['a_toward']]
    if not_ready:
        illustrations.append(dict(illustration='enters_without_starting_wood_and_brick',
                                  **max(not_ready, key=lambda c: c['race_preference_toward'])))
    return illustrations


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--n', type=int, default=2000)
    p.add_argument('--readiness-n', type=int, default=1000)
    p.add_argument('--screen-limit', type=int, default=0)
    p.add_argument('--out', type=Path, default=OUT)
    args = p.parse_args()
    started = time.time()
    args.out.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    rows, counts = screen(args.screen_limit)
    print(json.dumps(dict(stage='screened', counts=counts, seconds=time.time()-started)), flush=True)
    if not rows:
        raise ValueError('No qualifying two-edge race motifs')
    selected = sample(rows, args.n, 1)
    base.json_write(args.out/'eligible-screen.json', dict(counts=counts, eligible_seeds=[r['seed'] for r in rows]))
    base.json_write(args.out/'selected-inputs.json', selected)
    ev = base.Evaluation()
    result = dict(
        schema='opening-two-edge-gambling-v1', checkpoint_sha256=base.MODEL_SHA,
        seed=SEED, readiness_sample_seed=base.SEED + 601, script_sha256=base.digest(__file__),
        imported_method_sha256=base.digest(base.__file__), screen=counts,
        topology='A2 and B2 are TWO edges apart. Their inward roads meet at empty degree-three junction u. The unoccupied third edge u--w is contested. w is empty and has no older road attached.',
        design='Paired legal opening histories: rotate only B2 road inward versus outward before A2 chooses its free road. Board, settlements, cards, globals and A legal action set match. One geometrically selected motif per board; score-independent uniform board sampling.',
        uncertainty='95% whole-board normal intervals for paired means, Wilson intervals for frequencies. Each board supplies one paired motif.',
        inference='Frozen Generation 37, original checkpoint, direct network with legal-action softmax. No tree search, no future-state simulations, no gameplay rollouts.',
        scope='A chooses the final opening road and will take the first normal turn. This study does not compare A versus B race outcomes or establish who wins the race.',
        source='opening-study-100k-20261029, 100000 greedy opening boards with seeds 4100000 through 4199999. New interventions independently replayed by native game.',
        limitations=['The main contrast measures changing road orientation, including broader spatial consequences; it is not a pure semantic threat flag.',
                     'Starting-hand readiness uses existing starting cards only. The first roll can add resources.',
                     'Softmax preferences are network choice scores, not calibrated win probabilities.',
                     'A readiness strata are observational groups, not a randomized causal intervention.',
                     'Swapping B settlement order preserves pieces and production but changes its resource mix and bank counts. The factorial effect is not attributable solely to having wood and brick.'])
    result['roads'] = base.roads_experiment(ev, selected, args.out, patch_n=0)
    cases = json.loads((args.out/'roads-cases.json').read_text())
    for ready in (False, True):
        result['roads']['A_ready' if ready else 'A_unready'] = road_summary([c for c in cases if c['A_road_ready'] == ready])
    base.json_write(args.out/'illustrative-cases.json', representative_cases(cases))
    print(json.dumps(dict(stage='roads_done', n=len(cases), seconds=time.time()-started,
                         results=result['roads'])), flush=True)
    # Reuse native-legal B1/B2 hand-order factorial, with this study's geometry.
    readiness_rows = [{k: v for k, v in row.items() if k != 'A_road_ready'} for row in rows]
    result['opponent_starting_hand_readiness'] = base.opponent_readiness(ev, readiness_rows, args.readiness_n, args.out)
    result['validation'] = dict(all_openings_replayed=True,
        original_settlements_distance_exactly_two=True, junction_degree_three=True,
        junction_and_branch_destination_empty=True, no_prior_road_at_branch_destination=True,
        equal_A_legal_road_sets_in_pairs=True, road_orientation_global_vectors_identical=True,
        readiness_spatial_vectors_identical_within_each_orientation=True,
        network_rows=ev.inferences, future_simulations=0)
    result['elapsed_seconds'] = time.time()-started
    base.json_write(args.out/'results.json', result)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
