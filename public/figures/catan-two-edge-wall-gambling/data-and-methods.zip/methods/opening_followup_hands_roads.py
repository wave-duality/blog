#!/usr/bin/env python3
"""Paired Generation 37 starting-hand and contested-road experiments.

All game states are legal histories replayed by the native referee. No edited
feature vector is submitted as a real position. The zero-simulation wrapper is
used only to expose the native legal mask; its dummy evaluator performs no
network inference and every child visit count is asserted zero.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import time

import catan_rl
import numpy as np
import torch
import torch.nn.functional as F

from opening_engine import OpeningEngine, MODEL_SHA, GEOMETRY
from feature_dictionary import geometry_data
from train import split_obs

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'run/analysis/opening-followups-20261102/hands_roads'
SOURCE = ROOT / 'run/analysis/opening-study-100k-20261029/shards'
SEED = 2026110213
RESOURCES = ['wood', 'brick', 'sheep', 'wheat', 'ore']
ROLLS = np.array([2,3,4,5,6,8,9,10,11,12])
ROLL_P = np.array([1,2,3,4,5,5,4,3,2,1], dtype=float) / 30
G, DISTANCE = geometry_data()
ENDS = np.array(G['path_vertices'])
INCIDENT = [[i for i, vv in enumerate(ENDS) if v in vv] for v in range(54)]
EDGE = {tuple(sorted(vv)): i for i, vv in enumerate(ENDS.tolist())}


def json_write(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def mean_ci(x):
    x = np.asarray(x, dtype=float)
    if not len(x):
        return dict(n=0, mean=None, ci95=None)
    se = x.std(ddof=1) / np.sqrt(len(x)) if len(x)>1 else 0
    return dict(n=len(x), mean=float(x.mean()), ci95=[float(x.mean()-1.96*se), float(x.mean()+1.96*se)])


def wilson(x):
    x = np.asarray(x, dtype=bool); n = len(x)
    if not n: return dict(n=0, rate=None, ci95=None)
    p = x.mean(); z=1.96; d=1+z*z/n
    c=(p+z*z/(2*n))/d; h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return dict(n=n, count=int(x.sum()), rate=float(p), ci95=[max(0.,float(c-h)),min(1.,float(c+h))])


def grant(board, corner):
    count = np.zeros(5, dtype=int)
    for h in G['vertex_hexes'][corner]:
        if h is not None and h >= 0 and board[0][h] < 5:
            count[board[0][h]] += 1
    return count


def pip_total(board, corner):
    return sum(6-abs(7-board[1][h]) for h in G['vertex_hexes'][corner]
               if h is not None and h >= 0 and board[0][h] < 5)


def swap_a(history):
    return history[6:8] + history[2:6] + history[:2]


def swap_b(history):
    return history[:2] + history[4:6] + history[2:4] + history[6:]


def road_motif(board, history):
    """A2--u--v--B2: one unowned central edge both can race to claim.

    The opponent's away road must increase its distance from A2. Both outer
    edges and the central edge must be unoccupied by the two fixed earlier
    roads. Selection is purely geometric, highest adjacent production first.
    """
    a, b = history[6]-72, history[4]-72
    if DISTANCE[a,b] != 3: return None
    occupied = set(history[1:4:2])
    options = []
    for ea in INCIDENT[a]:
        u = next(v for v in ENDS[ea] if v != a)
        if DISTANCE[u,b] != 2 or ea in occupied: continue
        for eb in INCIDENT[b]:
            v = next(v for v in ENDS[eb] if v != b)
            if DISTANCE[u,v] != 1 or eb in occupied: continue
            middle = EDGE[tuple(sorted([int(u),int(v)]))]
            if middle in occupied: continue
            connects_b1 = bool(set(ENDS[eb]) & set(ENDS[history[3]]))
            away = [e for e in INCIDENT[b] if e not in occupied and
                    DISTANCE[a,next(w for w in ENDS[e] if w!=b)] > 3 and
                    bool(set(ENDS[e]) & set(ENDS[history[3]])) == connects_b1]
            if not away: continue
            options.append((-pip_total(board,int(u))-pip_total(board,int(v)),ea,eb,min(away),middle,int(u),int(v)))
    if not options: return None
    _, ar, toward, away, edge, u, v = min(options)
    return dict(a_corner=a,b_corner=b,a_toward=ar,b_toward=toward,b_away=away,
                contested_edge=edge,central_vertices=[u,v])


def load_screen(limit=0):
    hands=[];roads=[];counts=Counter()
    for path in sorted(SOURCE.glob('*.npz')):
        with np.load(path) as data:
            seeds=data['board_seed']; resources=data['board_resources'];numbers=data['board_numbers'];ports=data['board_ports']; histories=data['history']
            for i,seed in enumerate(seeds):
                if limit and counts['boards']>=limit: break
                counts['boards']+=1
                b=[resources[i].tolist(),numbers[i].tolist(),ports[i].tolist()];h=histories[i].astype(int).tolist()
                row=dict(seed=int(seed), board=b, history=h)
                a1,a2=grant(b,h[0]-72),grant(b,h[6]-72)
                if np.array_equal(a1,a2):counts['identical_A_hands']+=1
                elif a1.sum()!=a2.sum():counts['different_starting_card_count']+=1
                else:hands.append(row)
                motif=road_motif(b,h)
                if motif is not None:roads.append(dict(**row,motif=motif))
        if limit and counts['boards']>=limit: break
    counts['eligible_equal_size_different_A_hand']=len(hands);counts['eligible_contested_edge_geometry']=len(roads)
    return hands,roads,dict(counts)


class Evaluation:
    def __init__(self):
        self.engine=OpeningEngine();self.model=self.engine.model.requires_grad_(False)
        self.bot=catan_rl.Bot(sims=0,considered=241,determinizations=1)
        self.native_masks=0;self.inferences=0

    def position(self,board,history,roll=None,mask=True):
        # First validate all eight real opening actions using Game, independently
        # of the Bot replay below. A returned observation never bypasses PlayerView.
        game=catan_rl.Game.from_opening(*board,history)
        assert game.legal()==[240]
        replay=[(1,int(a)) for a in history]
        if roll is not None:replay += [(1,240),(0,int(roll))]
        obs,actor=self.bot.value_observations(*board,replay,0)
        assert actor==0 and obs.shape==(1,4752)
        legal=None
        if mask:
            called=[]
            def dummy(o):
                called.append(o.copy())
                return np.zeros((len(o),241),np.float32),np.zeros(len(o),np.float32)
            self.bot.choose(*board,replay,dummy)
            diagnostic=self.bot.last_search()
            assert len(called)==1 and not diagnostic['selection_rounds']
            assert all(a['visits']==0 for a in diagnostic['actions'])
            np.testing.assert_array_equal(called[0],obs)
            legal=np.array([a['action'] for a in diagnostic['actions']],dtype=int)
            assert len(legal)>0
            self.native_masks+=1
        return obs[0],legal

    @torch.inference_mode()
    def forward(self,observations,batch=64):
        ll=[];vv=[]
        for i in range(0,len(observations),batch):
            x=np.asarray(observations[i:i+batch],dtype=np.float32)
            l,v=self.model(*split_obs(torch.from_numpy(x)))
            ll.append(l.numpy());vv.append(v.numpy());self.inferences+=len(x)
        return np.concatenate(ll),np.concatenate(vv)

    @torch.inference_mode()
    def trace(self,obs):
        h,v,p,g=split_obs(torch.from_numpy(obs[None]))
        state=(F.relu(self.model.hex_embed(h)),F.relu(self.model.vertex_embed(v)),
               F.relu(self.model.path_embed(p)),F.relu(self.model.global_embed(g)))
        states=[state]
        for layer in self.model.layers:state=layer(*state);states.append(state)
        return states

    @torch.inference_mode()
    def patch_road(self,base,donor,rows,action,others):
        a=self.trace(base);b=self.trace(donor)
        def margin(s):
            scores=self.model.road_head(s[2]).squeeze(-1)[0].numpy()
            return float(scores[action]-np.mean(scores[others]))
        def run(state):
            for layer in self.model.layers:state=layer(*state)
            return margin(state)
        original=margin(a[-1]);target=margin(b[-1])
        identity=run(a[0]);full=run(b[0])
        assert abs(identity-original)<1e-5 and abs(full-target)<1e-5
        state=list(a[0]);state[2]=state[2].clone();state[2][:,rows]=b[0][2][:,rows]
        partial=run(tuple(state))
        path_state=list(a[0]);path_state[2]=b[0][2]
        all_paths=run(tuple(path_state))
        vertex_state=list(a[0]);vertex_state[1]=b[0][1]
        all_vertices=run(tuple(vertex_state))
        shuffled=list(a[0]);shuffled[2]=shuffled[2].clone()
        # Matched-size control patches two untouched path rows, so exact identity
        # is expected only when their native encoded rows are identical.
        same=np.flatnonzero(np.all(base[3200:4352].reshape(72,16)==donor[3200:4352].reshape(72,16),axis=1))
        control=same[:len(rows)]
        shuffled[2][:,control]=b[0][2][:,control]
        control_result=run(tuple(shuffled));assert abs(control_result-original)<1e-5
        return dict(base_margin=original,donor_margin=target,patched_margin=partial,
                    all_paths_patched_margin=all_paths,all_vertices_patched_margin=all_vertices,
                    identity_error=abs(identity-original),full_error=abs(full-target),
                    unchanged_rows_control_error=abs(control_result-original))


def policy(logits,legal):
    out=np.zeros(241,dtype=float)
    z=logits[legal].astype(float); e=np.exp(z-z.max());out[legal]=e/e.sum()
    return int(legal[np.lexsort((legal,-z))[0]]),out


def category(a):
    if a<72:return 'road'
    if a<126:return 'settlement'
    if a<180:return 'city'
    if a==180:return 'development card'
    if 214<=a<239:return 'bank trade'
    if a==239:return 'end turn'
    return f'action {a}'


def sample(rows,n,salt):
    index=np.random.default_rng(SEED+salt).permutation(len(rows))[:min(n,len(rows))]
    return [rows[i] for i in index]


def hands_experiment(ev,rows,out,patch_n):
    observations=[];legal=[];cases=[];rng=np.random.default_rng(SEED+100)
    for row in rows:
        b,h=row['board'],row['history'];alt=swap_a(h);roll=int(rng.choice(ROLLS,p=ROLL_P))
        x,_=ev.position(b,h,mask=False);y,_=ev.position(b,alt,mask=False)
        # Reordering the same pieces changes no spatial input before the roll.
        np.testing.assert_array_equal(x[:4352],y[:4352])
        assert np.isclose(x[-400:-395].sum(),y[-400:-395].sum())
        np.testing.assert_array_equal(x[-395:-390],y[-395:-390])
        assert not np.array_equal(x[-400:-395],y[-400:-395])
        assert np.allclose(x[-400:-395]*10,grant(b,h[6]-72))
        assert np.allclose(y[-400:-395]*10,grant(b,h[0]-72))
        xr,lx=ev.position(b,h,roll);yr,ly=ev.position(b,alt,roll)
        observations.extend([x,y,xr,yr]);legal.extend([lx,ly])
        cases.append(dict(**row,swapped_history=alt,roll=roll,
                          starting_hand_original=np.rint(x[-400:-395]*10).astype(int).tolist(),
                          starting_hand_swapped=np.rint(y[-400:-395]*10).astype(int).tolist(),
                          hand_after_roll_original=np.rint(xr[-400:-395]*10).astype(int).tolist(),
                          hand_after_roll_swapped=np.rint(yr[-400:-395]*10).astype(int).tolist()))
    logits,values=ev.forward(observations)
    metrics={k:[] for k in ['pre_roll_value_delta','pre_roll_absolute_value_delta','post_roll_value_delta','post_roll_absolute_value_delta','choice_changed','category_changed','total_variation','common_mask_total_variation','common_mask_choice_changed','same_legal_set']}
    for i,c in enumerate(cases):
        lx,ly=legal[2*i:2*i+2]; a,pa=policy(logits[4*i+2],lx);bb,pb=policy(logits[4*i+3],ly)
        common=np.intersect1d(lx,ly);ac,pc=policy(logits[4*i+2],common);bc,pd=policy(logits[4*i+3],common)
        c.update(pre_roll_value_original=float(values[4*i]),pre_roll_value_swapped=float(values[4*i+1]),
                 post_roll_value_original=float(values[4*i+2]),post_roll_value_swapped=float(values[4*i+3]),
                 legal_original=lx.tolist(),legal_swapped=ly.tolist(),choice_original=a,choice_swapped=bb,
                 category_original=category(a),category_swapped=category(bb),
                 preference_original={str(j):float(pa[j]) for j in lx},preference_swapped={str(j):float(pb[j]) for j in ly})
        pre=float(values[4*i+1]-values[4*i]);post=float(values[4*i+3]-values[4*i+2])
        for k,v in dict(pre_roll_value_delta=pre,pre_roll_absolute_value_delta=abs(pre),post_roll_value_delta=post,post_roll_absolute_value_delta=abs(post),
                        choice_changed=a!=bb,category_changed=category(a)!=category(bb),total_variation=np.abs(pa-pb).sum()/2,
                        common_mask_total_variation=np.abs(pc-pd).sum()/2,common_mask_choice_changed=ac!=bc,same_legal_set=np.array_equal(lx,ly)).items():metrics[k].append(v)
    # A first-layer global representation patch on the pre-roll value output.
    patches=[]
    for i in range(min(patch_n,len(cases))):
        sa=ev.trace(observations[4*i]);sb=ev.trace(observations[4*i+1]);model=ev.model
        def value(s):return float(torch.tanh(model.value_head(s[3])).item())
        def rest(state,depth):
            for layer in list(model.layers)[depth:]:state=layer(*state)
            return value(state)
        with torch.inference_mode():
            base=value(sa[-1]);donor=value(sb[-1]);state=list(sa[1]);state[3]=sb[1][3]
            patched=rest(tuple(state),1);identity=rest(sa[1],1);full=rest(sb[1],1)
            s0=list(sa[0]);s0[3]=sb[0][3];input_global=rest(tuple(s0),0)
        assert abs(identity-base)<1e-5 and abs(full-donor)<1e-5 and abs(input_global-donor)<1e-5
        patches.append(dict(seed=cases[i]['seed'],base=base,donor=donor,patched_global_after_round1=patched,
                            input_global_reconstruction_error=abs(input_global-donor),identity_error=abs(identity-base),full_error=abs(full-donor)))
    totals={k:(wilson(v) if k in ['choice_changed','category_changed','same_legal_set','common_mask_choice_changed'] else mean_ci(v)) for k,v in metrics.items()}
    totals['original_action_categories']=dict(Counter(c['category_original'] for c in cases));totals['swapped_action_categories']=dict(Counter(c['category_swapped'] for c in cases))
    totals['global_patch']=patch_summary(patches,'base','donor','patched_global_after_round1')
    json_write(out/'hands-cases.json',cases);json_write(out/'hands-patches.json',patches)
    return totals


def patch_summary(rows,base,donor,patched):
    if not rows:return dict(n=0)
    a=np.array([r[donor]-r[base] for r in rows]);b=np.array([r[patched]-r[base] for r in rows])
    denominator=float(a@a);value=float(a@b/denominator) if denominator else None
    rng=np.random.default_rng(SEED+900);boots=[]
    for _ in range(2000):
        ix=rng.integers(len(a),size=len(a));aa=a[ix];bb=b[ix]
        if aa@aa>0:boots.append(float(aa@bb/(aa@aa)))
    return dict(n=len(rows),pooled_effect_projection=value,ci95=np.quantile(boots,[.025,.975]).tolist(),
                formula='sum(delta_full * delta_patch) / sum(delta_full^2)',
                note='Effect alignment diagnostic, not a bounded causal fraction or a semantic neuron identification.')


def roads_experiment(ev,rows,out,patch_n):
    obs=[];legals=[];cases=[];patches=[]
    for row in rows:
        b,h,m=row['board'],row['history'],row['motif'];tow=h[:7].copy();away=h[:7].copy();tow[5]=m['b_toward'];away[5]=m['b_away']
        gt=catan_rl.Game.from_opening(*b,tow);ga=catan_rl.Game.from_opening(*b,away)
        lt=np.array(gt.legal());la=np.array(ga.legal());np.testing.assert_array_equal(lt,la)
        assert m['a_toward'] in lt and len(lt)>1
        xt=gt.opening_observation()[0];xa=ga.opening_observation()[0]
        # Same board, buildings, cards and global input; only road context differs.
        np.testing.assert_array_equal(xt[-400:],xa[-400:])
        obs.extend([xa,xt]);legals.append(lt);cases.append(dict(**row,toward_history=tow,away_history=away))
        if len(patches)<patch_n:
            p=ev.patch_road(xa,xt,[m['b_toward'],m['b_away']],m['a_toward'],lt[lt!=m['a_toward']])
            patches.append(dict(seed=row['seed'],**p))
    logits,values=ev.forward(obs);metrics={k:[] for k in ['race_preference_away','race_preference_toward','race_preference_delta','race_logit_margin_delta','race_chosen_away','race_chosen_toward','any_choice_changed']}
    for i,c in enumerate(cases):
        legal=legals[i];road=c['motif']['a_toward'];a,pa=policy(logits[2*i],legal);b,pb=policy(logits[2*i+1],legal)
        other=legal[legal!=road];margin_a=float(logits[2*i,road]-logits[2*i,other].mean());margin_b=float(logits[2*i+1,road]-logits[2*i+1,other].mean())
        for k,v in dict(race_preference_away=pa[road],race_preference_toward=pb[road],race_preference_delta=pb[road]-pa[road],
                        race_logit_margin_delta=margin_b-margin_a,race_chosen_away=a==road,race_chosen_toward=b==road,any_choice_changed=a!=b).items():metrics[k].append(v)
        c.update(legal_roads=legal.tolist(),choice_away=a,choice_toward=b,race_preference_away=float(pa[road]),race_preference_toward=float(pb[road]),race_logit_margin_away=margin_a,race_logit_margin_toward=margin_b,
                 preferences_away={str(j):float(pa[j]) for j in legal},preferences_toward={str(j):float(pb[j]) for j in legal})
    totals={k:(wilson(v) if k in ['race_chosen_away','race_chosen_toward','any_choice_changed'] else mean_ci(v)) for k,v in metrics.items()}
    totals['two_changed_path_embeddings_patch']=patch_summary(patches,'base_margin','donor_margin','patched_margin')
    totals['all_path_embeddings_patch']=patch_summary(patches,'base_margin','donor_margin','all_paths_patched_margin')
    totals['all_vertex_embeddings_patch']=patch_summary(patches,'base_margin','donor_margin','all_vertices_patched_margin')
    json_write(out/'roads-cases.json',cases);json_write(out/'roads-patches.json',patches)
    return totals


def roads_readiness(ev,rows,n,out):
    """Outcome-blind screening across all geometric pairs, then random sample.

    With the A road fixed toward the contested middle edge, that edge is
    geometrically reachable under either B orientation. At the first Play
    decision affordability is exactly having >=1 wood and >=1 brick.
    Native legal masks verify this predicate in all four selected conditions.
    """
    rng=np.random.default_rng(SEED+500);eligible=[]
    for row in rows:
        b,h=row['board'],row['history'];roll=int(rng.choice(ROLLS,p=ROLL_P))
        production=np.zeros(5,dtype=int)
        for v in [h[0]-72,h[6]-72]:
            for tile in G['vertex_hexes'][v]:
                if tile is not None and tile>=0 and b[0][tile]<5 and b[1][tile]==roll:
                    production[b[0][tile]]+=1
        original=grant(b,h[6]-72)+production;swapped=grant(b,h[0]-72)+production
        if min(original[0],original[1],swapped[0],swapped[1])>=1 and not np.array_equal(original,swapped):
            eligible.append(dict(**row,roll=roll,hand_original=original.tolist(),hand_swapped=swapped.tolist()))
    selected=sample(eligible,n,501);observations=[];legals=[]
    for row in selected:
        b,h,m=row['board'],row['history'],row['motif']
        for opponent in ['b_away','b_toward']:
            hh=h.copy();hh[5]=m[opponent];hh[7]=m['a_toward']
            for order in [hh,swap_a(hh)]:
                x,legal=ev.position(b,order,row['roll'])
                assert m['contested_edge'] in legal
                expected=row['hand_original'] if order==hh else row['hand_swapped']
                np.testing.assert_allclose(x[-400:-395]*10,expected,atol=1e-6,rtol=0)
                observations.append(x);legals.append(legal)
    logits,_=ev.forward(observations);interaction=[];absolute=[];delta0=[];delta1=[];changes=[]
    for i,row in enumerate(selected):
        edge=row['motif']['contested_edge'];prefs=[];choices=[];margins=[]
        for j in range(4):
            idx=4*i+j;action,p=policy(logits[idx],legals[idx]);prefs.append(float(p[edge]));choices.append(action)
            margins.append(float(logits[idx,edge]-logits[idx,239]))
        d0=prefs[2]-prefs[0];d1=prefs[3]-prefs[1];interaction.append(d1-d0);absolute.append(abs(d1-d0));delta0.append(d0);delta1.append(d1);changes.append(choices[2]!=choices[3])
        row.update(condition_order=['away/original','away/swapped','toward/original','toward/swapped'],race_preferences=prefs,choices=choices,
                   race_versus_end_turn_logits=margins,threat_effect_original=d0,threat_effect_swapped=d1,interaction=d1-d0)
    result=dict(screened_geometry_boards=len(rows),eligible_boards=len(eligible),n=len(selected),
                selection='Across all geometric pairs, one outcome-blind non-7 roll per board; require different A hands after swapping A1/A2 and >=1 wood+brick in both. Uniform random sample of eligible boards; native legal replay verifies contested edge legal in all four conditions.',
                interaction_preference=mean_ci(interaction),absolute_interaction_preference=mean_ci(absolute),
                hand_swap_changes_choice_under_threat=wilson(changes),threat_effect_original=mean_ci(delta0),threat_effect_swapped=mean_ci(delta1))
    json_write(out/'roads-hand-factorial-cases.json',selected)
    return result


def opponent_readiness(ev,rows,n,out):
    """Before A2's road: B starting-hand order x road orientation, all legal.

    Swapping B1/B2 preserves B's pieces/production but changes which settlement
    grants B's initial cards. Require equal card counts and exactly one hand
    able to buy a road. All four inputs have identical resources/numbers/ports,
    buildings and A's hand. No dice have yet been rolled.
    """
    eligible=[]
    for row in rows:
        b,h=row['board'],row['history'];first=grant(b,h[2]-72);second=grant(b,h[4]-72)
        ready_first=min(first[0],first[1])>=1;ready_second=min(second[0],second[1])>=1
        if ready_first!=ready_second and first.sum()==second.sum():
            eligible.append(dict(**row,original_B_ready=bool(ready_second),B_hand_first=first.tolist(),B_hand_second=second.tolist(),A_road_ready=bool(min(grant(b,h[6]-72)[:2])>=1)))
    selected=sample(eligible,n,601);observations=[];legals=[]
    for row in selected:
        b,h,m=row['board'],row['history'],row['motif'];pairs=[]
        for opponent in ['b_away','b_toward']:
            hh=h[:7].copy();hh[5]=m[opponent]
            # Fixed semantic condition order: unready, ready.
            orders=[hh,swap_b(hh)] if not row['original_B_ready'] else [swap_b(hh),hh]
            for order in orders:
                game=catan_rl.Game.from_opening(*b,order);x=game.opening_observation()[0];legal=np.array(game.legal())
                assert m['a_toward'] in legal
                observations.append(x);legals.append(legal);pairs.append(x)
        for x in pairs[1:]:
            np.testing.assert_array_equal(x[-400:-395],pairs[0][-400:-395])
        # Within each road orientation, the entire spatial input is unchanged.
        np.testing.assert_array_equal(pairs[0][:4352],pairs[1][:4352]);np.testing.assert_array_equal(pairs[2][:4352],pairs[3][:4352])
        for l in legals[-3:]:np.testing.assert_array_equal(l,legals[-4])
    logits,_=ev.forward(observations);metrics={k:[] for k in ['interaction','threat_effect_B_unready','threat_effect_B_ready']};choice_changes=[]
    for i,row in enumerate(selected):
        road=row['motif']['a_toward'];prefs=[];choices=[]
        for j in range(4):
            idx=4*i+j;choice,p=policy(logits[idx],legals[idx]);prefs.append(float(p[road]));choices.append(choice)
        d0=prefs[2]-prefs[0];d1=prefs[3]-prefs[1];metrics['interaction'].append(d1-d0);metrics['threat_effect_B_unready'].append(d0);metrics['threat_effect_B_ready'].append(d1);choice_changes.append(choices[2]!=choices[3])
        row.update(condition_order=['away/B_unready','away/B_ready','toward/B_unready','toward/B_ready'],race_preferences=prefs,choices=choices,
                   threat_effect_B_unready=d0,threat_effect_B_ready=d1,interaction=d1-d0)
    result=dict(screened_geometry_boards=len(rows),eligible_boards=len(eligible),n=len(selected),
                selection='Swap B1/B2 piece pairs, preserving total starting-card count; require exactly one B starting hand to contain wood+brick. Cross road orientation x B hand readiness. Uniform score-independent sample; all four setup histories native legal.',
                **{k:mean_ci(v) for k,v in metrics.items()},
                B_readiness_changes_choice_under_threat=wilson(choice_changes))
    for isready in [False,True]:
        mask=np.array([r['A_road_ready']==isready for r in selected]);result['A_ready' if isready else 'A_unready']={k:mean_ci(np.array(v)[mask]) for k,v in metrics.items()}
    json_write(out/'roads-opponent-readiness-cases.json',selected)
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--n',type=int,default=2000);p.add_argument('--patch-n',type=int,default=256);p.add_argument('--readiness-n',type=int,default=1000);p.add_argument('--screen-limit',type=int,default=0);p.add_argument('--out',type=Path,default=OUT);args=p.parse_args()
    started=time.time();args.out.mkdir(parents=True,exist_ok=True);torch.set_num_threads(1)
    hands,roads,screen=load_screen(args.screen_limit);print(json.dumps(dict(screen=screen,seconds=time.time()-started)),flush=True)
    h=sample(hands,args.n,1);r=sample(roads,args.n,2);ev=Evaluation()
    result=dict(schema='opening-hands-roads-v1',checkpoint_sha256=MODEL_SHA,seed=SEED,script_sha256=digest(__file__),screen=screen,
                sample_selection='Uniform seeded permutation among geometrically eligible whole boards, without looking at intervention scores.',
                uncertainty='95% whole-board normal intervals for paired means, Wilson intervals for frequencies, whole-board percentile bootstrap for patch projection.',
                dice='One shared roll per paired board, drawn with exact dice frequencies conditional on not rolling 7; same roll under all counterfactuals.',
                inference='Frozen Generation 37 direct network. Zero future-state simulations; the native 0-simulation dummy callback extracts legality only.',
                source='opening-study-100k-20261029: seeds 4100000 through 4199999, original greedy openings; interventions replayed natively.')
    result['hands']=hands_experiment(ev,h,args.out,args.patch_n);print(json.dumps(dict(stage='hands_done',seconds=time.time()-started,results=result['hands'])),flush=True)
    result['roads']=roads_experiment(ev,r,args.out,args.patch_n)
    result['roads']['same_board_hand_factorial']=roads_readiness(ev,roads,args.readiness_n,args.out)
    result['roads']['opponent_starting_hand_readiness']=opponent_readiness(ev,roads,args.readiness_n,args.out)
    result['validation']=dict(native_legal_masks=ev.native_masks,network_rows=ev.inferences,all_child_visits_zero=True,
        all_openings_replayed=True,hands_spatial_inputs_equal_before_roll=True,roads_global_inputs_equal_at_road_choice=True,
        patch_identity_and_full_controls_pass=True)
    result['elapsed_seconds']=time.time()-started;json_write(args.out/'results.json',result);print(json.dumps(result),flush=True)


if __name__=='__main__':main()
